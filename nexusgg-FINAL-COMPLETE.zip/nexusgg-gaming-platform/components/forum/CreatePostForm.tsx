"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import {
  Loader2,
  AlertCircle,
  Image as ImageIcon,
  X,
  Hash,
} from "lucide-react";
import { createClient } from "@/lib/auth/supabase-client";

interface CreatePostFormProps {
  games: any[];
}

interface PostFormData {
  title: string;
  content: string;
  gameId: string;
  tags: string;
}

export default function CreatePostForm({ games }: CreatePostFormProps) {
  const router = useRouter();
  const [error, setError] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<PostFormData>();

  const handleMediaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) {
        setError("Le fichier ne doit pas dépasser 10MB");
        return;
      }
      setMediaFile(file);
      setMediaPreview(URL.createObjectURL(file));
    }
  };

  const onSubmit = async (data: PostFormData) => {
    setError("");
    setIsLoading(true);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      let mediaUrl = undefined;
      let mediaType = undefined;

      // Upload media if present
      if (mediaFile) {
        const fileExt = mediaFile.name.split(".").pop();
        const fileName = `${user.id}-${Date.now()}.${fileExt}`;
        const filePath = `posts/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from("posts")
          .upload(filePath, mediaFile);

        if (uploadError) throw uploadError;

        const {
          data: { publicUrl },
        } = supabase.storage.from("posts").getPublicUrl(filePath);

        mediaUrl = publicUrl;
        mediaType = mediaFile.type.startsWith("video") ? "video" : "image";
      }

      // Create post
      const tags = data.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);

      const { error: postError } = await supabase.from("posts").insert({
        author_id: user.id,
        title: data.title,
        content: data.content,
        game_id: data.gameId || null,
        media_url: mediaUrl,
        media_type: mediaType,
        tags,
      });

      if (postError) throw postError;

      router.push("/forum");
      router.refresh();
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue");
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {error && (
        <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/50 flex items-start space-x-3">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-200">{error}</p>
        </div>
      )}

      {/* Title */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">
          Titre *
        </label>
        <input
          {...register("title", {
            required: "Le titre est requis",
            minLength: { value: 5, message: "Minimum 5 caractères" },
            maxLength: { value: 200, message: "Maximum 200 caractères" },
          })}
          type="text"
          className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          placeholder="Un titre accrocheur..."
        />
        {errors.title && (
          <p className="mt-1 text-sm text-red-400">{errors.title.message}</p>
        )}
      </div>

      {/* Game Selection */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">
          Jeu (optionnel)
        </label>
        <select
          {...register("gameId")}
          className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
        >
          <option value="">Sélectionner un jeu...</option>
          {games.map((game) => (
            <option key={game.id} value={game.id}>
              {game.name}
            </option>
          ))}
        </select>
      </div>

      {/* Content */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">
          Contenu *
        </label>
        <textarea
          {...register("content", {
            required: "Le contenu est requis",
            minLength: { value: 10, message: "Minimum 10 caractères" },
          })}
          rows={8}
          className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white resize-none"
          placeholder="Partage ton histoire..."
        />
        {errors.content && (
          <p className="mt-1 text-sm text-red-400">{errors.content.message}</p>
        )}
      </div>

      {/* Media Upload */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">
          Image ou Vidéo (optionnel)
        </label>
        {mediaPreview ? (
          <div className="relative">
            <img
              src={mediaPreview}
              alt="Preview"
              className="w-full rounded-lg max-h-96 object-cover"
            />
            <button
              type="button"
              onClick={() => {
                setMediaFile(null);
                setMediaPreview("");
              }}
              className="absolute top-2 right-2 p-2 rounded-full bg-red-500 hover:bg-red-600 transition-colors"
            >
              <X className="h-4 w-4 text-white" />
            </button>
          </div>
        ) : (
          <label className="cursor-pointer block p-8 glass-effect rounded-lg border-2 border-dashed border-slate-700 hover:border-indigo-500 transition-all text-center">
            <ImageIcon className="h-12 w-12 text-slate-500 mx-auto mb-3" />
            <p className="text-sm text-slate-400 mb-1">
              Clique pour uploader une image ou vidéo
            </p>
            <p className="text-xs text-slate-600">Max 10MB</p>
            <input
              type="file"
              accept="image/*,video/*"
              onChange={handleMediaChange}
              className="hidden"
            />
          </label>
        )}
      </div>

      {/* Tags */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-2">
          Tags (séparés par des virgules)
        </label>
        <div className="relative">
          <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-500" />
          <input
            {...register("tags")}
            type="text"
            className="w-full pl-10 pr-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
            placeholder="clutch, ranked, funny"
          />
        </div>
      </div>

      {/* Submit */}
      <div className="flex items-center justify-end space-x-4 pt-4 border-t border-slate-800/50">
        <button
          type="button"
          onClick={() => router.back()}
          className="px-6 py-3 rounded-lg glass-effect border border-slate-700 hover:border-slate-600 text-slate-300 font-medium transition-all"
        >
          Annuler
        </button>
        <button
          type="submit"
          disabled={isLoading}
          className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold transition-all duration-300 shadow-lg hover:shadow-indigo-500/50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Publication...</span>
            </>
          ) : (
            <span>Publier</span>
          )}
        </button>
      </div>
    </form>
  );
}
