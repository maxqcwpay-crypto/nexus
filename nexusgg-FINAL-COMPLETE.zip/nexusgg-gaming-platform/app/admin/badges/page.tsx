import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin } from "@/lib/admin/admin-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import { Trophy, Plus, Edit, Trash2 } from "lucide-react";

export default async function AdminBadgesPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const { data: badges } = await supabase
    .from("badges")
    .select("*, user_count:user_badges(count)")
    .order("created_at", { ascending: false });

  const rarityConfig = {
    common: { color: "text-slate-400 bg-slate-500/20", label: "Commun" },
    rare: { color: "text-blue-400 bg-blue-500/20", label: "Rare" },
    epic: { color: "text-purple-400 bg-purple-500/20", label: "Épique" },
    legendary: { color: "text-amber-400 bg-amber-500/20", label: "Légendaire" },
  };

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Gestion des Badges
              </h1>
              <p className="text-slate-400">
                {badges?.length || 0} badges disponibles
              </p>
            </div>
            <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-semibold flex items-center space-x-2">
              <Plus className="h-5 w-5" />
              <span>Créer un badge</span>
            </button>
          </div>

          {/* Badges Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {badges?.map((badge: any) => {
              const config =
                rarityConfig[badge.rarity as keyof typeof rarityConfig];

              return (
                <div
                  key={badge.id}
                  className="glass-effect rounded-lg p-6 border border-slate-800/50 hover:border-indigo-500/30 transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div
                      className={`h-16 w-16 rounded-full ${config.color} flex items-center justify-center`}
                    >
                      <Trophy className="h-8 w-8" />
                    </div>
                    <span className={`px-3 py-1 rounded text-xs font-medium ${config.color}`}>
                      {config.label}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2">
                    {badge.name}
                  </h3>
                  <p className="text-sm text-slate-400 mb-4">
                    {badge.description}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-800/50">
                    <div className="text-sm text-slate-500">
                      {badge.user_count?.[0]?.count || 0} utilisateurs
                    </div>
                    <div className="flex items-center space-x-2">
                      <button className="p-2 rounded-lg glass-effect border border-slate-700 hover:border-indigo-500 transition-all">
                        <Edit className="h-4 w-4 text-slate-400" />
                      </button>
                      <button className="p-2 rounded-lg glass-effect border border-red-500/30 hover:bg-red-500/20 transition-all">
                        <Trash2 className="h-4 w-4 text-red-400" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {(!badges || badges.length === 0) && (
            <div className="text-center py-12 glass-effect rounded-lg border border-slate-800/50">
              <Trophy className="h-12 w-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400 mb-4">Aucun badge pour le moment</p>
              <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-semibold">
                Créer le premier badge
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
