"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  User,
  MapPin,
  Calendar,
  Edit,
  Share2,
  MoreVertical,
  Twitch,
  Users,
} from "lucide-react";
import { UserProfile } from "@/lib/profile/profile-service";
import { formatDate } from "@/lib/utils";

interface ProfileHeaderProps {
  profile: UserProfile;
  isOwnProfile: boolean;
}

export default function ProfileHeader({
  profile,
  isOwnProfile,
}: ProfileHeaderProps) {
  const [isFollowing, setIsFollowing] = useState(false);

  const getRankColor = (rank: string) => {
    switch (rank) {
      case "Rookie":
        return "text-slate-400 bg-slate-800/50";
      case "Player":
        return "text-green-400 bg-green-900/30";
      case "Pro":
        return "text-blue-400 bg-blue-900/30";
      case "Elite":
        return "text-purple-400 bg-purple-900/30";
      case "Legend":
        return "text-amber-400 bg-amber-900/30";
      default:
        return "text-slate-400 bg-slate-800/50";
    }
  };

  return (
    <div className="relative">
      {/* Cover Image */}
      <div className="h-64 bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.3)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.3)_1px,transparent_1px)] bg-[size:64px_64px]" />
      </div>

      {/* Profile Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative -mt-24 pb-6">
          <div className="flex flex-col md:flex-row gap-6">
            {/* Avatar */}
            <div className="relative">
              <div className="h-40 w-40 rounded-2xl border-4 border-slate-950 overflow-hidden glass-effect">
                {profile.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt={profile.username}
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="h-full w-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                    <User className="h-20 w-20 text-white" />
                  </div>
                )}
              </div>
              <div
                className={`absolute -bottom-2 -right-2 px-3 py-1 rounded-full text-xs font-bold ${getRankColor(
                  profile.rank
                )} border border-slate-700`}
              >
                {profile.rank}
              </div>
            </div>

            {/* Info */}
            <div className="flex-1 pt-4 md:pt-10">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-bold text-white mb-2">
                    {profile.username}
                  </h1>
                  {profile.bio && (
                    <p className="text-slate-400 max-w-2xl mb-3">
                      {profile.bio}
                    </p>
                  )}
                  <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500">
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>
                        Membre depuis {formatDate(new Date(profile.created_at))}
                      </span>
                    </div>
                    {profile.discord_tag && (
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>{profile.discord_tag}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-3">
                  {isOwnProfile ? (
                    <Link
                      href="/profile/edit"
                      className="px-6 py-2 rounded-lg glass-effect border border-indigo-500/50 hover:border-indigo-500 text-white font-medium transition-all flex items-center space-x-2"
                    >
                      <Edit className="h-4 w-4" />
                      <span>Éditer</span>
                    </Link>
                  ) : (
                    <button
                      onClick={() => setIsFollowing(!isFollowing)}
                      className={`px-6 py-2 rounded-lg font-medium transition-all ${
                        isFollowing
                          ? "glass-effect border border-slate-700 text-slate-300 hover:border-red-500 hover:text-red-400"
                          : "bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white shadow-lg"
                      }`}
                    >
                      {isFollowing ? "Ne plus suivre" : "Suivre"}
                    </button>
                  )}
                  <button className="p-2 rounded-lg glass-effect border border-slate-700 hover:border-slate-600 transition-all">
                    <Share2 className="h-5 w-5 text-slate-400" />
                  </button>
                  <button className="p-2 rounded-lg glass-effect border border-slate-700 hover:border-slate-600 transition-all">
                    <MoreVertical className="h-5 w-5 text-slate-400" />
                  </button>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
                <div className="glass-effect rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-white">
                    {profile.posts_count}
                  </div>
                  <div className="text-xs text-slate-500">Posts</div>
                </div>
                <div className="glass-effect rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-white">
                    {profile.followers_count}
                  </div>
                  <div className="text-xs text-slate-500">Followers</div>
                </div>
                <div className="glass-effect rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-white">
                    {profile.following_count}
                  </div>
                  <div className="text-xs text-slate-500">Following</div>
                </div>
                <div className="glass-effect rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-indigo-400">
                    {profile.wins_count}
                  </div>
                  <div className="text-xs text-slate-500">Victoires</div>
                </div>
                <div className="glass-effect rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-cyan-400">
                    {profile.games_played}
                  </div>
                  <div className="text-xs text-slate-500">Parties</div>
                </div>
              </div>

              {/* Social Links */}
              {(profile.twitch_url || profile.steam_url) && (
                <div className="flex items-center gap-3 mt-4">
                  {profile.twitch_url && (
                    <a
                      href={profile.twitch_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg glass-effect border border-slate-700 hover:border-purple-500 transition-all group"
                    >
                      <Twitch className="h-5 w-5 text-slate-400 group-hover:text-purple-400" />
                    </a>
                  )}
                  {profile.steam_url && (
                    <a
                      href={profile.steam_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg glass-effect border border-slate-700 hover:border-blue-500 transition-all group"
                    >
                      <svg
                        className="h-5 w-5 text-slate-400 group-hover:text-blue-400"
                        viewBox="0 0 24 24"
                        fill="currentColor"
                      >
                        <path d="M12 2a10 10 0 0 0-10 10 9.99 9.99 0 0 0 6.06 9.17l2.64-3.64a3.72 3.72 0 0 1-.7-.07 2.98 2.98 0 1 1 2.98-2.98c0 .05 0 .1-.01.15l3.64 2.64A10 10 0 0 0 12 2m5.5 11.5a2.5 2.5 0 1 0-2.5-2.5 2.5 2.5 0 0 0 2.5 2.5z" />
                      </svg>
                    </a>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
