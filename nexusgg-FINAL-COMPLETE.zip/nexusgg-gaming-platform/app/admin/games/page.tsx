import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin } from "@/lib/admin/admin-service";
import { getAllGames } from "@/lib/profile/profile-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import { Edit, Trash2, PlusCircle } from "lucide-react";

export default async function AdminGamesPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const games = await getAllGames();

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">
                Gestion des Jeux
              </h1>
              <p className="text-slate-400">{games.length} jeux disponibles</p>
            </div>
            <button className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-semibold flex items-center space-x-2">
              <PlusCircle className="h-5 w-5" />
              <span>Ajouter un jeu</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {games.map((game) => (
              <div
                key={game.id}
                className="glass-effect rounded-lg p-6 border border-slate-800/50 hover:border-indigo-500/30 transition-all"
              >
                {game.cover_image && (
                  <img
                    src={game.cover_image}
                    alt={game.name}
                    className="w-full h-32 object-cover rounded-lg mb-4"
                  />
                )}
                <h3 className="text-lg font-bold text-white mb-2">
                  {game.name}
                </h3>
                <div className="flex flex-wrap gap-1 mb-4">
                  {game.genre?.slice(0, 2).map((g: string, idx: number) => (
                    <span
                      key={idx}
                      className="text-xs px-2 py-1 rounded bg-slate-800/50 text-slate-400"
                    >
                      {g}
                    </span>
                  ))}
                </div>
                <div className="flex items-center space-x-2">
                  <button className="flex-1 px-4 py-2 rounded-lg glass-effect border border-slate-700 hover:border-indigo-500 text-sm text-white transition-all flex items-center justify-center space-x-2">
                    <Edit className="h-4 w-4" />
                    <span>Éditer</span>
                  </button>
                  <button className="px-4 py-2 rounded-lg glass-effect border border-red-500/30 hover:bg-red-500/20 text-sm text-red-400 transition-all">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
