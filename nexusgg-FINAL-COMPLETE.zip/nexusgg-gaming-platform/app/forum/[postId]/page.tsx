import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, MessageSquare } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PostCard from "@/components/forum/PostCard";
import CommentItem from "@/components/forum/CommentItem";
import CommentForm from "@/components/forum/CommentForm";
import { getPostById, getComments } from "@/lib/forum/forum-service";
import { createClient } from "@/lib/auth/supabase-server";

interface PostPageProps {
  params: {
    postId: string;
  };
}

export default async function PostPage({ params }: PostPageProps) {
  const { postId } = params;
  const post = await getPostById(postId);

  if (!post) {
    notFound();
  }

  const comments = await getComments(postId);
  
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-24 pb-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            href="/forum"
            className="inline-flex items-center space-x-2 text-slate-400 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Retour au forum</span>
          </Link>

          {/* Post */}
          <PostCard post={post} currentUserId={user?.id} />

          {/* Comments Section */}
          <div className="mt-8">
            <div className="flex items-center space-x-2 mb-6">
              <MessageSquare className="h-5 w-5 text-slate-400" />
              <h2 className="text-2xl font-bold text-white">
                {comments.length} Commentaire{comments.length !== 1 ? 's' : ''}
              </h2>
            </div>

            {/* Add Comment Form */}
            {user ? (
              <div className="mb-8">
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <CommentForm postId={postId} />
                </div>
              </div>
            ) : (
              <div className="mb-8 text-center py-8 glass-effect rounded-lg border border-slate-800/50">
                <p className="text-slate-400 mb-4">
                  Connecte-toi pour commenter
                </p>
                <Link
                  href="/login"
                  className="inline-block px-6 py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-medium"
                >
                  Connexion
                </Link>
              </div>
            )}

            {/* Comments List */}
            {comments.length === 0 ? (
              <div className="text-center py-12 glass-effect rounded-lg border border-slate-800/50">
                <MessageSquare className="h-12 w-12 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400">
                  Pas encore de commentaires. Sois le premier !
                </p>
              </div>
            ) : (
              <div className="space-y-2">
                {comments.map((comment) => (
                  <CommentItem key={comment.id} comment={comment} postId={postId} currentUserId={user?.id} />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
