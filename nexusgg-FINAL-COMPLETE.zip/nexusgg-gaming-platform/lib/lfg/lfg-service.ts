import { createClient } from '@/lib/auth/supabase-server'

export interface LFGPost {
  id: string
  author_id: string
  author?: any
  game_id: string
  game?: any
  title: string
  description: string
  platform: 'PC' | 'PS5' | 'Xbox' | 'Switch' | 'Mobile'
  players_needed: number
  current_players: number
  scheduled_time?: string
  voice_required: boolean
  skill_level: 'Casual' | 'Competitive' | 'Any'
  rank_requirement?: string
  status: 'open' | 'full' | 'closed' | 'expired'
  tags: string[]
  region?: string
  created_at: string
  updated_at: string
  expires_at?: string
  members?: any[]
  applications?: any[]
  user_application?: any
}

export interface LFGApplication {
  id: string
  lfg_post_id: string
  user_id: string
  user?: any
  message?: string
  status: 'pending' | 'accepted' | 'declined'
  created_at: string
}

export async function getLFGPosts(filters: {
  gameId?: string
  platform?: string
  skillLevel?: string
  status?: string
  region?: string
  search?: string
} = {}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  let query = supabase
    .from('lfg_posts')
    .select(
      `
      *,
      author:profiles!lfg_posts_author_id_fkey(*),
      game:games(*),
      members:lfg_members(count),
      applications:lfg_applications(
        id,
        user_id,
        status
      )
    `
    )
    .order('created_at', { ascending: false })

  if (filters.gameId) {
    query = query.eq('game_id', filters.gameId)
  }

  if (filters.platform) {
    query = query.eq('platform', filters.platform)
  }

  if (filters.skillLevel && filters.skillLevel !== 'Any') {
    query = query.or(`skill_level.eq.${filters.skillLevel},skill_level.eq.Any`)
  }

  if (filters.status) {
    query = query.eq('status', filters.status)
  } else {
    query = query.in('status', ['open', 'full'])
  }

  if (filters.region) {
    query = query.eq('region', filters.region)
  }

  if (filters.search) {
    query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%`)
  }

  const { data: posts, error } = await query

  if (error) throw error

  // Add user application status
  const postsWithUserApp = posts?.map((post) => ({
    ...post,
    user_application: user
      ? post.applications?.find((app: any) => app.user_id === user.id)
      : null,
  }))

  return postsWithUserApp || []
}

export async function getLFGById(lfgId: string) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const { data: lfg, error } = await supabase
    .from('lfg_posts')
    .select(
      `
      *,
      author:profiles!lfg_posts_author_id_fkey(*),
      game:games(*),
      members:lfg_members(
        id,
        user:profiles(*)
      ),
      applications:lfg_applications(
        id,
        user_id,
        message,
        status,
        created_at,
        user:profiles(*)
      )
    `
    )
    .eq('id', lfgId)
    .single()

  if (error || !lfg) return null

  return {
    ...lfg,
    user_application: user
      ? lfg.applications?.find((app: any) => app.user_id === user.id)
      : null,
  }
}

export async function createLFGPost(data: {
  gameId: string
  title: string
  description: string
  platform: string
  playersNeeded: number
  scheduledTime?: string
  voiceRequired: boolean
  skillLevel: string
  rankRequirement?: string
  tags?: string[]
  region?: string
  expiresAt?: string
}) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) throw new Error('Unauthorized')

  const { data: lfg, error } = await supabase
    .from('lfg_posts')
    .insert({
      author_id: user.id,
      game_id: data.gameId,
      title: data.title,
      description: data.description,
      platform: data.platform,
      players_needed: data.playersNeeded,
      scheduled_time: data.scheduledTime,
      voice_required: data.voiceRequired,
      skill_level: data.skillLevel,
      rank_requirement: data.rankRequirement,
      tags: data.tags || [],
      region: data.region,
      expires_at: data.expiresAt,
    })
    .select()
    .single()

  if (error) throw error

  return lfg
}

export async function updateLFGPost(lfgId: string, data: any) {
  const supabase = await createClient()

  const { data: lfg, error } = await supabase
    .from('lfg_posts')
    .update({
      ...data,
      updated_at: new Date().toISOString(),
    })
    .eq('id', lfgId)
    .select()
    .single()

  if (error) throw error

  return lfg
}

export async function closeLFGPost(lfgId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('lfg_posts')
    .update({ status: 'closed' })
    .eq('id', lfgId)

  if (error) throw error
}

export async function deleteLFGPost(lfgId: string) {
  const supabase = await createClient()

  const { error } = await supabase.from('lfg_posts').delete().eq('id', lfgId)

  if (error) throw error
}

export async function applyToLFG(lfgId: string, message?: string) {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) throw new Error('Unauthorized')

  const { data: application, error } = await supabase
    .from('lfg_applications')
    .insert({
      lfg_post_id: lfgId,
      user_id: user.id,
      message,
    })
    .select()
    .single()

  if (error) throw error

  return application
}

export async function cancelApplication(applicationId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('lfg_applications')
    .delete()
    .eq('id', applicationId)

  if (error) throw error
}

export async function acceptApplication(applicationId: string) {
  const supabase = await createClient()

  // Get application details
  const { data: application } = await supabase
    .from('lfg_applications')
    .select('*')
    .eq('id', applicationId)
    .single()

  if (!application) throw new Error('Application not found')

  // Update application status
  await supabase
    .from('lfg_applications')
    .update({ status: 'accepted' })
    .eq('id', applicationId)

  // Add to members
  const { error: memberError } = await supabase.from('lfg_members').insert({
    lfg_post_id: application.lfg_post_id,
    user_id: application.user_id,
  })

  if (memberError) throw memberError
}

export async function declineApplication(applicationId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('lfg_applications')
    .update({ status: 'declined' })
    .eq('id', applicationId)

  if (error) throw error
}

export async function removeMember(lfgId: string, userId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('lfg_members')
    .delete()
    .eq('lfg_post_id', lfgId)
    .eq('user_id', userId)

  if (error) throw error
}

export async function getMyLFGPosts() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  const { data: posts } = await supabase
    .from('lfg_posts')
    .select(
      `
      *,
      game:games(*),
      members:lfg_members(count),
      applications:lfg_applications(count)
    `
    )
    .eq('author_id', user.id)
    .order('created_at', { ascending: false })

  return posts || []
}

export async function getMyApplications() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return []

  const { data: applications } = await supabase
    .from('lfg_applications')
    .select(
      `
      *,
      lfg_post:lfg_posts(
        *,
        game:games(*),
        author:profiles(*)
      )
    `
    )
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  return applications || []
}
