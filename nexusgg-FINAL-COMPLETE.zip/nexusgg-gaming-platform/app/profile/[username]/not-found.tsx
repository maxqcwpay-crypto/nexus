import Link from "next/link";
import { UserX, Home } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export default function ProfileNotFound() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-1 flex items-center justify-center px-4 py-24">
        <div className="text-center max-w-md">
          <div className="mb-8">
            <div className="mx-auto h-24 w-24 rounded-full bg-gradient-to-br from-red-500/20 to-orange-500/20 flex items-center justify-center mb-6">
              <UserX className="h-12 w-12 text-red-400" />
            </div>
            <h1 className="text-4xl font-bold text-white mb-4">
              Profil introuvable
            </h1>
            <p className="text-slate-400 mb-8">
              Ce joueur n&apos;existe pas ou a peut-être changé de pseudo.
            </p>
          </div>

          <div className="space-y-3">
            <Link
              href="/"
              className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold transition-all duration-300 shadow-lg hover:shadow-indigo-500/50"
            >
              <Home className="h-5 w-5" />
              <span>Retour à l&apos;accueil</span>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
