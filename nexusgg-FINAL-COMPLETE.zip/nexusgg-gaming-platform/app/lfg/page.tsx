import Link from "next/link";
import { PlusCircle, Filter } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import LFGCard from "@/components/lfg/LFGCard";
import { getLFGPosts } from "@/lib/lfg/lfg-service";
import { getAllGames } from "@/lib/profile/profile-service";
import { createClient } from "@/lib/auth/supabase-server";

interface LFGPageProps {
  searchParams: {
    game?: string;
    platform?: string;
    skill?: string;
    region?: string;
    status?: string;
  };
}

const platforms = ["PC", "PS5", "Xbox", "Switch", "Mobile"];
const skillLevels = ["Casual", "Competitive", "Any"];
const regions = ["EU West", "EU East", "NA West", "NA East", "Asia", "OCE"];

export default async function LFGPage({ searchParams }: LFGPageProps) {
  const { game, platform, skill, region, status } = searchParams;

  const lfgPosts = await getLFGPosts({
    gameId: game,
    platform,
    skillLevel: skill,
    region,
    status: status || "open",
  });

  const games = await getAllGames();

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-4xl font-bold neon-text mb-2">
                Looking For Group
              </h1>
              <p className="text-slate-400">
                Trouve des joueurs pour tes sessions gaming
              </p>
            </div>
            {user && (
              <Link
                href="/lfg/create"
                className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold transition-all duration-300 shadow-lg hover:shadow-indigo-500/50"
              >
                <PlusCircle className="h-5 w-5" />
                <span>Créer une demande</span>
              </Link>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar Filters */}
            <aside className="lg:col-span-1">
              <div className="space-y-4">
                {/* Status Filter */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3 flex items-center space-x-2">
                    <Filter className="h-4 w-4" />
                    <span>Statut</span>
                  </h3>
                  <div className="space-y-2">
                    {[
                      { value: "open", label: "Ouverts" },
                      { value: "full", label: "Complets" },
                      { value: "", label: "Tous" },
                    ].map((s) => (
                      <Link
                        key={s.value}
                        href={`/lfg?status=${s.value}${game ? `&game=${game}` : ""}${platform ? `&platform=${platform}` : ""}`}
                        className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                          status === s.value || (!status && !s.value)
                            ? "bg-indigo-500/20 text-indigo-400"
                            : "hover:bg-slate-800/50 text-slate-400"
                        }`}
                      >
                        {s.label}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Game Filter */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3">Jeu</h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    <Link
                      href="/lfg"
                      className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                        !game
                          ? "bg-indigo-500/20 text-indigo-400"
                          : "hover:bg-slate-800/50 text-slate-400"
                      }`}
                    >
                      Tous les jeux
                    </Link>
                    {games.map((g) => (
                      <Link
                        key={g.id}
                        href={`/lfg?game=${g.id}`}
                        className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                          game === g.id
                            ? "bg-indigo-500/20 text-indigo-400"
                            : "hover:bg-slate-800/50 text-slate-400"
                        }`}
                      >
                        {g.name}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Platform Filter */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3">Plateforme</h3>
                  <div className="space-y-2">
                    <Link
                      href={`/lfg${game ? `?game=${game}` : ""}`}
                      className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                        !platform
                          ? "bg-indigo-500/20 text-indigo-400"
                          : "hover:bg-slate-800/50 text-slate-400"
                      }`}
                    >
                      Toutes
                    </Link>
                    {platforms.map((p) => (
                      <Link
                        key={p}
                        href={`/lfg?platform=${p}${game ? `&game=${game}` : ""}`}
                        className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                          platform === p
                            ? "bg-indigo-500/20 text-indigo-400"
                            : "hover:bg-slate-800/50 text-slate-400"
                        }`}
                      >
                        {p}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Skill Level Filter */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3">Niveau</h3>
                  <div className="space-y-2">
                    {skillLevels.map((s) => (
                      <Link
                        key={s}
                        href={`/lfg?skill=${s}${game ? `&game=${game}` : ""}${platform ? `&platform=${platform}` : ""}`}
                        className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                          skill === s
                            ? "bg-indigo-500/20 text-indigo-400"
                            : "hover:bg-slate-800/50 text-slate-400"
                        }`}
                      >
                        {s}
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </aside>

            {/* LFG Posts Grid */}
            <div className="lg:col-span-3">
              {lfgPosts.length === 0 ? (
                <div className="card-gaming text-center py-12">
                  <p className="text-slate-400 mb-4">
                    Aucune demande LFG pour le moment
                  </p>
                  {user && (
                    <Link
                      href="/lfg/create"
                      className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-semibold"
                    >
                      <PlusCircle className="h-5 w-5" />
                      <span>Créer la première demande</span>
                    </Link>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {lfgPosts.map((lfg) => (
                    <LFGCard key={lfg.id} lfg={lfg} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
