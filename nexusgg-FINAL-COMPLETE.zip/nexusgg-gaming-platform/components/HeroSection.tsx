"use client";

import Link from "next/link";
import { ArrowRight, Gamepad2, Users, Trophy } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1542751371-adc38448a05e?q=80&w=2070')",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/70 via-slate-950/80 to-slate-950" />
        
        {/* Animated grid overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(168,85,247,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.05)_1px,transparent_1px)] bg-[size:64px_64px]" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        {/* Badge */}
        <div className="inline-flex items-center space-x-2 px-4 py-2 rounded-full glass-effect border border-indigo-500/30 mb-8 animate-float">
          <div className="h-2 w-2 bg-cyan-400 rounded-full animate-pulse" />
          <span className="text-sm font-medium text-cyan-400">
            +12,450 joueurs en ligne
          </span>
        </div>

        {/* Main Heading */}
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          Rejoins la{" "}
          <span className="neon-text">Communauté Gaming</span>
          <br />
          Ultime
        </h1>

        {/* Subheading */}
        <p className="text-xl md:text-2xl text-slate-400 mb-12 max-w-3xl mx-auto">
          Trouve des équipes, partage tes exploits et connecte-toi avec des
          milliers de joueurs passionnés.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <Link
            href="/signup"
            className="group px-8 py-4 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-bold text-lg transition-all duration-300 shadow-lg hover:shadow-indigo-500/50 flex items-center space-x-2 glow-effect"
          >
            <span>Rejoindre l&apos;Escouade</span>
            <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
          </Link>
          <Link
            href="/explore"
            className="px-8 py-4 rounded-lg glass-effect border border-slate-700 hover:border-indigo-500/50 text-white font-bold text-lg transition-all duration-300"
          >
            Explorer
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          <div className="card-gaming">
            <Gamepad2 className="h-8 w-8 text-indigo-500 mx-auto mb-3" />
            <div className="text-3xl font-bold text-white mb-1">50+</div>
            <div className="text-sm text-slate-400">Jeux supportés</div>
          </div>
          <div className="card-gaming">
            <Users className="h-8 w-8 text-cyan-500 mx-auto mb-3" />
            <div className="text-3xl font-bold text-white mb-1">100K+</div>
            <div className="text-sm text-slate-400">Joueurs actifs</div>
          </div>
          <div className="card-gaming">
            <Trophy className="h-8 w-8 text-purple-500 mx-auto mb-3" />
            <div className="text-3xl font-bold text-white mb-1">5K+</div>
            <div className="text-sm text-slate-400">Équipes formées</div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="h-12 w-8 rounded-full border-2 border-slate-600 flex items-start justify-center p-2">
          <div className="h-2 w-2 bg-indigo-500 rounded-full animate-pulse" />
        </div>
      </div>
    </section>
  );
}
