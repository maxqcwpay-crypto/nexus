"use client";

import Link from "next/link";
import {
  Users,
  Clock,
  Mic,
  Calendar,
  MapPin,
  CheckCircle,
  XCircle,
  Loader2,
} from "lucide-react";
import { LFGPost } from "@/lib/lfg/lfg-service";
import { formatRelativeTime } from "@/lib/utils";
import { useState } from "react";
import { createClient } from "@/lib/auth/supabase-client";
import { useRouter } from "next/navigation";

interface LFGCardProps {
  lfg: LFGPost;
  showActions?: boolean;
}

const platformIcons: Record<string, string> = {
  PC: "💻",
  PS5: "🎮",
  Xbox: "🎮",
  Switch: "🕹️",
  Mobile: "📱",
};

const statusConfig = {
  open: { color: "text-green-400 bg-green-500/20", label: "Ouvert" },
  full: { color: "text-orange-400 bg-orange-500/20", label: "Complet" },
  closed: { color: "text-red-400 bg-red-500/20", label: "Fermé" },
  expired: { color: "text-slate-400 bg-slate-500/20", label: "Expiré" },
};

export default function LFGCard({ lfg, showActions = true }: LFGCardProps) {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [hasApplied, setHasApplied] = useState(!!lfg.user_application);

  const handleApply = async () => {
    setIsLoading(true);
    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      if (hasApplied && lfg.user_application) {
        // Cancel application
        await supabase
          .from("lfg_applications")
          .delete()
          .eq("id", lfg.user_application.id);
        setHasApplied(false);
      } else {
        // Apply
        await supabase.from("lfg_applications").insert({
          lfg_post_id: lfg.id,
          user_id: user.id,
        });
        setHasApplied(true);
      }

      router.refresh();
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const spotsLeft = lfg.players_needed - lfg.current_players;
  const statusStyle = statusConfig[lfg.status];

  return (
    <div className="card-gaming group">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            {lfg.game && (
              <Link
                href={`/lfg?game=${lfg.game.id}`}
                className="text-xs px-2 py-1 rounded bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30"
              >
                {lfg.game.name}
              </Link>
            )}
            <span className="text-xl">{platformIcons[lfg.platform]}</span>
            <span className="text-xs text-slate-500">{lfg.platform}</span>
          </div>

          <Link href={`/lfg/${lfg.id}`}>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
              {lfg.title}
            </h3>
          </Link>

          <p className="text-slate-400 text-sm mb-3 line-clamp-2">
            {lfg.description}
          </p>

          <div className="flex items-center gap-4 text-sm text-slate-500 mb-3">
            <div className="flex items-center space-x-1">
              <Users className="h-4 w-4" />
              <span>
                {lfg.current_players}/{lfg.players_needed}
              </span>
            </div>

            {lfg.voice_required && (
              <div className="flex items-center space-x-1 text-cyan-400">
                <Mic className="h-4 w-4" />
                <span>Micro requis</span>
              </div>
            )}

            <div className="flex items-center space-x-1">
              <span className="px-2 py-0.5 rounded bg-slate-800/50">
                {lfg.skill_level}
              </span>
            </div>

            {lfg.region && (
              <div className="flex items-center space-x-1">
                <MapPin className="h-4 w-4" />
                <span>{lfg.region}</span>
              </div>
            )}
          </div>

          {lfg.scheduled_time && (
            <div className="flex items-center space-x-2 text-sm text-slate-400 mb-3">
              <Calendar className="h-4 w-4" />
              <span>
                {new Date(lfg.scheduled_time).toLocaleString("fr-FR", {
                  dateStyle: "short",
                  timeStyle: "short",
                })}
              </span>
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <img
                src={
                  lfg.author?.avatar_url ||
                  `https://api.dicebear.com/7.x/avataaars/svg?seed=${lfg.author?.username}`
                }
                alt={lfg.author?.username}
                className="h-6 w-6 rounded-full"
              />
              <Link
                href={`/profile/${lfg.author?.username}`}
                className="text-sm text-slate-400 hover:text-white"
              >
                {lfg.author?.username}
              </Link>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-500">
                {formatRelativeTime(new Date(lfg.created_at))}
              </span>
            </div>

            <span className={`text-xs px-2 py-1 rounded ${statusStyle.color}`}>
              {statusStyle.label}
            </span>
          </div>
        </div>
      </div>

      {showActions && lfg.status === "open" && (
        <div className="pt-4 border-t border-slate-800/50">
          <div className="flex items-center justify-between">
            <div className="text-sm">
              {spotsLeft > 0 ? (
                <span className="text-green-400 font-medium">
                  {spotsLeft} place{spotsLeft > 1 ? "s" : ""} restante
                  {spotsLeft > 1 ? "s" : ""}
                </span>
              ) : (
                <span className="text-orange-400 font-medium">Complet</span>
              )}
            </div>

            {spotsLeft > 0 && (
              <button
                onClick={handleApply}
                disabled={isLoading}
                className={`px-4 py-2 rounded-lg font-medium transition-all flex items-center space-x-2 ${
                  hasApplied
                    ? "glass-effect border border-red-500/30 text-red-400 hover:bg-red-500/10"
                    : "bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white shadow-lg"
                }`}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>...</span>
                  </>
                ) : hasApplied ? (
                  <>
                    <XCircle className="h-4 w-4" />
                    <span>Annuler</span>
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4" />
                    <span>Postuler</span>
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      )}

      {lfg.tags && lfg.tags.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-slate-800/50">
          {lfg.tags.map((tag, idx) => (
            <span
              key={idx}
              className="text-xs px-2 py-1 rounded bg-slate-800/50 text-slate-400"
            >
              #{tag}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
