import { Gamepad2, Zap, Shield, Users } from "lucide-react";
import Link from "next/link";
import SignupForm from "@/components/auth/SignupForm";

export default function SignupPage() {
  const features = [
    {
      icon: Zap,
      title: "Trouve des équipes",
      description: "Rejoins ou crée des équipes pour tes jeux favoris",
    },
    {
      icon: Shield,
      title: "Partage tes exploits",
      description: "Montre tes meilleurs clips et moments épiques",
    },
    {
      icon: Users,
      title: "Communauté active",
      description: "Connecte-toi avec 100K+ joueurs passionnés",
    },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(168,85,247,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.03)_1px,transparent_1px)] bg-[size:64px_64px]" />
        <div className="absolute top-1/4 -left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 -right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-6xl flex flex-col lg:flex-row items-center gap-12">
        {/* Left Side - Branding */}
        <div className="flex-1 text-center lg:text-left">
          <Link
            href="/"
            className="inline-flex items-center space-x-3 mb-8 group"
          >
            <Gamepad2 className="h-10 w-10 text-indigo-500 group-hover:text-cyan-400 transition-colors" />
            <span className="text-3xl font-bold neon-text">NexusGG</span>
          </Link>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Rejoins
            <br />
            <span className="neon-text">l&apos;escouade</span>
          </h1>

          <p className="text-xl text-slate-400 mb-8 max-w-lg">
            Crée ton compte et accède à la plateforme gaming ultime. Trouve des
            équipes, partage tes exploits et domine le classement.
          </p>

          {/* Features */}
          <div className="space-y-4 max-w-md">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="glass-effect rounded-lg p-4 flex items-start space-x-4"
                >
                  <div className="flex-shrink-0">
                    <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                      <Icon className="h-5 w-5 text-white" />
                    </div>
                  </div>
                  <div>
                    <div className="font-semibold text-white mb-1">
                      {feature.title}
                    </div>
                    <div className="text-sm text-slate-400">
                      {feature.description}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side - Signup Form */}
        <div className="flex-1 w-full max-w-md">
          <SignupForm />
        </div>
      </div>
    </div>
  );
}
