import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin, getReports } from "@/lib/admin/admin-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import { CheckCircle, XCircle, Eye, AlertCircle } from "lucide-react";
import { formatRelativeTime } from "@/lib/utils";
import Link from "next/link";

async function updateReportStatus(reportId: string, status: string) {
  "use server";
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    throw new Error("Unauthorized");
  }

  await supabase
    .from("reports")
    .update({
      status,
      reviewed_by: user.id,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", reportId);

  await supabase.from("admin_logs").insert({
    admin_id: user.id,
    action: "review_report",
    target_type: "report",
    target_id: reportId,
    details: { status },
  });
}

export default async function AdminReportsPage({
  searchParams,
}: {
  searchParams: { status?: string };
}) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const status = searchParams.status || "pending";
  const reports = await getReports(status);

  const statusOptions = [
    { value: "pending", label: "En attente", count: reports.filter((r: any) => r.status === "pending").length },
    { value: "reviewed", label: "Examinés", count: 0 },
    { value: "resolved", label: "Résolus", count: 0 },
    { value: "dismissed", label: "Rejetés", count: 0 },
    { value: "all", label: "Tous", count: reports.length },
  ];

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              Gestion des Reports
            </h1>
            <p className="text-slate-400">{reports.length} signalements</p>
          </div>

          {/* Status Tabs */}
          <div className="flex space-x-2 mb-6 overflow-x-auto">
            {statusOptions.map((opt) => (
              <Link
                key={opt.value}
                href={`/admin/reports?status=${opt.value}`}
                className={`px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
                  status === opt.value
                    ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                    : "glass-effect text-slate-400 hover:text-white"
                }`}
              >
                {opt.label}
                {opt.count > 0 && (
                  <span className="ml-2 px-2 py-0.5 rounded-full bg-slate-800 text-xs">
                    {opt.count}
                  </span>
                )}
              </Link>
            ))}
          </div>

          {/* Reports List */}
          {reports.length === 0 ? (
            <div className="glass-effect rounded-lg p-12 text-center border border-slate-800/50">
              <AlertCircle className="h-12 w-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">Aucun signalement {status !== "all" && `"${statusOptions.find(o => o.value === status)?.label}"`}</p>
            </div>
          ) : (
            <div className="space-y-4">
              {reports.map((report: any) => (
                <div
                  key={report.id}
                  className="glass-effect rounded-lg p-6 border border-slate-800/50"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className="px-3 py-1 rounded bg-red-500/20 text-red-400 text-sm font-medium">
                          {report.target_type}
                        </span>
                        <span className="text-sm text-slate-500">
                          Signalé par{" "}
                          <span className="text-slate-300">
                            {report.reporter?.username || "Utilisateur supprimé"}
                          </span>
                        </span>
                        <span className="text-slate-600">•</span>
                        <span className="text-sm text-slate-500">
                          {formatRelativeTime(new Date(report.created_at))}
                        </span>
                      </div>

                      <h3 className="font-semibold text-white mb-2">
                        Raison : {report.reason}
                      </h3>

                      {report.description && (
                        <p className="text-slate-400 text-sm mb-3">
                          {report.description}
                        </p>
                      )}

                      {report.reviewed_by && (
                        <div className="text-xs text-slate-500">
                          Examiné par {report.reviewer?.username} le{" "}
                          {formatRelativeTime(new Date(report.reviewed_at))}
                        </div>
                      )}
                    </div>

                    <div className={`px-3 py-1 rounded text-sm font-medium ${
                      report.status === "pending"
                        ? "bg-yellow-500/20 text-yellow-400"
                        : report.status === "resolved"
                        ? "bg-green-500/20 text-green-400"
                        : report.status === "dismissed"
                        ? "bg-slate-500/20 text-slate-400"
                        : "bg-blue-500/20 text-blue-400"
                    }`}>
                      {report.status === "pending"
                        ? "En attente"
                        : report.status === "resolved"
                        ? "Résolu"
                        : report.status === "dismissed"
                        ? "Rejeté"
                        : "Examiné"}
                    </div>
                  </div>

                  {/* Actions */}
                  {report.status === "pending" && (
                    <div className="flex items-center space-x-2 pt-4 border-t border-slate-800/50">
                      <Link
                        href={`/${report.target_type === "post" ? "forum" : "profile"}/${report.target_id}`}
                        className="px-4 py-2 rounded-lg glass-effect border border-slate-700 hover:border-indigo-500 text-sm text-white transition-all flex items-center space-x-2"
                        target="_blank"
                      >
                        <Eye className="h-4 w-4" />
                        <span>Voir le contenu</span>
                      </Link>

                      <form
                        action={async () => {
                          "use server";
                          await updateReportStatus(report.id, "resolved");
                        }}
                      >
                        <button className="px-4 py-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 text-green-400 text-sm transition-all flex items-center space-x-2">
                          <CheckCircle className="h-4 w-4" />
                          <span>Marquer résolu</span>
                        </button>
                      </form>

                      <form
                        action={async () => {
                          "use server";
                          await updateReportStatus(report.id, "dismissed");
                        }}
                      >
                        <button className="px-4 py-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 text-sm transition-all flex items-center space-x-2">
                          <XCircle className="h-4 w-4" />
                          <span>Rejeter</span>
                        </button>
                      </form>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
