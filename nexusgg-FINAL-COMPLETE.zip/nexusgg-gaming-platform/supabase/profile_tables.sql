-- Additional tables for user profiles

-- Games catalog
create table if not exists games (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  slug text unique not null,
  cover_image text,
  genre text[] default '{}',
  platform text[] default '{}',
  created_at timestamp with time zone default now()
);

-- User favorite games (many-to-many)
create table if not exists user_favorite_games (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade not null,
  game_id uuid references games(id) on delete cascade not null,
  added_at timestamp with time zone default now(),
  unique(user_id, game_id)
);

-- Badges
create table if not exists badges (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  icon text not null,
  description text,
  rarity text check (rarity in ('common', 'rare', 'epic', 'legendary')) default 'common',
  created_at timestamp with time zone default now()
);

-- User badges (many-to-many)
create table if not exists user_badges (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade not null,
  badge_id uuid references badges(id) on delete cascade not null,
  earned_at timestamp with time zone default now(),
  unique(user_id, badge_id)
);

-- Enable RLS
alter table games enable row level security;
alter table user_favorite_games enable row level security;
alter table badges enable row level security;
alter table user_badges enable row level security;

-- Policies for games (everyone can read)
create policy "Games are viewable by everyone"
  on games for select
  using (true);

-- Policies for user_favorite_games
create policy "User favorite games are viewable by everyone"
  on user_favorite_games for select
  using (true);

create policy "Users can manage their own favorite games"
  on user_favorite_games for all
  using (auth.uid() = user_id);

-- Policies for badges (everyone can read)
create policy "Badges are viewable by everyone"
  on badges for select
  using (true);

-- Policies for user_badges
create policy "User badges are viewable by everyone"
  on user_badges for select
  using (true);

create policy "Only system can assign badges"
  on user_badges for insert
  with check (false); -- Only through functions/triggers

-- Insert some default games
insert into games (name, slug, cover_image, genre, platform) values
  ('Valorant', 'valorant', 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400', '{FPS,Tactical}', '{PC}'),
  ('League of Legends', 'league-of-legends', 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400', '{MOBA,Strategy}', '{PC}'),
  ('Counter-Strike 2', 'cs2', 'https://images.unsplash.com/photo-1560419015-7c427e8ae5ba?w=400', '{FPS,Competitive}', '{PC}'),
  ('Fortnite', 'fortnite', 'https://images.unsplash.com/photo-1589241062272-c0a000072d3e?w=400', '{Battle Royale,Shooter}', '{PC,PS5,Xbox,Switch}'),
  ('Apex Legends', 'apex-legends', 'https://images.unsplash.com/photo-1551954354-8b7713b0d5e4?w=400', '{Battle Royale,FPS}', '{PC,PS5,Xbox}'),
  ('Overwatch 2', 'overwatch-2', 'https://images.unsplash.com/photo-1542751110-97427bbecf20?w=400', '{FPS,Hero Shooter}', '{PC,PS5,Xbox,Switch}'),
  ('Rocket League', 'rocket-league', 'https://images.unsplash.com/photo-1556056504-5c7696c4c28d?w=400', '{Sports,Racing}', '{PC,PS5,Xbox,Switch}'),
  ('Minecraft', 'minecraft', 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400', '{Sandbox,Survival}', '{PC,PS5,Xbox,Switch,Mobile}'),
  ('Dota 2', 'dota-2', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400', '{MOBA,Strategy}', '{PC}'),
  ('Rainbow Six Siege', 'rainbow-six-siege', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400', '{FPS,Tactical}', '{PC,PS5,Xbox}')
on conflict (slug) do nothing;

-- Insert some default badges
insert into badges (name, icon, description, rarity) values
  ('Rookie', 'user-plus', 'Bienvenue dans la communauté !', 'common'),
  ('First Win', 'trophy', 'Première victoire partagée', 'common'),
  ('Team Player', 'users', 'A rejoint 5 équipes', 'rare'),
  ('Veteran', 'shield', 'Membre depuis 1 an', 'epic'),
  ('Legend', 'crown', 'Statut légendaire atteint', 'legendary'),
  ('Content Creator', 'video', 'A partagé 10 clips', 'rare'),
  ('Community Helper', 'heart', 'A aidé 50 joueurs', 'epic'),
  ('Tournament Winner', 'award', 'Victoire en tournoi', 'legendary')
on conflict do nothing;

-- Function to award rookie badge on signup
create or replace function public.award_rookie_badge()
returns trigger as $$
begin
  insert into public.user_badges (user_id, badge_id)
  select new.id, id from public.badges where name = 'Rookie'
  on conflict do nothing;
  return new;
end;
$$ language plpgsql security definer;

-- Trigger to award rookie badge
drop trigger if exists on_profile_created_award_badge on profiles;
create trigger on_profile_created_award_badge
  after insert on profiles
  for each row execute procedure public.award_rookie_badge();

-- Add stats columns to profiles
alter table profiles add column if not exists posts_count integer default 0;
alter table profiles add column if not exists followers_count integer default 0;
alter table profiles add column if not exists following_count integer default 0;
alter table profiles add column if not exists wins_count integer default 0;
alter table profiles add column if not exists games_played integer default 0;
