import { createClient } from '@/lib/auth/supabase-server'
import { User as SupabaseUser } from '@supabase/supabase-js'

export interface UserProfile {
  id: string
  username: string
  avatar_url?: string
  bio?: string
  rank: string
  twitch_url?: string
  steam_url?: string
  discord_tag?: string
  created_at: string
  posts_count: number
  followers_count: number
  following_count: number
  wins_count: number
  games_played: number
  favorite_games?: any[]
  badges?: any[]
}

export async function getProfileByUsername(username: string): Promise<UserProfile | null> {
  const supabase = await createClient()
  
  const { data: profile, error } = await supabase
    .from('profiles')
    .select(`
      *,
      favorite_games:user_favorite_games(
        game:games(*)
      ),
      badges:user_badges(
        badge:badges(*)
      )
    `)
    .eq('username', username)
    .single()

  if (error || !profile) {
    return null
  }

  return profile
}

export async function getProfileById(userId: string): Promise<UserProfile | null> {
  const supabase = await createClient()
  
  const { data: profile, error } = await supabase
    .from('profiles')
    .select(`
      *,
      favorite_games:user_favorite_games(
        game:games(*)
      ),
      badges:user_badges(
        badge:badges(*)
      )
    `)
    .eq('id', userId)
    .single()

  if (error || !profile) {
    return null
  }

  return profile
}

export async function updateProfile(userId: string, updates: Partial<UserProfile>) {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('profiles')
    .update({
      ...updates,
      updated_at: new Date().toISOString(),
    })
    .eq('id', userId)
    .select()
    .single()

  if (error) {
    throw error
  }

  return data
}

export async function uploadAvatar(userId: string, file: File): Promise<string> {
  const supabase = await createClient()
  
  // Generate unique filename
  const fileExt = file.name.split('.').pop()
  const fileName = `${userId}-${Date.now()}.${fileExt}`
  const filePath = `avatars/${fileName}`

  // Upload file
  const { error: uploadError } = await supabase.storage
    .from('avatars')
    .upload(filePath, file, {
      cacheControl: '3600',
      upsert: true,
    })

  if (uploadError) {
    throw uploadError
  }

  // Get public URL
  const { data } = supabase.storage
    .from('avatars')
    .getPublicUrl(filePath)

  return data.publicUrl
}

export async function getAllGames() {
  const supabase = await createClient()
  
  const { data: games, error } = await supabase
    .from('games')
    .select('*')
    .order('name')

  if (error) {
    throw error
  }

  return games || []
}

export async function addFavoriteGame(userId: string, gameId: string) {
  const supabase = await createClient()
  
  const { error } = await supabase
    .from('user_favorite_games')
    .insert({ user_id: userId, game_id: gameId })

  if (error) {
    throw error
  }
}

export async function removeFavoriteGame(userId: string, gameId: string) {
  const supabase = await createClient()
  
  const { error } = await supabase
    .from('user_favorite_games')
    .delete()
    .eq('user_id', userId)
    .eq('game_id', gameId)

  if (error) {
    throw error
  }
}
