# 🔐 Configuration Supabase - Guide Complet

## 📝 Étape 1 : Créer un Projet Supabase

1. Va sur [supabase.com](https://supabase.com)
2. Crée un compte gratuit
3. Clique sur "New Project"
4. Remplis les informations :
   - **Project Name** : `nexusgg` (ou ton choix)
   - **Database Password** : Crée un mot de passe fort (garde-le précieusement)
   - **Region** : Choisis la région la plus proche (ex: `eu-west-1` pour l'Europe)
5. Clique sur "Create new project" et attends 2-3 minutes

---

## 🔑 Étape 2 : Récupérer les Clés API

1. Dans ton projet Supabase, va dans **Settings** (icône engrenage en bas à gauche)
2. Clique sur **API** dans le menu
3. Tu verras deux informations importantes :
   - **Project URL** : `https://xxxxx.supabase.co`
   - **anon public** (clé API publique)

4. Copie ces valeurs

---

## 📄 Étape 3 : Configurer les Variables d'Environnement

1. Dans ton projet Next.js, crée un fichier `.env.local` à la racine :

```bash
# Copie le contenu de .env.example
cp .env.example .env.local
```

2. Ouvre `.env.local` et remplace les valeurs :

```env
NEXT_PUBLIC_SUPABASE_URL=https://ton-projet-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=ta_cle_anon_publique_ici

NEXT_PUBLIC_APP_URL=http://localhost:3000
```

---

## 🗄️ Étape 4 : Créer les Tables dans la Base de Données

### Option 1 : Via l'interface Supabase (Recommandé pour débuter)

1. Dans Supabase, va dans **Table Editor**
2. Clique sur **New Table**
3. Crée la table `profiles` :

```sql
-- Table des profils utilisateurs
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  username text unique not null,
  avatar_url text,
  bio text,
  rank text default 'Rookie',
  twitch_url text,
  steam_url text,
  discord_tag text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  
  constraint username_length check (char_length(username) >= 3)
);

-- Enable Row Level Security
alter table profiles enable row level security;

-- Policies
create policy "Profiles are viewable by everyone"
  on profiles for select
  using (true);

create policy "Users can update own profile"
  on profiles for update
  using (auth.uid() = id);

-- Function to create profile on signup
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, username)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1))
  );
  return new;
end;
$$ language plpgsql security definer;

-- Trigger to create profile
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

### Option 2 : Via le SQL Editor

1. Va dans **SQL Editor**
2. Crée une nouvelle query
3. Colle le SQL ci-dessus
4. Clique sur **Run**

---

## 🔒 Étape 5 : Configurer l'Authentification OAuth (Optionnel)

### Google OAuth

1. Dans Supabase, va dans **Authentication** → **Providers**
2. Trouve **Google** et clique pour l'activer
3. Tu auras besoin de :
   - **Client ID** de Google Cloud Console
   - **Client Secret** de Google Cloud Console

#### Créer les credentials Google :
1. Va sur [Google Cloud Console](https://console.cloud.google.com)
2. Crée un nouveau projet ou sélectionne un existant
3. Va dans **APIs & Services** → **Credentials**
4. Clique sur **Create Credentials** → **OAuth 2.0 Client ID**
5. Configure :
   - Application type : **Web application**
   - Authorized redirect URIs : `https://ton-projet-id.supabase.co/auth/v1/callback`
6. Copie le Client ID et Client Secret dans Supabase

### Discord OAuth

1. Va sur [Discord Developer Portal](https://discord.com/developers/applications)
2. Crée une nouvelle application
3. Va dans **OAuth2**
4. Ajoute l'URL de redirection : `https://ton-projet-id.supabase.co/auth/v1/callback`
5. Copie le Client ID et Client Secret
6. Dans Supabase, active Discord et colle les credentials

---

## ✅ Étape 6 : Tester l'Authentification

1. Lance ton serveur de développement :
```bash
npm run dev
```

2. Va sur `http://localhost:3000/signup`
3. Crée un compte test
4. Vérifie que :
   - L'email de confirmation est envoyé (check les spams)
   - Le profil est créé dans la table `profiles`

---

## 🔧 Dépannage

### Erreur : "Invalid API Key"
- Vérifie que tu as bien copié les bonnes clés dans `.env.local`
- Redémarre le serveur après avoir modifié `.env.local`

### Erreur : "Email not confirmed"
- En développement, tu peux désactiver la confirmation d'email :
  - Va dans **Authentication** → **Settings**
  - Désactive "Enable email confirmations"

### L'utilisateur n'apparaît pas dans `profiles`
- Vérifie que le trigger `on_auth_user_created` est bien créé
- Check les logs dans Supabase → **Database** → **Triggers**

---

## 📚 Ressources Supplémentaires

- [Documentation Supabase Auth](https://supabase.com/docs/guides/auth)
- [Row Level Security](https://supabase.com/docs/guides/auth/row-level-security)
- [Next.js avec Supabase](https://supabase.com/docs/guides/getting-started/tutorials/with-nextjs)

---

## 🚀 Prochaines Étapes

Une fois Supabase configuré :
1. Teste l'inscription et la connexion
2. Configure les OAuth providers (optionnel)
3. Passe à l'étape suivante : **Profils Utilisateurs**
