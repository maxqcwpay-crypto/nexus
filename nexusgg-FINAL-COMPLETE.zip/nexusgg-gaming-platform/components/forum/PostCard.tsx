"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ThumbsUp,
  ThumbsDown,
  MessageSquare,
  Eye,
  Pin,
  Lock,
  MoreVertical,
  Share2,
  Edit,
  Trash2,
  Flag,
} from "lucide-react";
import { ForumPost } from "@/lib/forum/forum-service";
import { formatRelativeTime } from "@/lib/utils";
import { createClient } from "@/lib/auth/supabase-client";
import { useRouter } from "next/navigation";
import EditPostModal from "./EditPostModal";
import ReportModal from "./ReportModal";
import { deletePost } from "@/app/forum/actions";

interface PostCardProps {
  post: ForumPost;
  currentUserId?: string;
}

export default function PostCard({ post, currentUserId }: PostCardProps) {
  const router = useRouter();
  const [userVote, setUserVote] = useState<'upvote' | 'downvote' | null>(
    post.user_vote || null
  );
  const [upvotes, setUpvotes] = useState(post.upvotes);
  const [downvotes, setDownvotes] = useState(post.downvotes);
  const [isVoting, setIsVoting] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const isOwner = currentUserId === post.author_id;

  const handleVote = async (voteType: 'upvote' | 'downvote') => {
    if (isVoting) return;
    setIsVoting(true);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push('/login');
        return;
      }

      // Optimistic update
      const oldVote = userVote;
      const oldUpvotes = upvotes;
      const oldDownvotes = downvotes;

      if (oldVote === voteType) {
        // Remove vote
        setUserVote(null);
        if (voteType === 'upvote') {
          setUpvotes(upvotes - 1);
        } else {
          setDownvotes(downvotes - 1);
        }
      } else if (oldVote) {
        // Change vote
        setUserVote(voteType);
        if (voteType === 'upvote') {
          setUpvotes(upvotes + 1);
          setDownvotes(downvotes - 1);
        } else {
          setUpvotes(upvotes - 1);
          setDownvotes(downvotes + 1);
        }
      } else {
        // New vote
        setUserVote(voteType);
        if (voteType === 'upvote') {
          setUpvotes(upvotes + 1);
        } else {
          setDownvotes(downvotes + 1);
        }
      }

      // Make API call
      const { data: existingVote } = await supabase
        .from('post_votes')
        .select('*')
        .eq('post_id', post.id)
        .eq('user_id', user.id)
        .single();

      if (existingVote) {
        if (existingVote.vote_type === voteType) {
          await supabase
            .from('post_votes')
            .delete()
            .eq('post_id', post.id)
            .eq('user_id', user.id);
        } else {
          await supabase
            .from('post_votes')
            .update({ vote_type: voteType })
            .eq('post_id', post.id)
            .eq('user_id', user.id);
        }
      } else {
        await supabase.from('post_votes').insert({
          post_id: post.id,
          user_id: user.id,
          vote_type: voteType,
        });
      }

      router.refresh();
    } catch (error) {
      console.error('Vote error:', error);
      // Revert on error
      setUserVote(userVote);
      setUpvotes(upvotes);
      setDownvotes(downvotes);
    } finally {
      setIsVoting(false);
    }
  };

  const score = upvotes - downvotes;

  return (
    <article className="card-gaming group">
      <div className="flex gap-4">
        {/* Vote Section */}
        <div className="flex flex-col items-center space-y-1 flex-shrink-0">
          <button
            onClick={() => handleVote('upvote')}
            disabled={isVoting}
            className={`p-2 rounded-lg transition-all ${
              userVote === 'upvote'
                ? 'bg-indigo-500/20 text-indigo-400'
                : 'glass-effect hover:bg-slate-800/60 text-slate-400 hover:text-indigo-400'
            }`}
          >
            <ThumbsUp className="h-5 w-5" />
          </button>
          <div
            className={`text-sm font-bold ${
              score > 0
                ? 'text-green-400'
                : score < 0
                ? 'text-red-400'
                : 'text-slate-400'
            }`}
          >
            {score}
          </div>
          <button
            onClick={() => handleVote('downvote')}
            disabled={isVoting}
            className={`p-2 rounded-lg transition-all ${
              userVote === 'downvote'
                ? 'bg-red-500/20 text-red-400'
                : 'glass-effect hover:bg-slate-800/60 text-slate-400 hover:text-red-400'
            }`}
          >
            <ThumbsDown className="h-5 w-5" />
          </button>
        </div>

        {/* Content Section */}
        <div className="flex-1 min-w-0">
          {/* Header */}
          <div className="flex items-start justify-between gap-4 mb-3">
            <div className="flex items-center gap-2 flex-wrap">
              {post.is_pinned && (
                <Pin className="h-4 w-4 text-indigo-400 flex-shrink-0" />
              )}
              {post.game && (
                <Link
                  href={`/forum?game=${post.game.id}`}
                  className="text-xs px-2 py-1 rounded bg-indigo-500/20 text-indigo-400 hover:bg-indigo-500/30 transition-colors"
                >
                  {post.game.name}
                </Link>
              )}
              <Link
                href={`/profile/${post.author?.username}`}
                className="text-sm text-slate-400 hover:text-white transition-colors"
              >
                u/{post.author?.username}
              </Link>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-500">
                {formatRelativeTime(new Date(post.created_at))}
              </span>
            </div>
            <button className="p-1 rounded hover:bg-slate-800/50 transition-all">
              <MoreVertical className="h-4 w-4 text-slate-500" />
            </button>
          </div>

          {/* Title */}
          <Link href={`/forum/${post.id}`}>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
              {post.title}
              {post.is_locked && (
                <Lock className="inline h-4 w-4 ml-2 text-slate-500" />
              )}
            </h3>
          </Link>

          {/* Content Preview */}
          <p className="text-slate-400 mb-3 line-clamp-3">{post.content}</p>

          {/* Media */}
          {post.media_url && (
            <div className="mb-3 rounded-lg overflow-hidden">
              {post.media_type === 'image' ? (
                <img
                  src={post.media_url}
                  alt={post.title}
                  className="w-full max-h-96 object-cover"
                />
              ) : (
                <div className="aspect-video bg-slate-800 flex items-center justify-center">
                  <span className="text-slate-500">Video</span>
                </div>
              )}
            </div>
          )}

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-3">
              {post.tags.map((tag, idx) => (
                <Link
                  key={idx}
                  href={`/forum?tag=${tag}`}
                  className="text-xs px-2 py-1 rounded bg-slate-800/50 text-slate-400 hover:bg-slate-700/50 transition-colors"
                >
                  #{tag}
                </Link>
              ))}
            </div>
          )}

          {/* Footer */}
          <div className="flex items-center gap-4 text-sm text-slate-500">
            <Link
              href={`/forum/${post.id}`}
              className="flex items-center space-x-1 hover:text-cyan-400 transition-colors"
            >
              <MessageSquare className="h-4 w-4" />
              <span>{post.comment_count} commentaires</span>
            </Link>
            <button className="flex items-center space-x-1 hover:text-slate-300 transition-colors">
              <Share2 className="h-4 w-4" />
              <span>Partager</span>
            </button>
            
            {!isOwner && currentUserId && (
              <button 
                onClick={() => setShowReportModal(true)}
                className="flex items-center space-x-1 hover:text-red-400 transition-colors"
              >
                <Flag className="h-4 w-4" />
                <span>Signaler</span>
              </button>
            )}
            
            {isOwner && (
              <div className="relative ml-auto">
                <button
                  onClick={() => setShowMenu(!showMenu)}
                  className="p-1 rounded hover:bg-slate-800/50 transition-colors"
                >
                  <MoreVertical className="h-4 w-4 text-slate-400" />
                </button>

                {showMenu && (
                  <div className="absolute right-0 mt-2 w-48 glass-effect rounded-lg border border-slate-700 shadow-xl z-10">
                    <button
                      onClick={() => {
                        setShowEditModal(true);
                        setShowMenu(false);
                      }}
                      className="w-full px-4 py-2 text-left text-sm text-indigo-400 hover:bg-slate-800/50 transition-colors flex items-center space-x-2 rounded-t-lg"
                    >
                      <Edit className="h-4 w-4" />
                      <span>Éditer</span>
                    </button>
                    <button
                      onClick={async () => {
                        if (!confirm("Êtes-vous sûr de vouloir supprimer ce post ?")) return;
                        setIsDeleting(true);
                        try {
                          await deletePost(post.id);
                          router.push("/forum");
                          router.refresh();
                        } catch (error) {
                          alert("Erreur lors de la suppression");
                          setIsDeleting(false);
                        }
                      }}
                      disabled={isDeleting}
                      className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-slate-800/50 transition-colors flex items-center space-x-2 rounded-b-lg border-t border-slate-800"
                    >
                      <Trash2 className="h-4 w-4" />
                      <span>{isDeleting ? "Suppression..." : "Supprimer"}</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </article>
    
    {showEditModal && (
      <EditPostModal
        post={post}
        onClose={() => setShowEditModal(false)}
      />
    )}
    
    {showReportModal && (
      <ReportModal
        targetType="post"
        targetId={post.id}
        onClose={() => setShowReportModal(false)}
      />
    )}
  );
}
