import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin, getAllPosts } from "@/lib/admin/admin-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import Link from "next/link";
import { Trash2, Pin, Lock, Eye } from "lucide-react";
import { formatRelativeTime } from "@/lib/utils";

export default async function AdminPostsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const { posts } = await getAllPosts();

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              Gestion des Posts
            </h1>
            <p className="text-slate-400">{posts.length} posts au total</p>
          </div>

          <div className="glass-effect rounded-lg border border-slate-800/50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-900/50 border-b border-slate-800">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Post
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Auteur
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Jeu
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Score
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Date
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Statut
                    </th>
                    <th className="px-6 py-4 text-right text-xs font-medium text-slate-400 uppercase">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {posts.map((post: any) => (
                    <tr key={post.id} className="hover:bg-slate-800/30">
                      <td className="px-6 py-4">
                        <Link
                          href={`/forum/${post.id}`}
                          className="text-sm font-medium text-white hover:text-indigo-400 line-clamp-1"
                        >
                          {post.title}
                        </Link>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-slate-300">
                          {post.author?.username || "Deleted"}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-slate-400">
                          {post.game?.name || "N/A"}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-slate-300">
                          {post.upvotes - post.downvotes}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-slate-400">
                          {formatRelativeTime(new Date(post.created_at))}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-1">
                          {post.is_pinned && (
                            <span className="px-2 py-1 text-xs bg-indigo-500/20 text-indigo-400 rounded">
                              Épinglé
                            </span>
                          )}
                          {post.is_locked && (
                            <span className="px-2 py-1 text-xs bg-red-500/20 text-red-400 rounded">
                              Verrouillé
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <Link
                            href={`/forum/${post.id}`}
                            className="p-2 rounded hover:bg-slate-700/50"
                          >
                            <Eye className="h-4 w-4 text-slate-400" />
                          </Link>
                          <form action={async () => {
                            "use server";
                            const { pinPost, unpinPost } = await import("./actions");
                            if (post.is_pinned) {
                              await unpinPost(post.id);
                            } else {
                              await pinPost(post.id);
                            }
                          }}>
                            <button 
                              type="submit"
                              className={`p-2 rounded hover:bg-slate-700/50 ${post.is_pinned ? 'text-indigo-400' : 'text-slate-400'}`}
                              title={post.is_pinned ? "Désépingler" : "Épingler"}
                            >
                              <Pin className="h-4 w-4" />
                            </button>
                          </form>
                          <form action={async () => {
                            "use server";
                            const { lockPost, unlockPost } = await import("./actions");
                            if (post.is_locked) {
                              await unlockPost(post.id);
                            } else {
                              await lockPost(post.id);
                            }
                          }}>
                            <button 
                              type="submit"
                              className={`p-2 rounded hover:bg-slate-700/50 ${post.is_locked ? 'text-red-400' : 'text-slate-400'}`}
                              title={post.is_locked ? "Déverrouiller" : "Verrouiller"}
                            >
                              <Lock className="h-4 w-4" />
                            </button>
                          </form>
                          <form action={async () => {
                            "use server";
                            const { deletePost } = await import("./actions");
                            await deletePost(post.id);
                          }}>
                            <button 
                              type="submit"
                              className="p-2 rounded hover:bg-red-500/20"
                              title="Supprimer"
                              onClick={(e) => {
                                if (!confirm('Êtes-vous sûr de vouloir supprimer ce post ?')) {
                                  e.preventDefault();
                                }
                              }}
                            >
                              <Trash2 className="h-4 w-4 text-red-400" />
                            </button>
                          </form>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
