-- Admin system tables

-- Admin roles table
create table if not exists admin_roles (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references profiles(id) on delete cascade unique not null,
  role text check (role in ('super_admin', 'moderator', 'support')) default 'moderator',
  permissions jsonb default '{}',
  created_at timestamp with time zone default now(),
  created_by uuid references profiles(id)
);

-- Admin activity logs
create table if not exists admin_logs (
  id uuid default gen_random_uuid() primary key,
  admin_id uuid references profiles(id) on delete set null,
  action text not null,
  target_type text,
  target_id uuid,
  details jsonb,
  ip_address text,
  created_at timestamp with time zone default now()
);

-- Reports table (user reports)
create table if not exists reports (
  id uuid default gen_random_uuid() primary key,
  reporter_id uuid references profiles(id) on delete set null,
  target_type text check (target_type in ('post', 'comment', 'user')) not null,
  target_id uuid not null,
  reason text not null,
  description text,
  status text check (status in ('pending', 'reviewed', 'resolved', 'dismissed')) default 'pending',
  reviewed_by uuid references profiles(id) on delete set null,
  reviewed_at timestamp with time zone,
  created_at timestamp with time zone default now()
);

-- Site statistics (cached)
create table if not exists site_stats (
  id uuid default gen_random_uuid() primary key,
  stat_date date not null unique,
  total_users integer default 0,
  total_posts integer default 0,
  total_comments integer default 0,
  active_users integer default 0,
  new_users integer default 0,
  new_posts integer default 0,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table admin_roles enable row level security;
alter table admin_logs enable row level security;
alter table reports enable row level security;
alter table site_stats enable row level security;

-- Policies for admin_roles
create policy "Admin roles viewable by admins"
  on admin_roles for select
  using (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid()
    )
  );

create policy "Only super admins can manage roles"
  on admin_roles for all
  using (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid() and ar.role = 'super_admin'
    )
  );

-- Policies for admin_logs
create policy "Admin logs viewable by admins"
  on admin_logs for select
  using (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid()
    )
  );

create policy "Admins can create logs"
  on admin_logs for insert
  with check (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid()
    )
  );

-- Policies for reports
create policy "Users can create reports"
  on reports for insert
  with check (auth.uid() = reporter_id);

create policy "Users can view their own reports"
  on reports for select
  using (auth.uid() = reporter_id);

create policy "Admins can view all reports"
  on reports for select
  using (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid()
    )
  );

create policy "Admins can update reports"
  on reports for update
  using (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid()
    )
  );

-- Policies for site_stats
create policy "Stats viewable by admins"
  on site_stats for select
  using (
    exists (
      select 1 from admin_roles ar
      where ar.user_id = auth.uid()
    )
  );

-- Function to check if user is admin
create or replace function is_admin(user_id uuid)
returns boolean as $$
begin
  return exists (
    select 1 from admin_roles
    where admin_roles.user_id = user_id
  );
end;
$$ language plpgsql security definer;

-- Function to get daily stats
create or replace function update_daily_stats()
returns void as $$
declare
  stat_date date := current_date;
begin
  insert into site_stats (
    stat_date,
    total_users,
    total_posts,
    total_comments,
    active_users,
    new_users,
    new_posts
  )
  select
    stat_date,
    (select count(*) from profiles),
    (select count(*) from posts),
    (select count(*) from comments),
    (select count(distinct author_id) from posts where created_at >= current_date),
    (select count(*) from profiles where created_at >= current_date),
    (select count(*) from posts where created_at >= current_date)
  on conflict (stat_date) do update set
    total_users = excluded.total_users,
    total_posts = excluded.total_posts,
    total_comments = excluded.total_comments,
    active_users = excluded.active_users,
    new_users = excluded.new_users,
    new_posts = excluded.new_posts;
end;
$$ language plpgsql security definer;

-- Add is_banned column to profiles
alter table profiles add column if not exists is_banned boolean default false;
alter table profiles add column if not exists ban_reason text;
alter table profiles add column if not exists banned_at timestamp with time zone;
alter table profiles add column if not exists banned_by uuid references profiles(id);

-- Indexes
create index if not exists admin_roles_user_id_idx on admin_roles(user_id);
create index if not exists admin_logs_admin_id_idx on admin_logs(admin_id);
create index if not exists admin_logs_created_at_idx on admin_logs(created_at desc);
create index if not exists reports_status_idx on reports(status);
create index if not exists reports_target_idx on reports(target_type, target_id);
