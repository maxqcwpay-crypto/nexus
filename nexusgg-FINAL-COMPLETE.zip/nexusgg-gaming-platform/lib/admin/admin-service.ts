import { createClient } from '@/lib/auth/supabase-server'

export interface AdminStats {
  totalUsers: number
  totalPosts: number
  totalComments: number
  activeUsers: number
  newUsers: number
  newPosts: number
  recentActivity: any[]
}

export async function isAdmin(userId: string): Promise<boolean> {
  const supabase = await createClient()
  
  const { data } = await supabase
    .from('admin_roles')
    .select('role')
    .eq('user_id', userId)
    .single()

  return !!data
}

export async function getAdminRole(userId: string): Promise<string | null> {
  const supabase = await createClient()
  
  const { data } = await supabase
    .from('admin_roles')
    .select('role')
    .eq('user_id', userId)
    .single()

  return data?.role || null
}

export async function getAdminStats(): Promise<AdminStats> {
  const supabase = await createClient()

  const [
    { count: totalUsers },
    { count: totalPosts },
    { count: totalComments },
    { count: activeUsers },
    { count: newUsers },
    { count: newPosts },
  ] = await Promise.all([
    supabase.from('profiles').select('*', { count: 'exact', head: true }),
    supabase.from('posts').select('*', { count: 'exact', head: true }),
    supabase.from('comments').select('*', { count: 'exact', head: true }),
    supabase
      .from('posts')
      .select('author_id', { count: 'exact', head: true })
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString()),
    supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()),
    supabase
      .from('posts')
      .select('*', { count: 'exact', head: true })
      .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()),
  ])

  const { data: recentActivity } = await supabase
    .from('posts')
    .select(`
      *,
      author:profiles!posts_author_id_fkey(username, avatar_url)
    `)
    .order('created_at', { ascending: false })
    .limit(10)

  return {
    totalUsers: totalUsers || 0,
    totalPosts: totalPosts || 0,
    totalComments: totalComments || 0,
    activeUsers: activeUsers || 0,
    newUsers: newUsers || 0,
    newPosts: newPosts || 0,
    recentActivity: recentActivity || [],
  }
}

export async function getAllUsers(page = 1, search = '') {
  const supabase = await createClient()
  const pageSize = 20
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1

  let query = supabase
    .from('profiles')
    .select('*, posts_count, followers_count', { count: 'exact' })
    .order('created_at', { ascending: false })

  if (search) {
    query = query.or(`username.ilike.%${search}%,email.ilike.%${search}%`)
  }

  const { data, count, error } = await query.range(from, to)

  return { users: data || [], totalCount: count || 0 }
}

export async function banUser(userId: string, reason: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('profiles')
    .update({
      is_banned: true,
      ban_reason: reason,
      banned_at: new Date().toISOString(),
      banned_by: adminId,
    })
    .eq('id', userId)

  if (error) throw error

  await logAdminAction(adminId, 'ban_user', 'user', userId, { reason })
}

export async function unbanUser(userId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('profiles')
    .update({
      is_banned: false,
      ban_reason: null,
      banned_at: null,
      banned_by: null,
    })
    .eq('id', userId)

  if (error) throw error

  await logAdminAction(adminId, 'unban_user', 'user', userId, {})
}

export async function deleteUser(userId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase.from('profiles').delete().eq('id', userId)

  if (error) throw error

  await logAdminAction(adminId, 'delete_user', 'user', userId, {})
}

export async function getAllPosts(page = 1, filters: any = {}) {
  const supabase = await createClient()
  const pageSize = 20
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1

  let query = supabase
    .from('posts')
    .select(
      `
      *,
      author:profiles!posts_author_id_fkey(username, avatar_url),
      game:games(name)
    `,
      { count: 'exact' }
    )
    .order('created_at', { ascending: false })

  if (filters.search) {
    query = query.or(`title.ilike.%${filters.search}%,content.ilike.%${filters.search}%`)
  }

  if (filters.gameId) {
    query = query.eq('game_id', filters.gameId)
  }

  const { data, count, error } = await query.range(from, to)

  return { posts: data || [], totalCount: count || 0 }
}

export async function deletePost(postId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase.from('posts').delete().eq('id', postId)

  if (error) throw error

  await logAdminAction(adminId, 'delete_post', 'post', postId, {})
}

export async function pinPost(postId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('posts')
    .update({ is_pinned: true })
    .eq('id', postId)

  if (error) throw error

  await logAdminAction(adminId, 'pin_post', 'post', postId, {})
}

export async function unpinPost(postId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('posts')
    .update({ is_pinned: false })
    .eq('id', postId)

  if (error) throw error

  await logAdminAction(adminId, 'unpin_post', 'post', postId, {})
}

export async function lockPost(postId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('posts')
    .update({ is_locked: true })
    .eq('id', postId)

  if (error) throw error

  await logAdminAction(adminId, 'lock_post', 'post', postId, {})
}

export async function getReports(status = 'pending') {
  const supabase = await createClient()

  let query = supabase
    .from('reports')
    .select(
      `
      *,
      reporter:profiles!reports_reporter_id_fkey(username, avatar_url),
      reviewer:profiles!reports_reviewed_by_fkey(username)
    `
    )
    .order('created_at', { ascending: false })

  if (status !== 'all') {
    query = query.eq('status', status)
  }

  const { data, error } = await query

  return data || []
}

export async function updateReport(reportId: string, status: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('reports')
    .update({
      status,
      reviewed_by: adminId,
      reviewed_at: new Date().toISOString(),
    })
    .eq('id', reportId)

  if (error) throw error

  await logAdminAction(adminId, 'review_report', 'report', reportId, { status })
}

export async function getAdminLogs(limit = 50) {
  const supabase = await createClient()

  const { data } = await supabase
    .from('admin_logs')
    .select(
      `
      *,
      admin:profiles!admin_logs_admin_id_fkey(username, avatar_url)
    `
    )
    .order('created_at', { ascending: false })
    .limit(limit)

  return data || []
}

async function logAdminAction(
  adminId: string,
  action: string,
  targetType: string,
  targetId: string,
  details: any
) {
  const supabase = await createClient()

  await supabase.from('admin_logs').insert({
    admin_id: adminId,
    action,
    target_type: targetType,
    target_id: targetId,
    details,
  })
}

export async function createGame(data: any, adminId: string) {
  const supabase = await createClient()

  const { data: game, error } = await supabase
    .from('games')
    .insert({
      name: data.name,
      slug: data.slug,
      cover_image: data.coverImage,
      genre: data.genre,
      platform: data.platform,
    })
    .select()
    .single()

  if (error) throw error

  await logAdminAction(adminId, 'create_game', 'game', game.id, data)

  return game
}

export async function updateGame(gameId: string, data: any, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase
    .from('games')
    .update({
      name: data.name,
      slug: data.slug,
      cover_image: data.coverImage,
      genre: data.genre,
      platform: data.platform,
    })
    .eq('id', gameId)

  if (error) throw error

  await logAdminAction(adminId, 'update_game', 'game', gameId, data)
}

export async function deleteGame(gameId: string, adminId: string) {
  const supabase = await createClient()

  const { error } = await supabase.from('games').delete().eq('id', gameId)

  if (error) throw error

  await logAdminAction(adminId, 'delete_game', 'game', gameId, {})
}
