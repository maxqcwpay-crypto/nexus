import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin, getAdminLogs } from "@/lib/admin/admin-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import { Activity, Filter } from "lucide-react";
import { formatRelativeTime } from "@/lib/utils";

export default async function AdminLogsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const logs = await getAdminLogs(100);

  const actionLabels: Record<string, string> = {
    ban_user: "Ban utilisateur",
    unban_user: "Déban utilisateur",
    delete_user: "Suppression utilisateur",
    delete_post: "Suppression post",
    pin_post: "Épinglage post",
    unpin_post: "Désépinglage post",
    lock_post: "Verrouillage post",
    unlock_post: "Déverrouillage post",
    create_game: "Création jeu",
    update_game: "Modification jeu",
    delete_game: "Suppression jeu",
    review_report: "Examen report",
  };

  const actionColors: Record<string, string> = {
    ban_user: "text-red-400 bg-red-500/20",
    unban_user: "text-green-400 bg-green-500/20",
    delete_user: "text-red-400 bg-red-500/20",
    delete_post: "text-red-400 bg-red-500/20",
    pin_post: "text-indigo-400 bg-indigo-500/20",
    unpin_post: "text-slate-400 bg-slate-500/20",
    lock_post: "text-orange-400 bg-orange-500/20",
    unlock_post: "text-green-400 bg-green-500/20",
    create_game: "text-green-400 bg-green-500/20",
    update_game: "text-blue-400 bg-blue-500/20",
    delete_game: "text-red-400 bg-red-500/20",
    review_report: "text-cyan-400 bg-cyan-500/20",
  };

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              Logs d&apos;Activité Admin
            </h1>
            <p className="text-slate-400">
              Historique complet des {logs.length} dernières actions
            </p>
          </div>

          {/* Logs Table */}
          <div className="glass-effect rounded-lg border border-slate-800/50 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-900/50 border-b border-slate-800">
                  <tr>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Date
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Admin
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Action
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Type
                    </th>
                    <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase">
                      Détails
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {logs.map((log: any) => (
                    <tr key={log.id} className="hover:bg-slate-800/30">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-slate-400">
                          {formatRelativeTime(new Date(log.created_at))}
                        </div>
                        <div className="text-xs text-slate-600">
                          {new Date(log.created_at).toLocaleString("fr-FR")}
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <img
                            src={
                              log.admin?.avatar_url ||
                              `https://api.dicebear.com/7.x/avataaars/svg?seed=${log.admin?.username}`
                            }
                            alt={log.admin?.username}
                            className="h-8 w-8 rounded-full"
                          />
                          <span className="text-sm text-white">
                            {log.admin?.username || "Admin supprimé"}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span
                          className={`px-3 py-1 rounded text-xs font-medium ${
                            actionColors[log.action] ||
                            "text-slate-400 bg-slate-500/20"
                          }`}
                        >
                          {actionLabels[log.action] || log.action}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-sm text-slate-400">
                          {log.target_type || "N/A"}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {log.details && Object.keys(log.details).length > 0 ? (
                          <div className="text-xs text-slate-500">
                            {JSON.stringify(log.details, null, 2)
                              .slice(0, 100)
                              .replace(/[{}"]/g, "")}
                          </div>
                        ) : (
                          <span className="text-xs text-slate-600">-</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {logs.length === 0 && (
            <div className="text-center py-12 glass-effect rounded-lg border border-slate-800/50 mt-6">
              <Activity className="h-12 w-12 text-slate-600 mx-auto mb-4" />
              <p className="text-slate-400">Aucun log pour le moment</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
