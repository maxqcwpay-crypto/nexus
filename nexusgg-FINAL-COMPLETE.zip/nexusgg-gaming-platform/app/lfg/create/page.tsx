import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { getAllGames } from "@/lib/profile/profile-service";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CreateLFGForm from "@/components/lfg/CreateLFGForm";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

export default async function CreateLFGPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const games = await getAllGames();

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-24 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            href="/lfg"
            className="inline-flex items-center space-x-2 text-slate-400 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Retour aux demandes LFG</span>
          </Link>

          <div className="mb-8">
            <h1 className="text-4xl font-bold neon-text mb-2">
              Créer une demande LFG
            </h1>
            <p className="text-slate-400">
              Trouve des joueurs pour ta prochaine session
            </p>
          </div>

          <div className="glass-effect rounded-lg p-6 md:p-8 border border-slate-800/50">
            <CreateLFGForm games={games} />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
