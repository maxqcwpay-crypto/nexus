# 🛡️ Panel d'Administration - Guide Complet

## 🎯 Vue d'ensemble

Le panel d'administration de NexusGG permet de gérer l'ensemble de la plateforme depuis une interface centralisée. Seuls les utilisateurs avec le rôle `admin` peuvent y accéder.

## 📊 Fonctionnalités Disponibles

### 1. **Dashboard** (`/admin`)
- Vue d'ensemble des statistiques clés
- Nombre total d'utilisateurs, posts, commentaires
- Utilisateurs actifs (24h)
- Nouveaux utilisateurs et posts (7j)
- Activité récente de la plateforme
- Logs des actions admin

### 2. **Gestion des Utilisateurs** (`/admin/users`)
- **Liste complète** de tous les utilisateurs
- **Recherche** par username ou email
- **Informations affichées :**
  - Avatar, username, email
  - Rang (Rookie → Legend)
  - Nombre de posts
  - Date d'inscription
  - Statut (Actif/Banni)
- **Actions disponibles :**
  - 🚫 **Bannir** un utilisateur (avec raison)
  - ✅ **Débannir** un utilisateur
  - 🗑️ **Supprimer** un utilisateur (irréversible)

### 3. **Gestion des Posts** (`/admin/posts`)
- **Liste de tous les posts** du forum
- **Informations :**
  - Titre, auteur, jeu
  - Score (upvotes - downvotes)
  - Date de création
  - Statut (Épinglé/Verrouillé)
- **Actions :**
  - 👁️ **Voir** le post
  - 📌 **Épingler** (apparaît en haut)
  - 🔒 **Verrouiller** (empêche les commentaires)
  - 🗑️ **Supprimer**

### 4. **Gestion des Jeux** (`/admin/games`)
- **Catalogue complet** des jeux
- **Grid view** avec cover images
- **Actions :**
  - ➕ **Ajouter** un nouveau jeu
  - ✏️ **Éditer** les informations
  - 🗑️ **Supprimer** un jeu

### 5. **Gestion des Badges** (`/admin/badges`)
- Liste des badges disponibles
- Création de nouveaux badges
- Modification des raretés
- Attribution manuelle

### 6. **Reports** (`/admin/reports`)
- Signalements des utilisateurs
- Filtrage par statut (pending/reviewed/resolved)
- Review et modération

### 7. **Logs Admin** (`/admin/logs`)
- Historique de toutes les actions admin
- Traçabilité complète
- Filtrage par admin/action/date

### 8. **Paramètres** (`/admin/settings`)
- Configuration du site
- Gestion des permissions
- Paramètres avancés

---

## 🚀 Installation et Configuration

### 1. Créer les tables admin dans Supabase

```bash
# Exécute admin_tables.sql dans Supabase SQL Editor
```

Le script crée :
- `admin_roles` : Rôles des administrateurs
- `admin_logs` : Logs de toutes les actions
- `reports` : Signalements utilisateurs
- `site_stats` : Statistiques quotidiennes

### 2. Créer ton premier admin

**Important :** Par défaut, personne n'a accès au panel. Tu dois créer manuellement le premier admin.

#### Option A : Via Supabase SQL Editor

```sql
-- Remplace USER_ID par l'ID de ton compte
INSERT INTO admin_roles (user_id, role, created_by)
VALUES (
  'ton-user-id-ici',
  'super_admin',
  'ton-user-id-ici'
);
```

Pour trouver ton USER_ID :
1. Va dans Supabase → **Authentication** → **Users**
2. Trouve ton compte
3. Copie l'UUID

#### Option B : Via la console

```sql
-- Trouve ton user ID
SELECT id, username FROM profiles WHERE username = 'ton-username';

-- Crée le role admin
INSERT INTO admin_roles (user_id, role)
VALUES ('uuid-du-dessus', 'super_admin');
```

### 3. Vérifier l'accès

1. Connecte-toi sur le site avec ton compte
2. Va sur `/admin`
3. Tu devrais voir le dashboard admin

---

## 👥 Système de Rôles

### Hiérarchie

1. **super_admin** (Super Administrateur)
   - Accès complet
   - Peut créer/supprimer d'autres admins
   - Toutes les permissions

2. **moderator** (Modérateur)
   - Gestion des posts et commentaires
   - Ban/unban des utilisateurs
   - Review des reports
   - Pas d'accès aux paramètres critiques

3. **support** (Support)
   - Lecture seule des données
   - Peut répondre aux reports
   - Pas de droits de modération

### Créer un nouvel admin

```sql
INSERT INTO admin_roles (user_id, role, created_by)
VALUES (
  'user-id-du-nouveau-admin',
  'moderator', -- ou 'super_admin', 'support'
  'ton-user-id'
);
```

---

## 🔒 Sécurité

### Vérification des permissions

Le panel utilise Row Level Security (RLS) de Supabase :

```typescript
// Middleware de vérification
export async function isAdmin(userId: string): Promise<boolean> {
  const { data } = await supabase
    .from('admin_roles')
    .select('role')
    .eq('user_id', userId)
    .single()

  return !!data
}
```

### Policies RLS

- ✅ Seuls les admins peuvent voir `admin_roles`
- ✅ Seuls les super_admins peuvent modifier les rôles
- ✅ Toutes les actions sont loggées dans `admin_logs`
- ✅ Les utilisateurs non-admin sont redirigés automatiquement

---

## 📊 Logs et Traçabilité

Toutes les actions sensibles sont automatiquement enregistrées :

### Actions loggées

- Ban/Unban utilisateur
- Suppression utilisateur
- Suppression/Pin/Lock de posts
- Création/modification de jeux
- Attribution de badges
- Review de reports

### Structure des logs

```typescript
{
  admin_id: "uuid",
  action: "ban_user",
  target_type: "user",
  target_id: "uuid-de-l-utilisateur",
  details: { reason: "Spam" },
  created_at: "2026-01-21T10:00:00Z"
}
```

---

## 🎨 Interface

### Design

- **Sidebar** fixe avec navigation rapide
- **Dashboard** avec cards de statistiques
- **Tables** responsives pour les données
- **Actions** contextuelles par ligne
- **Modals** pour les confirmations critiques

### Couleurs

- Background : Slate 950
- Sidebar : Glass effect
- Accents : Indigo/Cyan (cohérent avec le site)
- Danger : Red (suppressions)
- Success : Green (actions positives)

---

## 🧪 Comment Tester

### 1. Accéder au panel
```
1. Connecte-toi avec un compte admin
2. Va sur /admin
3. Tu devrais voir le dashboard
```

### 2. Bannir un utilisateur
```
1. Va sur /admin/users
2. Clique sur les 3 points d'un utilisateur
3. Clique "Bannir"
4. Entre une raison
5. Confirme
```

### 3. Gérer un post
```
1. Va sur /admin/posts
2. Trouve un post
3. Clique sur Pin/Lock/Delete
4. L'action est loggée automatiquement
```

### 4. Voir les logs
```
1. Va sur /admin/logs (à créer)
2. Vois toutes les actions récentes
3. Filtre par admin ou action
```

---

## 📝 TODO / Améliorations Futures

### Haute priorité
- [ ] Page Reports complète avec modération
- [ ] Page Logs avec filtres avancés
- [ ] Page Badges avec création/édition
- [ ] Page Settings pour config site

### Moyenne priorité
- [ ] Graphiques de statistiques (Chart.js)
- [ ] Export de données (CSV, JSON)
- [ ] Notifications admin en temps réel
- [ ] Dashboard personnalisable

### Basse priorité
- [ ] Thème clair pour admin
- [ ] Raccourcis clavier
- [ ] Mode maintenance du site
- [ ] Backup automatique des données

---

## 🐛 Problèmes Courants

### "Accès refusé" sur /admin
→ Vérifie que ton user_id est dans `admin_roles`
→ Vérifie que tu es bien connecté

### Les actions ne fonctionnent pas
→ Vérifie les policies RLS dans Supabase
→ Check la console pour les erreurs

### Les logs ne s'enregistrent pas
→ Vérifie que `admin_logs` existe
→ Vérifie les permissions d'insertion

---

## 🔐 Bonnes Pratiques

1. **Ne donne pas le rôle super_admin à n'importe qui**
   - Crée des moderators pour la modération quotidienne
   - Reserve super_admin aux personnes de confiance

2. **Vérifie régulièrement les logs**
   - Assure-toi qu'il n'y a pas d'actions suspectes
   - Monitore les bans/suppressions

3. **Communique avec ton équipe**
   - Préviens avant de supprimer des données
   - Documente les raisons des bans

4. **Sauvegarde avant les actions critiques**
   - Export des données importantes
   - Backup de la base de données

---

## 🎯 Prochaines Étapes

Le panel admin est maintenant opérationnel ! Tu peux :
1. Créer ton premier admin
2. Gérer les utilisateurs
3. Modérer les posts
4. Suivre l'activité de la plateforme

**Besoin d'aide ?** Consulte la documentation Supabase ou contacte le support.
