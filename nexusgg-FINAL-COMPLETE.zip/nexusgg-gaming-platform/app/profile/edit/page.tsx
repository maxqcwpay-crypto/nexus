import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { getProfileById, getAllGames } from "@/lib/profile/profile-service";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import EditProfileForm from "@/components/profile/EditProfileForm";
import { ArrowLeft } from "lucide-react";
import Link from "next/link";

export default async function EditProfilePage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect("/login");
  }

  const profile = await getProfileById(user.id);
  if (!profile) {
    redirect("/");
  }

  const games = await getAllGames();

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-24 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              href={`/profile/${profile.username}`}
              className="inline-flex items-center space-x-2 text-slate-400 hover:text-white transition-colors mb-4"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Retour au profil</span>
            </Link>
            <h1 className="text-4xl font-bold neon-text mb-2">
              Éditer le profil
            </h1>
            <p className="text-slate-400">
              Personnalise ton profil pour te démarquer dans la communauté
            </p>
          </div>

          {/* Form */}
          <div className="glass-effect rounded-lg p-6 md:p-8 border border-slate-800/50">
            <EditProfileForm profile={profile} availableGames={games} />
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
