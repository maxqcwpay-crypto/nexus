import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Users, Mic, Calendar, MapPin, CheckCircle, XCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getLFGById } from "@/lib/lfg/lfg-service";
import { createClient } from "@/lib/auth/supabase-server";
import { formatRelativeTime } from "@/lib/utils";

interface LFGDetailsPageProps {
  params: {
    lfgId: string;
  };
}

const platformIcons: Record<string, string> = {
  PC: "💻",
  PS5: "🎮",
  Xbox: "🎮",
  Switch: "🕹️",
  Mobile: "📱",
};

export default async function LFGDetailsPage({ params }: LFGDetailsPageProps) {
  const { lfgId } = params;
  const lfg = await getLFGById(lfgId);

  if (!lfg) {
    notFound();
  }

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const isOwner = user?.id === lfg.author_id;
  const spotsLeft = lfg.players_needed - lfg.current_players;

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-24 pb-12">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <Link
            href="/lfg"
            className="inline-flex items-center space-x-2 text-slate-400 hover:text-white transition-colors mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Retour aux demandes</span>
          </Link>

          {/* LFG Details */}
          <div className="glass-effect rounded-lg p-8 border border-slate-800/50 mb-6">
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-4">
                  {lfg.game && (
                    <span className="text-sm px-3 py-1 rounded bg-indigo-500/20 text-indigo-400">
                      {lfg.game.name}
                    </span>
                  )}
                  <span className="text-2xl">{platformIcons[lfg.platform]}</span>
                  <span className="text-sm text-slate-400">{lfg.platform}</span>
                </div>

                <h1 className="text-3xl font-bold text-white mb-4">{lfg.title}</h1>

                <div className="flex items-center gap-6 text-sm text-slate-400 mb-6">
                  <div className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-cyan-400" />
                    <span className="text-white font-medium">
                      {lfg.current_players}/{lfg.players_needed}
                    </span>
                    <span>joueurs</span>
                  </div>

                  {lfg.voice_required && (
                    <div className="flex items-center space-x-2 text-cyan-400">
                      <Mic className="h-5 w-5" />
                      <span>Micro requis</span>
                    </div>
                  )}

                  <div className="px-3 py-1 rounded bg-slate-800/50">
                    {lfg.skill_level}
                  </div>

                  {lfg.region && (
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-5 w-5" />
                      <span>{lfg.region}</span>
                    </div>
                  )}
                </div>

                {lfg.scheduled_time && (
                  <div className="flex items-center space-x-2 text-slate-300 mb-6 p-3 glass-effect rounded-lg inline-flex">
                    <Calendar className="h-5 w-5 text-indigo-400" />
                    <span>
                      {new Date(lfg.scheduled_time).toLocaleString("fr-FR", {
                        dateStyle: "full",
                        timeStyle: "short",
                      })}
                    </span>
                  </div>
                )}

                <div className="prose prose-invert max-w-none mb-6">
                  <p className="text-slate-300 whitespace-pre-wrap">{lfg.description}</p>
                </div>

                {lfg.tags && lfg.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-6">
                    {lfg.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="text-xs px-3 py-1 rounded bg-slate-800/50 text-slate-400"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center space-x-3 pt-6 border-t border-slate-800/50">
                  <img
                    src={
                      lfg.author?.avatar_url ||
                      `https://api.dicebear.com/7.x/avataaars/svg?seed=${lfg.author?.username}`
                    }
                    alt={lfg.author?.username}
                    className="h-12 w-12 rounded-full"
                  />
                  <div>
                    <Link
                      href={`/profile/${lfg.author?.username}`}
                      className="font-medium text-white hover:text-indigo-400"
                    >
                      {lfg.author?.username}
                    </Link>
                    <div className="text-sm text-slate-500">
                      {formatRelativeTime(new Date(lfg.created_at))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Team Members */}
          {lfg.members && lfg.members.length > 0 && (
            <div className="glass-effect rounded-lg p-6 border border-slate-800/50 mb-6">
              <h2 className="text-xl font-bold text-white mb-4">
                Équipe ({lfg.current_players}/{lfg.players_needed})
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {/* Author */}
                <div className="flex items-center space-x-3 p-3 glass-effect rounded-lg">
                  <img
                    src={lfg.author?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${lfg.author?.username}`}
                    alt={lfg.author?.username}
                    className="h-10 w-10 rounded-full"
                  />
                  <div>
                    <div className="text-sm font-medium text-white">
                      {lfg.author?.username}
                    </div>
                    <div className="text-xs text-indigo-400">Créateur</div>
                  </div>
                </div>

                {/* Members */}
                {lfg.members.map((member: any) => (
                  <div
                    key={member.id}
                    className="flex items-center space-x-3 p-3 glass-effect rounded-lg"
                  >
                    <img
                      src={member.user?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${member.user?.username}`}
                      alt={member.user?.username}
                      className="h-10 w-10 rounded-full"
                    />
                    <div className="text-sm font-medium text-white">
                      {member.user?.username}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Applications (Owner only) */}
          {isOwner && lfg.applications && lfg.applications.filter((a: any) => a.status === 'pending').length > 0 && (
            <div className="glass-effect rounded-lg p-6 border border-slate-800/50">
              <h2 className="text-xl font-bold text-white mb-4">
                Candidatures en attente
              </h2>
              <div className="space-y-3">
                {lfg.applications
                  .filter((a: any) => a.status === 'pending')
                  .map((app: any) => (
                    <div
                      key={app.id}
                      className="flex items-center justify-between p-4 glass-effect rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <img
                          src={app.user?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${app.user?.username}`}
                          alt={app.user?.username}
                          className="h-10 w-10 rounded-full"
                        />
                        <div>
                          <div className="font-medium text-white">
                            {app.user?.username}
                          </div>
                          {app.message && (
                            <div className="text-sm text-slate-400 mt-1">
                              {app.message}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <form action={async () => {
                          "use server";
                          const { acceptApplication } = await import("./actions");
                          await acceptApplication(app.id, lfg.id);
                        }}>
                          <button 
                            type="submit"
                            className="p-2 rounded-lg bg-green-500/20 hover:bg-green-500/30 text-green-400 transition-all"
                            title="Accepter"
                          >
                            <CheckCircle className="h-5 w-5" />
                          </button>
                        </form>
                        <form action={async () => {
                          "use server";
                          const { declineApplication } = await import("./actions");
                          await declineApplication(app.id, lfg.id);
                        }}>
                          <button 
                            type="submit"
                            className="p-2 rounded-lg bg-red-500/20 hover:bg-red-500/30 text-red-400 transition-all"
                            title="Refuser"
                          >
                            <XCircle className="h-5 w-5" />
                          </button>
                        </form>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
