import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "NexusGG - Communauté Gaming Ultimate",
  description: "Rejoins la plus grande communauté de gamers. Trouve des équipes, partage tes exploits et connecte-toi avec des joueurs du monde entier.",
  keywords: ["gaming", "communauté", "LFG", "esport", "jeux vidéo"],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr" className="dark">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
