"use client";

import { Gamepad2 } from "lucide-react";

interface Game {
  id: string;
  name: string;
  slug: string;
  cover_image?: string;
  genre: string[];
  platform: string[];
}

interface FavoriteGamesProps {
  games: Game[];
}

export default function FavoriteGames({ games }: FavoriteGamesProps) {
  if (!games || games.length === 0) {
    return (
      <div className="card-gaming text-center py-12">
        <Gamepad2 className="h-12 w-12 text-slate-600 mx-auto mb-4" />
        <p className="text-slate-400">Aucun jeu favori pour le moment</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {games.map((game) => (
        <div
          key={game.id}
          className="card-gaming group cursor-pointer overflow-hidden"
        >
          {/* Game Cover */}
          <div className="relative h-32 mb-3 rounded-lg overflow-hidden bg-slate-800">
            {game.cover_image ? (
              <img
                src={game.cover_image}
                alt={game.name}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-900/50 to-cyan-900/50">
                <Gamepad2 className="h-12 w-12 text-slate-600" />
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 to-transparent opacity-60" />
          </div>

          {/* Game Info */}
          <div>
            <h3 className="font-bold text-white mb-1 group-hover:text-indigo-400 transition-colors">
              {game.name}
            </h3>
            {game.genre && game.genre.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {game.genre.slice(0, 2).map((genre, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2 py-0.5 rounded bg-slate-800/50 text-slate-400"
                  >
                    {genre}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}
