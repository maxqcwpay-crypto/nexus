"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin } from "@/lib/admin/admin-service";

export async function pinPost(postId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    throw new Error("Unauthorized");
  }

  const { error } = await supabase
    .from("posts")
    .update({ is_pinned: true })
    .eq("id", postId);

  if (error) throw error;

  // Log action
  await supabase.from("admin_logs").insert({
    admin_id: user.id,
    action: "pin_post",
    target_type: "post",
    target_id: postId,
    details: {},
  });

  revalidatePath("/admin/posts");
  revalidatePath("/forum");
}

export async function unpinPost(postId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    throw new Error("Unauthorized");
  }

  const { error } = await supabase
    .from("posts")
    .update({ is_pinned: false })
    .eq("id", postId);

  if (error) throw error;

  await supabase.from("admin_logs").insert({
    admin_id: user.id,
    action: "unpin_post",
    target_type: "post",
    target_id: postId,
    details: {},
  });

  revalidatePath("/admin/posts");
  revalidatePath("/forum");
}

export async function lockPost(postId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    throw new Error("Unauthorized");
  }

  const { error } = await supabase
    .from("posts")
    .update({ is_locked: true })
    .eq("id", postId);

  if (error) throw error;

  await supabase.from("admin_logs").insert({
    admin_id: user.id,
    action: "lock_post",
    target_type: "post",
    target_id: postId,
    details: {},
  });

  revalidatePath("/admin/posts");
  revalidatePath("/forum");
}

export async function unlockPost(postId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    throw new Error("Unauthorized");
  }

  const { error } = await supabase
    .from("posts")
    .update({ is_locked: false })
    .eq("id", postId);

  if (error) throw error;

  await supabase.from("admin_logs").insert({
    admin_id: user.id,
    action: "unlock_post",
    target_type: "post",
    target_id: postId,
    details: {},
  });

  revalidatePath("/admin/posts");
  revalidatePath("/forum");
}

export async function deletePost(postId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    throw new Error("Unauthorized");
  }

  const { error } = await supabase.from("posts").delete().eq("id", postId);

  if (error) throw error;

  await supabase.from("admin_logs").insert({
    admin_id: user.id,
    action: "delete_post",
    target_type: "post",
    target_id: postId,
    details: {},
  });

  revalidatePath("/admin/posts");
  revalidatePath("/forum");
}
