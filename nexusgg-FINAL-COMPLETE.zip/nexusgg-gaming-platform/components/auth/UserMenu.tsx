"use client";

import { useState } from "react";
import Link from "next/link";
import { User, LogOut, Settings, Trophy, UserCircle } from "lucide-react";
import { createClient } from "@/lib/auth/supabase-client";
import { useRouter } from "next/navigation";
import { User as SupabaseUser } from "@supabase/supabase-js";

interface UserMenuProps {
  user: SupabaseUser;
}

export default function UserMenu({ user }: UserMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const router = useRouter();

  const handleSignOut = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  };

  const username = user.user_metadata?.username || user.email?.split("@")[0] || "Gamer";

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 p-2 rounded-lg glass-hover transition-all"
      >
        <div className="h-8 w-8 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
          <User className="h-5 w-5 text-white" />
        </div>
        <span className="text-sm font-medium text-slate-300 hidden md:block">
          {username}
        </span>
      </button>

      {isOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />

          {/* Dropdown Menu */}
          <div className="absolute right-0 mt-2 w-64 glass-effect rounded-lg border border-slate-800/50 shadow-xl z-50">
            <div className="p-4 border-b border-slate-800/50">
              <div className="flex items-center space-x-3">
                <div className="h-12 w-12 rounded-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                  <User className="h-6 w-6 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-white">{username}</div>
                  <div className="text-xs text-slate-400">{user.email}</div>
                </div>
              </div>
            </div>

            <div className="py-2">
              <Link
                href={`/profile/${username}`}
                onClick={() => setIsOpen(false)}
                className="flex items-center space-x-3 px-4 py-2 hover:bg-slate-800/50 transition-colors"
              >
                <UserCircle className="h-5 w-5 text-slate-400" />
                <span className="text-sm text-slate-300">Mon Profil</span>
              </Link>

              <Link
                href="/achievements"
                onClick={() => setIsOpen(false)}
                className="flex items-center space-x-3 px-4 py-2 hover:bg-slate-800/50 transition-colors"
              >
                <Trophy className="h-5 w-5 text-slate-400" />
                <span className="text-sm text-slate-300">Achievements</span>
              </Link>

              <Link
                href="/settings"
                onClick={() => setIsOpen(false)}
                className="flex items-center space-x-3 px-4 py-2 hover:bg-slate-800/50 transition-colors"
              >
                <Settings className="h-5 w-5 text-slate-400" />
                <span className="text-sm text-slate-300">Paramètres</span>
              </Link>
            </div>

            <div className="border-t border-slate-800/50 py-2">
              <button
                onClick={handleSignOut}
                className="flex items-center space-x-3 px-4 py-2 hover:bg-red-500/10 transition-colors w-full text-left"
              >
                <LogOut className="h-5 w-5 text-red-400" />
                <span className="text-sm text-red-400">Déconnexion</span>
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
