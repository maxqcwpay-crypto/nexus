# ✅ Système LFG (Looking For Group) Complet ! 🎮

## 🎯 Vue d'ensemble

Le système LFG permet aux joueurs de créer des demandes pour trouver des coéquipiers, postuler aux demandes d'autres joueurs, et gérer leur équipe.

## 📊 Ce qui a été créé

### 📊 Nouvelles Tables Supabase
- `lfg_posts` : Demandes LFG avec tous les détails
- `lfg_applications` : Candidatures des joueurs
- `lfg_members` : Membres acceptés dans l'équipe

### 📄 Pages
- `/app/lfg/page.tsx` : Liste des demandes avec filtres
- `/app/lfg/create/page.tsx` : Création de demande (protégée)
- `/app/lfg/[lfgId]/page.tsx` : Détails + gestion équipe

### 🎨 Composants
- `/components/lfg/LFGCard.tsx` : Card avec bouton postuler
- `/components/lfg/CreateLFGForm.tsx` : Formulaire complet

### 🛠️ Services
- `/lib/lfg/lfg-service.ts` : Toutes les fonctions CRUD
- `/supabase/lfg_tables.sql` : Script SQL complet

---

## 🚀 Installation

### 1. Créer les tables dans Supabase

```bash
# Exécute lfg_tables.sql dans Supabase SQL Editor
```

### 2. Lancer l'application

```bash
npm run dev
```

### 3. Tester

1. Va sur `/lfg`
2. Clique "Créer une demande"
3. Remplis le formulaire
4. Publie ta demande

---

## 🎮 Fonctionnalités

### ✨ Page LFG Principale

**URL :** `/lfg`

**Features :**
- Liste de toutes les demandes LFG
- **Filtres avancés** :
  - Par jeu
  - Par plateforme (PC, PS5, Xbox, Switch, Mobile)
  - Par niveau (Casual, Competitive, Any)
  - Par région (EU, NA, Asia, OCE)
  - Par statut (Ouvert, Complet)
- Bouton "Postuler" directement sur la card
- Indicateur de places restantes

### ✨ Création de Demande LFG

**URL :** `/lfg/create` (protégée)

**Champs disponibles :**
- **Jeu** (requis) - Dropdown avec tous les jeux
- **Titre** (requis) - Ex: "Cherche 2 pour Ranked"
- **Description** (requise) - Détails de la demande
- **Plateforme** (requise) - PC, PS5, Xbox, etc.
- **Joueurs recherchés** (requis) - 1 à 10
- **Niveau** - Casual, Competitive, Any
- **Région** - Pour le matchmaking géographique
- **Date/Heure** (optionnel) - Session programmée
- **Micro requis** - Checkbox vocal
- **Rang requis** (optionnel) - Ex: "Gold+"
- **Tags** - Pour recherche

**Validation :**
- Titre min 5 caractères
- Description min 10 caractères
- 1-10 joueurs max

### ✨ Détails LFG

**URL :** `/lfg/[lfgId]`

**Affichage :**
- Informations complètes de la demande
- Liste de l'équipe actuelle
- Places restantes
- Tags et filtres appliqués

**Pour le créateur :**
- Liste des candidatures en attente
- Boutons Accepter/Refuser
- Gestion des membres

**Pour les autres :**
- Bouton "Postuler"
- Message optionnel lors de la candidature
- Statut de la candidature

### ✨ Système d'Applications

**Workflow :**

1. **Joueur A** crée une demande LFG
2. **Joueur B** voit la demande et clique "Postuler"
3. **Joueur A** reçoit la candidature
4. **Joueur A** accepte ou refuse
5. Si accepté → **Joueur B** rejoint l'équipe

**Statuts :**
- `pending` - En attente de réponse
- `accepted` - Accepté, ajouté à l'équipe
- `declined` - Refusé

### ✨ Gestion Automatique

**Triggers SQL automatiques :**

1. **Compteur de joueurs** :
   - S'incrémente quand quelqu'un est accepté
   - Décrémente quand quelqu'un quitte

2. **Statut automatique** :
   - `open` → `full` quand équipe complète
   - `full` → `open` si quelqu'un quitte

3. **Expiration** :
   - Les demandes de +7 jours → `expired`
   - Fonction SQL `expire_old_lfg_posts()`

---

## 📊 Structure des Tables

### Table `lfg_posts`
```
- id (uuid)
- author_id (uuid → profiles)
- game_id (uuid → games)
- title (text)
- description (text)
- platform (PC|PS5|Xbox|Switch|Mobile)
- players_needed (integer, 1-10)
- current_players (integer)
- scheduled_time (timestamp)
- voice_required (boolean)
- skill_level (Casual|Competitive|Any)
- rank_requirement (text)
- status (open|full|closed|expired)
- tags (text[])
- region (text)
- expires_at (timestamp)
```

### Table `lfg_applications`
```
- id (uuid)
- lfg_post_id (uuid → lfg_posts)
- user_id (uuid → profiles)
- message (text)
- status (pending|accepted|declined)
```

### Table `lfg_members`
```
- id (uuid)
- lfg_post_id (uuid → lfg_posts)
- user_id (uuid → profiles)
- joined_at (timestamp)
```

---

## 🔒 Permissions (RLS)

### LFG Posts
- ✅ Tout le monde peut voir
- ✅ Utilisateurs connectés peuvent créer
- ✅ Créateur peut modifier/supprimer

### Applications
- ✅ Utilisateur voit ses propres candidatures
- ✅ Créateur du LFG voit toutes les candidatures
- ✅ Créateur peut accepter/refuser

### Members
- ✅ Tout le monde peut voir
- ✅ Créateur peut ajouter/retirer

---

## 🧪 Comment Tester

### 1. Créer une demande LFG
```
1. Va sur /lfg
2. Clique "Créer une demande"
3. Remplis le formulaire :
   - Jeu : Valorant
   - Titre : "Cherche 2 pour Ranked"
   - Plateforme : PC
   - Joueurs : 2
   - Niveau : Competitive
4. Publie
```

### 2. Postuler à une demande
```
1. Trouve une demande LFG ouverte
2. Clique "Postuler"
3. Ajoute un message (optionnel)
4. Confirme
5. Ta candidature est envoyée
```

### 3. Gérer les candidatures
```
1. Ouvre ta propre demande LFG
2. Scroll vers "Candidatures en attente"
3. Clique ✅ pour accepter ou ❌ pour refuser
4. Le joueur est ajouté à ton équipe
5. Le compteur s'incrémente automatiquement
```

### 4. Filtrer les demandes
```
1. Sur /lfg
2. Utilise les filtres sidebar :
   - Sélectionne un jeu
   - Choisis une plateforme
   - Filtre par niveau
3. Les résultats se mettent à jour
```

---

## 🎨 Design

### LFGCard
- Layout compact avec infos essentielles
- Emoji pour les plateformes (💻 🎮 📱)
- Badge de statut coloré
- Compteur de places visuels
- Bouton "Postuler" avec états

### Page Création
- Formulaire en 2 colonnes responsive
- Icons pour champs importants
- Validation en temps réel
- Preview du nombre de joueurs

### Page Détails
- Header avec toutes les infos
- Section équipe avec avatars
- Liste des candidatures (owner only)
- Boutons d'action contextuels

---

## 📝 TODO / Améliorations

### Haute priorité
- [ ] Notifications pour nouvelles candidatures
- [ ] Chat intégré dans l'équipe
- [ ] Édition de demandes LFG
- [ ] Historique des demandes

### Moyenne priorité
- [ ] Rating des joueurs post-session
- [ ] Invitations directes
- [ ] Demandes récurrentes
- [ ] Calendrier des sessions

### Basse priorité
- [ ] Statistiques LFG par joueur
- [ ] Badges LFG ("Team Player")
- [ ] Intégration Discord pour invites
- [ ] Export des équipes

---

## 🐛 Problèmes Courants

### "Impossible de postuler"
→ Vérifie que tu es connecté
→ Vérifie que le LFG n'est pas complet

### Les candidatures n'apparaissent pas
→ Vérifie les policies RLS
→ Check que tu es le créateur du LFG

### Le compteur ne se met pas à jour
→ Vérifie que les triggers sont créés
→ Exécute `lfg_tables.sql`

### Les filtres ne fonctionnent pas
→ Vérifie les searchParams dans l'URL
→ Rafraîchis la page

---

## 🎯 Workflow Complet

### Scénario : Session Ranked Valorant

1. **Alice** crée un LFG :
   - Jeu : Valorant
   - Titre : "Cherche 2 pour push Platine"
   - 2 joueurs recherchés
   - Niveau : Competitive
   - Micro requis ✅

2. **Bob** et **Charlie** voient la demande

3. **Bob** postule avec message :
   "Platine 2, bon game sense"

4. **Charlie** postule sans message

5. **Alice** voit les 2 candidatures

6. **Alice** accepte **Bob** :
   - Bob rejoint l'équipe
   - Compteur : 2/3
   - Status : toujours `open`

7. **Alice** accepte **Charlie** :
   - Charlie rejoint
   - Compteur : 3/3
   - Status → automatiquement `full`

8. L'équipe est complète ! 🎉

---

## ✅ Ce qui est COMPLET

- ✅ Création de demandes LFG
- ✅ Filtres multiples (jeu, plateforme, niveau, région)
- ✅ Système de candidatures
- ✅ Gestion d'équipe
- ✅ Statuts automatiques
- ✅ Expiration des demandes
- ✅ Page de détails
- ✅ Permissions RLS complètes
- ✅ Triggers automatiques

---

## 🎉 Félicitations !

Le système LFG est maintenant **100% fonctionnel** ! Les joueurs peuvent :
- Créer des demandes
- Postuler aux demandes
- Gérer leurs équipes
- Filtrer par préférences
- Programmer des sessions

**Le projet NexusGG est maintenant COMPLET avec toutes les fonctionnalités principales !** 🚀🎮
