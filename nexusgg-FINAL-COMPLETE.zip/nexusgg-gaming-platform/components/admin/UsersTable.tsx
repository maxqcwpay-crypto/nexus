"use client";

import { useState } from "react";
import { Search, Ban, Trash2, UserCheck, MoreVertical } from "lucide-react";
import { createClient } from "@/lib/auth/supabase-client";
import { useRouter } from "next/navigation";
import { formatDate } from "@/lib/utils";

interface UsersTableProps {
  initialUsers: any[];
  currentUserId: string;
}

export default function UsersTable({ initialUsers, currentUserId }: UsersTableProps) {
  const router = useRouter();
  const [users, setUsers] = useState(initialUsers);
  const [search, setSearch] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [showActionMenu, setShowActionMenu] = useState<string | null>(null);

  const handleBan = async (userId: string) => {
    const reason = prompt("Raison du ban:");
    if (!reason) return;

    try {
      const supabase = createClient();
      const { error } = await supabase
        .from("profiles")
        .update({
          is_banned: true,
          ban_reason: reason,
          banned_at: new Date().toISOString(),
          banned_by: currentUserId,
        })
        .eq("id", userId);

      if (error) throw error;
      
      router.refresh();
      alert("Utilisateur banni avec succès");
    } catch (error) {
      alert("Erreur lors du ban");
    }
  };

  const handleUnban = async (userId: string) => {
    try {
      const supabase = createClient();
      const { error } = await supabase
        .from("profiles")
        .update({
          is_banned: false,
          ban_reason: null,
          banned_at: null,
          banned_by: null,
        })
        .eq("id", userId);

      if (error) throw error;
      
      router.refresh();
      alert("Ban levé avec succès");
    } catch (error) {
      alert("Erreur lors du unban");
    }
  };

  const handleDelete = async (userId: string) => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer cet utilisateur ? Cette action est irréversible.")) {
      return;
    }

    try {
      const supabase = createClient();
      const { error } = await supabase.from("profiles").delete().eq("id", userId);

      if (error) throw error;
      
      router.refresh();
      alert("Utilisateur supprimé");
    } catch (error) {
      alert("Erreur lors de la suppression");
    }
  };

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(search.toLowerCase()) ||
      user.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-500" />
          <input
            type="text"
            placeholder="Rechercher un utilisateur..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="glass-effect rounded-lg border border-slate-800/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-900/50 border-b border-slate-800">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Utilisateur
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Email
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Rang
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Posts
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Inscrit le
                </th>
                <th className="px-6 py-4 text-left text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Statut
                </th>
                <th className="px-6 py-4 text-right text-xs font-medium text-slate-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-3">
                      <img
                        src={user.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`}
                        alt={user.username}
                        className="h-10 w-10 rounded-full"
                      />
                      <div>
                        <div className="text-sm font-medium text-white">{user.username}</div>
                        <div className="text-xs text-slate-500">ID: {user.id.slice(0, 8)}...</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-300">{user.email || "N/A"}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 text-xs font-semibold rounded bg-indigo-500/20 text-indigo-400">
                      {user.rank}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-300">{user.posts_count || 0}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-slate-400">
                      {formatDate(new Date(user.created_at))}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.is_banned ? (
                      <span className="px-2 py-1 text-xs font-semibold rounded bg-red-500/20 text-red-400">
                        Banni
                      </span>
                    ) : (
                      <span className="px-2 py-1 text-xs font-semibold rounded bg-green-500/20 text-green-400">
                        Actif
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="relative inline-block">
                      <button
                        onClick={() => setShowActionMenu(showActionMenu === user.id ? null : user.id)}
                        className="p-2 rounded-lg hover:bg-slate-700/50 transition-colors"
                      >
                        <MoreVertical className="h-5 w-5 text-slate-400" />
                      </button>
                      
                      {showActionMenu === user.id && (
                        <div className="absolute right-0 mt-2 w-48 glass-effect rounded-lg border border-slate-700 shadow-xl z-10">
                          {user.is_banned ? (
                            <button
                              onClick={() => {
                                handleUnban(user.id);
                                setShowActionMenu(null);
                              }}
                              className="w-full px-4 py-2 text-left text-sm text-green-400 hover:bg-slate-800/50 transition-colors flex items-center space-x-2"
                            >
                              <UserCheck className="h-4 w-4" />
                              <span>Débannir</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => {
                                handleBan(user.id);
                                setShowActionMenu(null);
                              }}
                              className="w-full px-4 py-2 text-left text-sm text-orange-400 hover:bg-slate-800/50 transition-colors flex items-center space-x-2"
                            >
                              <Ban className="h-4 w-4" />
                              <span>Bannir</span>
                            </button>
                          )}
                          <button
                            onClick={() => {
                              handleDelete(user.id);
                              setShowActionMenu(null);
                            }}
                            className="w-full px-4 py-2 text-left text-sm text-red-400 hover:bg-slate-800/50 transition-colors flex items-center space-x-2 border-t border-slate-800"
                          >
                            <Trash2 className="h-4 w-4" />
                            <span>Supprimer</span>
                          </button>
                        </div>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-12 text-slate-400">
          Aucun utilisateur trouvé
        </div>
      )}
    </div>
  );
}
