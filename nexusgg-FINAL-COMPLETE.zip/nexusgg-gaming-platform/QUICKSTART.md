# 🚀 Guide de Démarrage Rapide - NexusGG

## Installation en 3 étapes

### 1️⃣ Installer les dépendances

```bash
cd nexusgg-gaming-platform
npm install
```

### 2️⃣ Lancer le serveur de développement

```bash
npm run dev
```

### 3️⃣ Ouvrir dans le navigateur

Aller sur [http://localhost:3000](http://localhost:3000)

---

## ✅ Ce qui est inclus dans cette version

### Pages
- ✅ Landing Page complète avec hero section
- ✅ Section "Derniers Posts" avec données mockées

### Composants
- ✅ Navbar responsive avec glassmorphism
- ✅ Hero section immersive
- ✅ Grid de posts avec stats
- ✅ Footer complet

### Fonctionnalités
- ✅ Design gaming dark mode
- ✅ Effets néon (indigo/cyan)
- ✅ Animations (float, glow, hover)
- ✅ Responsive mobile-first
- ✅ TypeScript strict
- ✅ Tailwind CSS configuré

---

## 🎨 Personnalisation Rapide

### Changer les couleurs principales

Dans `tailwind.config.js`:
```js
neon: {
  purple: '#a855f7',  // Modifier ici
  blue: '#06b6d4',    // Modifier ici
  pink: '#ec4899',    // Modifier ici
}
```

### Modifier le nom de la plateforme

Dans `components/Navbar.tsx`:
```tsx
<span className="text-2xl font-bold neon-text">NexusGG</span>
```

### Ajouter des posts

Dans `components/LatestPosts.tsx`, modifier le tableau `mockPosts`.

---

## 📁 Fichiers Importants

| Fichier | Description |
|---------|-------------|
| `app/page.tsx` | Page d'accueil principale |
| `app/layout.tsx` | Layout racine avec metadata |
| `app/globals.css` | Styles globaux et thème |
| `components/Navbar.tsx` | Navigation |
| `components/HeroSection.tsx` | Hero section |
| `components/LatestPosts.tsx` | Liste des posts |
| `types.ts` | Toutes les interfaces TypeScript |
| `tailwind.config.js` | Configuration Tailwind |

---

## 🐛 Problèmes Courants

### Les images ne s'affichent pas
Vérifier que les URLs dans `next.config.js` sont bien ajoutées:
```js
images: {
  domains: ['images.unsplash.com', 'api.dicebear.com'],
}
```

### Erreur de compilation TypeScript
Vérifier que tous les imports sont corrects et que `tsconfig.json` est bien configuré.

### Tailwind ne fonctionne pas
1. Vérifier que `globals.css` est bien importé dans `layout.tsx`
2. Relancer le serveur: `npm run dev`

---

## 🔜 Prochaines Étapes Suggérées

1. **Authentification** - Implémenter login/signup
2. **Base de données** - Connecter Supabase
3. **Profils** - Pages de profils utilisateurs
4. **Forum** - Système de posts complet
5. **LFG** - Looking For Group feature

---

## 💡 Conseils pour Cursor AI

- Utilisez `Cmd/Ctrl + K` pour générer du code
- Demandez à modifier un composant spécifique
- Utilisez les types dans `types.ts` pour l'auto-complétion
- Les composants sont modulaires pour une édition facile

---

**Besoin d'aide?** Consultez le README.md principal pour plus de détails!
