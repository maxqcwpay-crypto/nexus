import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin, getAllUsers } from "@/lib/admin/admin-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import UsersTable from "@/components/admin/UsersTable";

export default async function AdminUsersPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const { users } = await getAllUsers();

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">
              Gestion des Utilisateurs
            </h1>
            <p className="text-slate-400">
              {users.length} utilisateurs au total
            </p>
          </div>

          <UsersTable initialUsers={users} currentUserId={user.id} />
        </div>
      </main>
    </div>
  );
}
