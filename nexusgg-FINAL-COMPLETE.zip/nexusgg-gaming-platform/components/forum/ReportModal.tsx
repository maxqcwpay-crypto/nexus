"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { X, Flag, Loader2 } from "lucide-react";
import { createClient } from "@/lib/auth/supabase-client";

interface ReportModalProps {
  targetType: "post" | "comment" | "user";
  targetId: string;
  onClose: () => void;
}

const reportReasons = [
  "Spam",
  "Contenu offensant",
  "Harcèlement",
  "Désinformation",
  "Contenu inapproprié",
  "Violation des règles",
  "Autre",
];

export default function ReportModal({
  targetType,
  targetId,
  onClose,
}: ReportModalProps) {
  const router = useRouter();
  const [reason, setReason] = useState("");
  const [description, setDescription] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason) return;

    setIsSubmitting(true);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const { error } = await supabase.from("reports").insert({
        reporter_id: user.id,
        target_type: targetType,
        target_id: targetId,
        reason,
        description: description.trim() || null,
      });

      if (error) throw error;

      alert("Signalement envoyé avec succès");
      onClose();
    } catch (error) {
      console.error("Error submitting report:", error);
      alert("Erreur lors de l'envoi du signalement");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80">
      <div className="w-full max-w-md glass-effect rounded-lg border border-slate-800/50 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-2">
            <Flag className="h-5 w-5 text-red-400" />
            <h2 className="text-xl font-bold text-white">Signaler</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-slate-800/50 transition-colors"
          >
            <X className="h-5 w-5 text-slate-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Raison du signalement *
            </label>
            <select
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all outline-none text-white"
              required
            >
              <option value="">Sélectionner une raison...</option>
              {reportReasons.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Description (optionnel)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-red-500 focus:ring-2 focus:ring-red-500/20 transition-all outline-none text-white resize-none"
              placeholder="Donnez plus de détails sur le problème..."
            />
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3">
            <p className="text-xs text-yellow-200">
              Les signalements sont examinés par notre équipe de modération. Les faux
              signalements peuvent entraîner des sanctions.
            </p>
          </div>

          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800/50">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 rounded-lg glass-effect border border-slate-700 hover:border-slate-600 text-slate-300 font-medium transition-all"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !reason}
              className="px-6 py-3 rounded-lg bg-red-500 hover:bg-red-600 text-white font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  <span>Envoi...</span>
                </>
              ) : (
                <>
                  <Flag className="h-5 w-5" />
                  <span>Signaler</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
