import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: number | string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  color?: "indigo" | "cyan" | "purple" | "green";
}

const colorClasses = {
  indigo: "text-indigo-400 bg-indigo-500/20",
  cyan: "text-cyan-400 bg-cyan-500/20",
  purple: "text-purple-400 bg-purple-500/20",
  green: "text-green-400 bg-green-500/20",
};

export default function StatsCard({
  title,
  value,
  icon: Icon,
  trend,
  color = "indigo",
}: StatsCardProps) {
  return (
    <div className="glass-effect rounded-lg p-6 border border-slate-800/50">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon className="h-6 w-6" />
        </div>
        {trend && (
          <div
            className={`text-sm font-medium ${
              trend.isPositive ? "text-green-400" : "text-red-400"
            }`}
          >
            {trend.isPositive ? "+" : ""}
            {trend.value}%
          </div>
        )}
      </div>
      <div className="text-3xl font-bold text-white mb-1">{value}</div>
      <div className="text-sm text-slate-400">{title}</div>
    </div>
  );
}
