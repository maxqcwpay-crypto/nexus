import Link from "next/link";
import { PlusCircle, TrendingUp, Clock, Trophy } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PostCard from "@/components/forum/PostCard";
import { getPosts } from "@/lib/forum/forum-service";
import { getAllGames } from "@/lib/profile/profile-service";
import { createClient } from "@/lib/auth/supabase-server";

interface ForumPageProps {
  searchParams: {
    game?: string;
    tag?: string;
    search?: string;
    sort?: 'recent' | 'top' | 'trending';
  };
}

export default async function ForumPage({ searchParams }: ForumPageProps) {
  const { game, tag, search, sort = 'recent' } = searchParams;

  const { posts } = await getPosts({
    gameId: game,
    tag,
    search,
    sort,
    page: 1,
    pageSize: 20,
  });

  const games = await getAllGames();

  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const sortOptions = [
    { value: 'recent', label: 'Récents', icon: Clock },
    { value: 'top', label: 'Top', icon: Trophy },
    { value: 'trending', label: 'Tendances', icon: TrendingUp },
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
            <div>
              <h1 className="text-4xl font-bold neon-text mb-2">Forum</h1>
              <p className="text-slate-400">
                Partage tes exploits et discute avec la communauté
              </p>
            </div>
            {user && (
              <Link
                href="/forum/create"
                className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold transition-all duration-300 shadow-lg hover:shadow-indigo-500/50"
              >
                <PlusCircle className="h-5 w-5" />
                <span>Créer un post</span>
              </Link>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Sidebar */}
            <aside className="lg:col-span-1">
              <div className="space-y-4">
                {/* Sort Options */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3">Trier par</h3>
                  <div className="space-y-2">
                    {sortOptions.map((option) => {
                      const Icon = option.icon;
                      const isActive = sort === option.value;
                      return (
                        <Link
                          key={option.value}
                          href={`/forum?sort=${option.value}${game ? `&game=${game}` : ''}${tag ? `&tag=${tag}` : ''}`}
                          className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all ${
                            isActive
                              ? 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30'
                              : 'hover:bg-slate-800/50 text-slate-400'
                          }`}
                        >
                          <Icon className="h-4 w-4" />
                          <span className="text-sm font-medium">
                            {option.label}
                          </span>
                        </Link>
                      );
                    })}
                  </div>
                </div>

                {/* Games Filter */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3">
                    Filtrer par jeu
                  </h3>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    <Link
                      href="/forum"
                      className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                        !game
                          ? 'bg-indigo-500/20 text-indigo-400'
                          : 'hover:bg-slate-800/50 text-slate-400'
                      }`}
                    >
                      Tous les jeux
                    </Link>
                    {games.map((g) => (
                      <Link
                        key={g.id}
                        href={`/forum?game=${g.id}&sort=${sort}`}
                        className={`block px-3 py-2 rounded-lg text-sm transition-all ${
                          game === g.id
                            ? 'bg-indigo-500/20 text-indigo-400'
                            : 'hover:bg-slate-800/50 text-slate-400'
                        }`}
                      >
                        {g.name}
                      </Link>
                    ))}
                  </div>
                </div>

                {/* Rules */}
                <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
                  <h3 className="font-semibold text-white mb-3">
                    Règles du forum
                  </h3>
                  <ul className="space-y-2 text-sm text-slate-400">
                    <li>• Respecte les autres joueurs</li>
                    <li>• Pas de spam ou contenu NSFW</li>
                    <li>• Pas de toxicité</li>
                    <li>• Utilise les bons tags</li>
                  </ul>
                </div>
              </div>
            </aside>

            {/* Posts List */}
            <div className="lg:col-span-3">
              {posts.length === 0 ? (
                <div className="card-gaming text-center py-12">
                  <p className="text-slate-400 mb-4">
                    Aucun post pour le moment
                  </p>
                  {user && (
                    <Link
                      href="/forum/create"
                      className="inline-flex items-center space-x-2 px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-semibold"
                    >
                      <PlusCircle className="h-5 w-5" />
                      <span>Créer le premier post</span>
                    </Link>
                  )}
                </div>
              ) : (
                <div className="space-y-4">
                  {posts.map((post) => (
                    <PostCard key={post.id} post={post} currentUserId={user?.id} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
