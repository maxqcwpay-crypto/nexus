"use client";

import { MessageSquare, ThumbsUp, Eye } from "lucide-react";
import { Post } from "@/types";
import { formatRelativeTime } from "@/lib/utils";

// Mock data
const mockPosts: Post[] = [
  {
    id: "1",
    authorId: "user1",
    author: {
      id: "user1",
      username: "ProGamer_X",
      email: "user1@example.com",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ProGamerX",
      createdAt: new Date("2024-01-15"),
      updatedAt: new Date("2024-01-15"),
      favoriteGames: [],
      rank: "Elite",
      badges: [],
    },
    title: "Nouveau meta Valorant - Patch 8.0",
    content:
      "Le nouveau patch a complètement changé le meta. Voici mon analyse complète des changements...",
    mediaUrl: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800",
    mediaType: "image",
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2h ago
    updatedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    upvotes: 234,
    downvotes: 12,
    commentCount: 45,
    tags: ["Valorant", "Meta", "Patch"],
    gameId: "valorant",
  },
  {
    id: "2",
    authorId: "user2",
    author: {
      id: "user2",
      username: "StratMaster",
      email: "user2@example.com",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=StratMaster",
      createdAt: new Date("2024-01-10"),
      updatedAt: new Date("2024-01-10"),
      favoriteGames: [],
      rank: "Pro",
      badges: [],
    },
    title: "Mon clutch 1v5 en Ranked",
    content: "Impossible de croire ce qui s'est passé hier soir...",
    mediaUrl: "https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800",
    mediaType: "video",
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000), // 5h ago
    updatedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
    upvotes: 567,
    downvotes: 8,
    commentCount: 89,
    tags: ["CS2", "Clutch", "Ranked"],
    gameId: "cs2",
  },
  {
    id: "3",
    authorId: "user3",
    author: {
      id: "user3",
      username: "LeagueQueen",
      email: "user3@example.com",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=LeagueQueen",
      createdAt: new Date("2024-01-05"),
      updatedAt: new Date("2024-01-05"),
      favoriteGames: [],
      rank: "Legend",
      badges: [],
    },
    title: "Guide complet: Yasuo Mid S14",
    content:
      "Après 500h sur Yasuo, voici tout ce que vous devez savoir pour carry vos games...",
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
    updatedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    upvotes: 892,
    downvotes: 45,
    commentCount: 156,
    tags: ["League of Legends", "Guide", "Yasuo"],
    gameId: "lol",
  },
];

export default function LatestPosts() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-slate-950">
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="neon-text">Derniers Posts</span> de la Communauté
          </h2>
          <p className="text-slate-400 text-lg">
            Découvre ce que les joueurs partagent en ce moment
          </p>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mockPosts.map((post) => (
            <article
              key={post.id}
              className="card-gaming group cursor-pointer"
            >
              {/* Post Image */}
              {post.mediaUrl && (
                <div className="relative h-48 mb-4 rounded-lg overflow-hidden">
                  <img
                    src={post.mediaUrl}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  {post.mediaType === "video" && (
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                      <div className="h-12 w-12 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <div className="w-0 h-0 border-l-[12px] border-l-white border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent ml-1" />
                      </div>
                    </div>
                  )}
                  <div className="absolute top-2 right-2">
                    <span className="px-2 py-1 text-xs font-semibold bg-indigo-500/80 backdrop-blur-sm rounded">
                      {post.tags[0]}
                    </span>
                  </div>
                </div>
              )}

              {/* Author Info */}
              <div className="flex items-center space-x-3 mb-3">
                <img
                  src={post.author.avatar}
                  alt={post.author.username}
                  className="h-10 w-10 rounded-full border-2 border-indigo-500/30"
                />
                <div>
                  <div className="font-medium text-white">
                    {post.author.username}
                  </div>
                  <div className="text-xs text-slate-500">
                    {formatRelativeTime(post.createdAt)}
                  </div>
                </div>
              </div>

              {/* Post Title */}
              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
                {post.title}
              </h3>

              {/* Post Content Preview */}
              <p className="text-slate-400 text-sm mb-4 line-clamp-2">
                {post.content}
              </p>

              {/* Post Stats */}
              <div className="flex items-center justify-between text-sm text-slate-500">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-1 hover:text-indigo-400 transition-colors">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{post.upvotes}</span>
                  </div>
                  <div className="flex items-center space-x-1 hover:text-cyan-400 transition-colors">
                    <MessageSquare className="h-4 w-4" />
                    <span>{post.commentCount}</span>
                  </div>
                </div>
                <div className="px-2 py-1 rounded bg-slate-800/50 text-xs font-medium">
                  {post.author.rank}
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button className="px-8 py-3 rounded-lg glass-effect border border-indigo-500/30 hover:border-indigo-500 text-white font-medium transition-all duration-300 hover:shadow-lg hover:shadow-indigo-500/20">
            Voir tous les posts
          </button>
        </div>
      </div>
    </section>
  );
}
