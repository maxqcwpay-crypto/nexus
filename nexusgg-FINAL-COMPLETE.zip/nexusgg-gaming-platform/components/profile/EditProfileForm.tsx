"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import {
  User,
  Upload,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Twitch,
  X,
  Gamepad2,
} from "lucide-react";
import { createClient } from "@/lib/auth/supabase-client";
import { UserProfile } from "@/lib/profile/profile-service";

interface EditProfileFormProps {
  profile: UserProfile;
  availableGames: any[];
}

interface ProfileFormData {
  username: string;
  bio: string;
  twitch_url: string;
  steam_url: string;
  discord_tag: string;
}

export default function EditProfileForm({
  profile,
  availableGames,
}: EditProfileFormProps) {
  const router = useRouter();
  const [error, setError] = useState<string>("");
  const [success, setSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState(profile.avatar_url || "");
  const [selectedGames, setSelectedGames] = useState<string[]>(
    profile.favorite_games?.map((fg: any) => fg.game.id) || []
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<ProfileFormData>({
    defaultValues: {
      username: profile.username,
      bio: profile.bio || "",
      twitch_url: profile.twitch_url || "",
      steam_url: profile.steam_url || "",
      discord_tag: profile.discord_tag || "",
    },
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("L'image ne doit pas dépasser 5MB");
        return;
      }
      setAvatarFile(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const toggleGame = (gameId: string) => {
    setSelectedGames((prev) =>
      prev.includes(gameId)
        ? prev.filter((id) => id !== gameId)
        : [...prev, gameId]
    );
  };

  const onSubmit = async (data: ProfileFormData) => {
    setError("");
    setSuccess(false);
    setIsLoading(true);

    try {
      const supabase = createClient();

      // Upload avatar if changed
      let avatarUrl = profile.avatar_url;
      if (avatarFile) {
        const fileExt = avatarFile.name.split(".").pop();
        const fileName = `${profile.id}-${Date.now()}.${fileExt}`;
        const filePath = `avatars/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from("avatars")
          .upload(filePath, avatarFile, {
            cacheControl: "3600",
            upsert: true,
          });

        if (uploadError) throw uploadError;

        const {
          data: { publicUrl },
        } = supabase.storage.from("avatars").getPublicUrl(filePath);

        avatarUrl = publicUrl;
      }

      // Update profile
      const { error: updateError } = await supabase
        .from("profiles")
        .update({
          username: data.username,
          bio: data.bio,
          twitch_url: data.twitch_url,
          steam_url: data.steam_url,
          discord_tag: data.discord_tag,
          avatar_url: avatarUrl,
          updated_at: new Date().toISOString(),
        })
        .eq("id", profile.id);

      if (updateError) throw updateError;

      // Update favorite games
      // First delete all existing
      await supabase
        .from("user_favorite_games")
        .delete()
        .eq("user_id", profile.id);

      // Then insert new ones
      if (selectedGames.length > 0) {
        const gamesToInsert = selectedGames.map((gameId) => ({
          user_id: profile.id,
          game_id: gameId,
        }));

        const { error: gamesError } = await supabase
          .from("user_favorite_games")
          .insert(gamesToInsert);

        if (gamesError) throw gamesError;
      }

      setSuccess(true);
      setTimeout(() => {
        router.push(`/profile/${data.username}`);
        router.refresh();
      }, 2000);
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue");
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
      {/* Messages */}
      {error && (
        <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/50 flex items-start space-x-3">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-200">{error}</p>
        </div>
      )}

      {success && (
        <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/50 flex items-start space-x-3">
          <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-green-200">
            Profil mis à jour avec succès ! Redirection...
          </p>
        </div>
      )}

      {/* Avatar Upload */}
      <div>
        <label className="block text-sm font-medium text-slate-300 mb-4">
          Photo de profil
        </label>
        <div className="flex items-center space-x-6">
          <div className="h-24 w-24 rounded-full overflow-hidden glass-effect">
            {avatarPreview ? (
              <img
                src={avatarPreview}
                alt="Avatar"
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="h-full w-full bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center">
                <User className="h-12 w-12 text-white" />
              </div>
            )}
          </div>
          <label className="cursor-pointer px-4 py-2 rounded-lg glass-effect border border-slate-700 hover:border-indigo-500 transition-all flex items-center space-x-2">
            <Upload className="h-4 w-4 text-slate-400" />
            <span className="text-sm text-slate-300">Changer</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleAvatarChange}
              className="hidden"
            />
          </label>
        </div>
        <p className="text-xs text-slate-500 mt-2">
          JPG, PNG ou GIF. Max 5MB.
        </p>
      </div>

      {/* Username */}
      <div>
        <label
          htmlFor="username"
          className="block text-sm font-medium text-slate-300 mb-2"
        >
          Nom d&apos;utilisateur
        </label>
        <input
          {...register("username", { required: true, minLength: 3 })}
          type="text"
          id="username"
          className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
        />
        {errors.username && (
          <p className="mt-1 text-sm text-red-400">
            Le nom d&apos;utilisateur doit contenir au moins 3 caractères
          </p>
        )}
      </div>

      {/* Bio */}
      <div>
        <label
          htmlFor="bio"
          className="block text-sm font-medium text-slate-300 mb-2"
        >
          Biographie
        </label>
        <textarea
          {...register("bio")}
          id="bio"
          rows={4}
          maxLength={200}
          className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white resize-none"
          placeholder="Parle-nous de toi..."
        />
        <p className="text-xs text-slate-500 mt-1">Maximum 200 caractères</p>
      </div>

      {/* Social Links */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Liens sociaux</h3>

        <div>
          <label
            htmlFor="twitch_url"
            className="block text-sm font-medium text-slate-300 mb-2"
          >
            Twitch
          </label>
          <div className="relative">
            <Twitch className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-500" />
            <input
              {...register("twitch_url")}
              type="url"
              id="twitch_url"
              className="w-full pl-10 pr-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
              placeholder="https://twitch.tv/username"
            />
          </div>
        </div>

        <div>
          <label
            htmlFor="steam_url"
            className="block text-sm font-medium text-slate-300 mb-2"
          >
            Steam
          </label>
          <input
            {...register("steam_url")}
            type="url"
            id="steam_url"
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
            placeholder="https://steamcommunity.com/id/username"
          />
        </div>

        <div>
          <label
            htmlFor="discord_tag"
            className="block text-sm font-medium text-slate-300 mb-2"
          >
            Discord
          </label>
          <input
            {...register("discord_tag")}
            type="text"
            id="discord_tag"
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
            placeholder="username#1234"
          />
        </div>
      </div>

      {/* Favorite Games */}
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">
          Jeux Favoris (max 6)
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {availableGames.map((game) => {
            const isSelected = selectedGames.includes(game.id);
            return (
              <button
                key={game.id}
                type="button"
                onClick={() =>
                  selectedGames.length < 6 || isSelected
                    ? toggleGame(game.id)
                    : null
                }
                className={`relative p-3 rounded-lg border transition-all ${
                  isSelected
                    ? "border-indigo-500 bg-indigo-500/10"
                    : "border-slate-700 glass-effect hover:border-slate-600"
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Gamepad2
                    className={`h-5 w-5 ${
                      isSelected ? "text-indigo-400" : "text-slate-500"
                    }`}
                  />
                  <span
                    className={`text-sm font-medium ${
                      isSelected ? "text-white" : "text-slate-300"
                    }`}
                  >
                    {game.name}
                  </span>
                </div>
                {isSelected && (
                  <div className="absolute top-2 right-2 h-5 w-5 rounded-full bg-indigo-500 flex items-center justify-center">
                    <X className="h-3 w-3 text-white" />
                  </div>
                )}
              </button>
            );
          })}
        </div>
        <p className="text-xs text-slate-500 mt-2">
          {selectedGames.length}/6 sélectionnés
        </p>
      </div>

      {/* Submit */}
      <div className="flex items-center justify-end space-x-4 pt-6 border-t border-slate-800/50">
        <button
          type="button"
          onClick={() => router.back()}
          className="px-6 py-3 rounded-lg glass-effect border border-slate-700 hover:border-slate-600 text-slate-300 font-medium transition-all"
        >
          Annuler
        </button>
        <button
          type="submit"
          disabled={isLoading}
          className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold transition-all duration-300 shadow-lg hover:shadow-indigo-500/50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Enregistrement...</span>
            </>
          ) : (
            <span>Enregistrer</span>
          )}
        </button>
      </div>
    </form>
  );
}
