-- LFG (Looking For Group) System Tables

-- LFG Posts table
create table if not exists lfg_posts (
  id uuid default gen_random_uuid() primary key,
  author_id uuid references profiles(id) on delete cascade not null,
  game_id uuid references games(id) on delete cascade not null,
  title text not null,
  description text not null,
  platform text check (platform in ('PC', 'PS5', 'Xbox', 'Switch', 'Mobile')) not null,
  players_needed integer not null check (players_needed > 0 and players_needed <= 10),
  current_players integer default 1 check (current_players >= 0),
  scheduled_time timestamp with time zone,
  voice_required boolean default false,
  skill_level text check (skill_level in ('Casual', 'Competitive', 'Any')) default 'Any',
  rank_requirement text,
  status text check (status in ('open', 'full', 'closed', 'expired')) default 'open',
  tags text[] default '{}',
  region text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  expires_at timestamp with time zone
);

-- LFG Applications table
create table if not exists lfg_applications (
  id uuid default gen_random_uuid() primary key,
  lfg_post_id uuid references lfg_posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  message text,
  status text check (status in ('pending', 'accepted', 'declined')) default 'pending',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now(),
  unique(lfg_post_id, user_id)
);

-- LFG Members (accepted applications)
create table if not exists lfg_members (
  id uuid default gen_random_uuid() primary key,
  lfg_post_id uuid references lfg_posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  joined_at timestamp with time zone default now(),
  unique(lfg_post_id, user_id)
);

-- Enable RLS
alter table lfg_posts enable row level security;
alter table lfg_applications enable row level security;
alter table lfg_members enable row level security;

-- Policies for lfg_posts
create policy "LFG posts are viewable by everyone"
  on lfg_posts for select
  using (true);

create policy "Authenticated users can create LFG posts"
  on lfg_posts for insert
  with check (auth.uid() = author_id);

create policy "Users can update their own LFG posts"
  on lfg_posts for update
  using (auth.uid() = author_id);

create policy "Users can delete their own LFG posts"
  on lfg_posts for delete
  using (auth.uid() = author_id);

-- Policies for lfg_applications
create policy "Users can view applications to their posts"
  on lfg_applications for select
  using (
    auth.uid() = user_id
    or exists (
      select 1 from lfg_posts
      where lfg_posts.id = lfg_applications.lfg_post_id
      and lfg_posts.author_id = auth.uid()
    )
  );

create policy "Users can create applications"
  on lfg_applications for insert
  with check (auth.uid() = user_id);

create policy "Post owners can update applications"
  on lfg_applications for update
  using (
    exists (
      select 1 from lfg_posts
      where lfg_posts.id = lfg_applications.lfg_post_id
      and lfg_posts.author_id = auth.uid()
    )
  );

create policy "Users can delete their own applications"
  on lfg_applications for delete
  using (auth.uid() = user_id);

-- Policies for lfg_members
create policy "LFG members are viewable by everyone"
  on lfg_members for select
  using (true);

create policy "Post owners can add members"
  on lfg_members for insert
  with check (
    exists (
      select 1 from lfg_posts
      where lfg_posts.id = lfg_members.lfg_post_id
      and lfg_posts.author_id = auth.uid()
    )
  );

create policy "Post owners can remove members"
  on lfg_members for delete
  using (
    exists (
      select 1 from lfg_posts
      where lfg_posts.id = lfg_members.lfg_post_id
      and lfg_posts.author_id = auth.uid()
    )
  );

-- Function to update LFG status based on members
create or replace function update_lfg_status()
returns trigger as $$
begin
  -- Update current_players count
  update lfg_posts
  set current_players = (
    select count(*) from lfg_members
    where lfg_members.lfg_post_id = NEW.lfg_post_id
  ) + 1 -- +1 for the author
  where id = NEW.lfg_post_id;
  
  -- Update status to full if needed
  update lfg_posts
  set status = 'full'
  where id = NEW.lfg_post_id
  and current_players >= players_needed
  and status = 'open';
  
  return NEW;
end;
$$ language plpgsql;

-- Trigger to update status when member is added
drop trigger if exists on_lfg_member_added on lfg_members;
create trigger on_lfg_member_added
  after insert on lfg_members
  for each row execute procedure update_lfg_status();

-- Function to reopen LFG when member leaves
create or replace function update_lfg_on_member_leave()
returns trigger as $$
begin
  -- Update current_players count
  update lfg_posts
  set current_players = (
    select count(*) from lfg_members
    where lfg_members.lfg_post_id = OLD.lfg_post_id
  ) + 1
  where id = OLD.lfg_post_id;
  
  -- Reopen if was full
  update lfg_posts
  set status = 'open'
  where id = OLD.lfg_post_id
  and current_players < players_needed
  and status = 'full';
  
  return OLD;
end;
$$ language plpgsql;

-- Trigger when member leaves
drop trigger if exists on_lfg_member_removed on lfg_members;
create trigger on_lfg_member_removed
  after delete on lfg_members
  for each row execute procedure update_lfg_on_member_leave();

-- Function to expire old LFG posts
create or replace function expire_old_lfg_posts()
returns void as $$
begin
  update lfg_posts
  set status = 'expired'
  where status = 'open'
  and (
    expires_at is not null and expires_at < now()
    or (expires_at is null and created_at < now() - interval '7 days')
  );
end;
$$ language plpgsql;

-- Indexes for performance
create index if not exists lfg_posts_game_id_idx on lfg_posts(game_id);
create index if not exists lfg_posts_status_idx on lfg_posts(status);
create index if not exists lfg_posts_created_at_idx on lfg_posts(created_at desc);
create index if not exists lfg_posts_platform_idx on lfg_posts(platform);
create index if not exists lfg_applications_lfg_post_id_idx on lfg_applications(lfg_post_id);
create index if not exists lfg_applications_user_id_idx on lfg_applications(user_id);
create index if not exists lfg_members_lfg_post_id_idx on lfg_members(lfg_post_id);
