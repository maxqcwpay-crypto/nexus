"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/auth/supabase-server";

export async function acceptApplication(applicationId: string, lfgId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    throw new Error("Unauthorized");
  }

  // Get application details
  const { data: application } = await supabase
    .from("lfg_applications")
    .select("*")
    .eq("id", applicationId)
    .single();

  if (!application) {
    throw new Error("Application not found");
  }

  // Verify user is the LFG owner
  const { data: lfg } = await supabase
    .from("lfg_posts")
    .select("author_id")
    .eq("id", application.lfg_post_id)
    .single();

  if (!lfg || lfg.author_id !== user.id) {
    throw new Error("Unauthorized");
  }

  // Update application status
  await supabase
    .from("lfg_applications")
    .update({ status: "accepted", updated_at: new Date().toISOString() })
    .eq("id", applicationId);

  // Add to members
  await supabase.from("lfg_members").insert({
    lfg_post_id: application.lfg_post_id,
    user_id: application.user_id,
  });

  revalidatePath(`/lfg/${lfgId}`);
  revalidatePath("/lfg");
}

export async function declineApplication(applicationId: string, lfgId: string) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    throw new Error("Unauthorized");
  }

  // Get application details
  const { data: application } = await supabase
    .from("lfg_applications")
    .select("*")
    .eq("id", applicationId)
    .single();

  if (!application) {
    throw new Error("Application not found");
  }

  // Verify user is the LFG owner
  const { data: lfg } = await supabase
    .from("lfg_posts")
    .select("author_id")
    .eq("id", application.lfg_post_id)
    .single();

  if (!lfg || lfg.author_id !== user.id) {
    throw new Error("Unauthorized");
  }

  // Update application status
  await supabase
    .from("lfg_applications")
    .update({ status: "declined", updated_at: new Date().toISOString() })
    .eq("id", applicationId);

  revalidatePath(`/lfg/${lfgId}`);
  revalidatePath("/lfg");
}
