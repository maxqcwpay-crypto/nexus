import { Gamepad2 } from "lucide-react";
import Link from "next/link";
import LoginForm from "@/components/auth/LoginForm";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(168,85,247,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(168,85,247,0.03)_1px,transparent_1px)] bg-[size:64px_64px]" />
        <div className="absolute top-1/4 -left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 -right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-1000" />
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-6xl flex flex-col lg:flex-row items-center gap-12">
        {/* Left Side - Branding */}
        <div className="flex-1 text-center lg:text-left">
          <Link
            href="/"
            className="inline-flex items-center space-x-3 mb-8 group"
          >
            <Gamepad2 className="h-10 w-10 text-indigo-500 group-hover:text-cyan-400 transition-colors" />
            <span className="text-3xl font-bold neon-text">NexusGG</span>
          </Link>

          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Reprends
            <br />
            <span className="neon-text">la partie</span>
          </h1>

          <p className="text-xl text-slate-400 mb-8 max-w-lg">
            Connecte-toi pour retrouver ton équipe, partager tes meilleurs
            moments et continuer ta progression.
          </p>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-4 max-w-md">
            <div className="glass-effect rounded-lg p-4">
              <div className="text-2xl font-bold text-indigo-400 mb-1">
                100K+
              </div>
              <div className="text-xs text-slate-500">Joueurs</div>
            </div>
            <div className="glass-effect rounded-lg p-4">
              <div className="text-2xl font-bold text-cyan-400 mb-1">5K+</div>
              <div className="text-xs text-slate-500">Équipes</div>
            </div>
            <div className="glass-effect rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-400 mb-1">24/7</div>
              <div className="text-xs text-slate-500">Actif</div>
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex-1 w-full max-w-md">
          <LoginForm />
        </div>
      </div>
    </div>
  );
}
