import { createClient } from '@/lib/auth/supabase-server'

export interface ForumPost {
  id: string
  author_id: string
  author?: any
  game_id?: string
  game?: any
  title: string
  content: string
  media_url?: string
  media_type?: 'image' | 'video' | 'clip'
  upvotes: number
  downvotes: number
  comment_count: number
  tags: string[]
  is_pinned: boolean
  is_locked: boolean
  created_at: string
  updated_at: string
  user_vote?: 'upvote' | 'downvote' | null
}

export interface ForumComment {
  id: string
  post_id: string
  author_id: string
  author?: any
  parent_comment_id?: string
  content: string
  upvotes: number
  downvotes: number
  created_at: string
  updated_at: string
  replies?: ForumComment[]
  user_vote?: 'upvote' | 'downvote' | null
}

export type PostSortOption = 'recent' | 'top' | 'trending'

export async function getPosts(
  options: {
    gameId?: string
    tag?: string
    search?: string
    sort?: PostSortOption
    page?: number
    pageSize?: number
  } = {}
): Promise<{ posts: ForumPost[]; totalCount: number }> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const {
    gameId,
    tag,
    search,
    sort = 'recent',
    page = 1,
    pageSize = 10,
  } = options

  let query = supabase
    .from('posts')
    .select(
      `
      *,
      author:profiles!posts_author_id_fkey(*),
      game:games(*),
      user_vote:post_votes!post_votes_post_id_fkey(vote_type)
    `,
      { count: 'exact' }
    )

  // Filters
  if (gameId) {
    query = query.eq('game_id', gameId)
  }

  if (tag) {
    query = query.contains('tags', [tag])
  }

  if (search) {
    query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`)
  }

  // Sorting
  if (sort === 'recent') {
    query = query.order('created_at', { ascending: false })
  } else if (sort === 'top') {
    query = query.order('upvotes', { ascending: false })
  } else if (sort === 'trending') {
    // Simple trending: recent posts with high upvotes
    query = query
      .gte('created_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString())
      .order('upvotes', { ascending: false })
  }

  // Pagination
  const from = (page - 1) * pageSize
  const to = from + pageSize - 1
  query = query.range(from, to)

  const { data: posts, error, count } = await query

  if (error) {
    throw error
  }

  // Filter user votes
  const postsWithVotes = posts?.map((post) => ({
    ...post,
    user_vote: user
      ? post.user_vote?.find((v: any) => v.vote_type)?.vote_type || null
      : null,
  }))

  return {
    posts: postsWithVotes || [],
    totalCount: count || 0,
  }
}

export async function getPostById(postId: string): Promise<ForumPost | null> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const { data: post, error } = await supabase
    .from('posts')
    .select(
      `
      *,
      author:profiles!posts_author_id_fkey(*),
      game:games(*),
      user_vote:post_votes!post_votes_post_id_fkey(vote_type)
    `
    )
    .eq('id', postId)
    .single()

  if (error || !post) {
    return null
  }

  return {
    ...post,
    user_vote: user
      ? post.user_vote?.find((v: any) => v.vote_type)?.vote_type || null
      : null,
  }
}

export async function createPost(data: {
  title: string
  content: string
  gameId?: string
  mediaUrl?: string
  mediaType?: 'image' | 'video' | 'clip'
  tags?: string[]
}): Promise<ForumPost> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    throw new Error('Unauthorized')
  }

  const { data: post, error } = await supabase
    .from('posts')
    .insert({
      author_id: user.id,
      title: data.title,
      content: data.content,
      game_id: data.gameId,
      media_url: data.mediaUrl,
      media_type: data.mediaType,
      tags: data.tags || [],
    })
    .select(
      `
      *,
      author:profiles!posts_author_id_fkey(*),
      game:games(*)
    `
    )
    .single()

  if (error) {
    throw error
  }

  return post
}

export async function updatePost(
  postId: string,
  data: {
    title?: string
    content?: string
    tags?: string[]
  }
): Promise<ForumPost> {
  const supabase = await createClient()

  const { data: post, error } = await supabase
    .from('posts')
    .update({
      ...data,
      updated_at: new Date().toISOString(),
    })
    .eq('id', postId)
    .select(
      `
      *,
      author:profiles!posts_author_id_fkey(*),
      game:games(*)
    `
    )
    .single()

  if (error) {
    throw error
  }

  return post
}

export async function deletePost(postId: string): Promise<void> {
  const supabase = await createClient()

  const { error } = await supabase.from('posts').delete().eq('id', postId)

  if (error) {
    throw error
  }
}

export async function votePost(
  postId: string,
  voteType: 'upvote' | 'downvote'
): Promise<void> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    throw new Error('Unauthorized')
  }

  // Check if user already voted
  const { data: existingVote } = await supabase
    .from('post_votes')
    .select('*')
    .eq('post_id', postId)
    .eq('user_id', user.id)
    .single()

  if (existingVote) {
    if (existingVote.vote_type === voteType) {
      // Remove vote if same type
      await supabase
        .from('post_votes')
        .delete()
        .eq('post_id', postId)
        .eq('user_id', user.id)
    } else {
      // Update vote if different type
      await supabase
        .from('post_votes')
        .update({ vote_type: voteType })
        .eq('post_id', postId)
        .eq('user_id', user.id)
    }
  } else {
    // Create new vote
    await supabase.from('post_votes').insert({
      post_id: postId,
      user_id: user.id,
      vote_type: voteType,
    })
  }
}

export async function getComments(postId: string): Promise<ForumComment[]> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  const { data: comments, error } = await supabase
    .from('comments')
    .select(
      `
      *,
      author:profiles!comments_author_id_fkey(*),
      user_vote:comment_votes!comment_votes_comment_id_fkey(vote_type)
    `
    )
    .eq('post_id', postId)
    .order('created_at', { ascending: true })

  if (error) {
    throw error
  }

  // Build comment tree
  const commentMap = new Map<string, ForumComment>()
  const rootComments: ForumComment[] = []

  comments?.forEach((comment) => {
    const commentWithVote = {
      ...comment,
      replies: [],
      user_vote: user
        ? comment.user_vote?.find((v: any) => v.vote_type)?.vote_type || null
        : null,
    }
    commentMap.set(comment.id, commentWithVote)
  })

  comments?.forEach((comment) => {
    const commentObj = commentMap.get(comment.id)!
    if (comment.parent_comment_id) {
      const parent = commentMap.get(comment.parent_comment_id)
      if (parent) {
        parent.replies = parent.replies || []
        parent.replies.push(commentObj)
      }
    } else {
      rootComments.push(commentObj)
    }
  })

  return rootComments
}

export async function createComment(data: {
  postId: string
  content: string
  parentCommentId?: string
}): Promise<ForumComment> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    throw new Error('Unauthorized')
  }

  const { data: comment, error } = await supabase
    .from('comments')
    .insert({
      post_id: data.postId,
      author_id: user.id,
      content: data.content,
      parent_comment_id: data.parentCommentId,
    })
    .select(
      `
      *,
      author:profiles!comments_author_id_fkey(*)
    `
    )
    .single()

  if (error) {
    throw error
  }

  return comment
}

export async function voteComment(
  commentId: string,
  voteType: 'upvote' | 'downvote'
): Promise<void> {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    throw new Error('Unauthorized')
  }

  const { data: existingVote } = await supabase
    .from('comment_votes')
    .select('*')
    .eq('comment_id', commentId)
    .eq('user_id', user.id)
    .single()

  if (existingVote) {
    if (existingVote.vote_type === voteType) {
      await supabase
        .from('comment_votes')
        .delete()
        .eq('comment_id', commentId)
        .eq('user_id', user.id)
    } else {
      await supabase
        .from('comment_votes')
        .update({ vote_type: voteType })
        .eq('comment_id', commentId)
        .eq('user_id', user.id)
    }
  } else {
    await supabase.from('comment_votes').insert({
      comment_id: commentId,
      user_id: user.id,
      vote_type: voteType,
    })
  }
}
