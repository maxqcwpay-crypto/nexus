"use client";

import Link from "next/link";
import { useState } from "react";
import { Gamepad2, Menu, X, Search, Bell } from "lucide-react";
import { useUser } from "@/lib/auth/useUser";
import UserMenu from "./auth/UserMenu";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, loading } = useUser();

  const navItems = [
    { title: "Accueil", href: "/" },
    { title: "Forum", href: "/forum" },
    { title: "LFG", href: "/lfg" },
    { title: "Communauté", href: "/community" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-effect border-b border-slate-800/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2 group">
            <div className="relative">
              <Gamepad2 className="h-8 w-8 text-indigo-500 group-hover:text-cyan-400 transition-colors" />
              <div className="absolute inset-0 blur-md bg-indigo-500 opacity-0 group-hover:opacity-50 transition-opacity" />
            </div>
            <span className="text-2xl font-bold neon-text">NexusGG</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="px-4 py-2 rounded-md text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/50 transition-all duration-200"
              >
                {item.title}
              </Link>
            ))}
          </div>

          {/* Right side icons */}
          <div className="hidden md:flex items-center space-x-4">
            {user && (
              <>
                <button className="p-2 rounded-md hover:bg-slate-800/50 transition-all duration-200 relative">
                  <Search className="h-5 w-5 text-slate-400 hover:text-white" />
                </button>
                <button className="p-2 rounded-md hover:bg-slate-800/50 transition-all duration-200 relative">
                  <Bell className="h-5 w-5 text-slate-400 hover:text-white" />
                  <span className="absolute top-1 right-1 h-2 w-2 bg-cyan-400 rounded-full animate-pulse" />
                </button>
              </>
            )}

            {!loading && (
              <>
                {user ? (
                  <UserMenu user={user} />
                ) : (
                  <div className="flex items-center space-x-3">
                    <Link
                      href="/login"
                      className="px-4 py-2 rounded-md text-slate-300 hover:text-white hover:bg-slate-800/50 font-medium transition-all duration-200"
                    >
                      Connexion
                    </Link>
                    <Link
                      href="/signup"
                      className="px-4 py-2 rounded-md bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-medium transition-all duration-200 shadow-lg hover:shadow-indigo-500/50"
                    >
                      S&apos;inscrire
                    </Link>
                  </div>
                )}
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-md hover:bg-slate-800/50 transition-all"
          >
            {mobileMenuOpen ? (
              <X className="h-6 w-6 text-slate-300" />
            ) : (
              <Menu className="h-6 w-6 text-slate-300" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-effect border-t border-slate-800/50">
          <div className="px-2 pt-2 pb-3 space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="block px-3 py-2 rounded-md text-base font-medium text-slate-300 hover:text-white hover:bg-slate-800/50 transition-all"
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.title}
              </Link>
            ))}
            {!loading && (
              <div className="pt-4 pb-2 border-t border-slate-800/50 space-y-2">
                {user ? (
                  <div className="px-3 py-2">
                    <UserMenu user={user} />
                  </div>
                ) : (
                  <>
                    <Link
                      href="/login"
                      className="block px-3 py-2 rounded-md text-slate-300 hover:text-white hover:bg-slate-800/50 font-medium text-center"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      Connexion
                    </Link>
                    <Link
                      href="/signup"
                      className="block px-3 py-2 rounded-md bg-gradient-to-r from-indigo-500 to-cyan-500 text-white font-medium text-center"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      S&apos;inscrire
                    </Link>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
