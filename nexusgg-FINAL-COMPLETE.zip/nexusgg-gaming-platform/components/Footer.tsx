import Link from "next/link";
import { Gamepad2, Twitter, Youtube, Twitch, MessageCircle } from "lucide-react";

export default function Footer() {
  const footerLinks = {
    Plateforme: [
      { name: "Accueil", href: "/" },
      { name: "Forum", href: "/forum" },
      { name: "LFG", href: "/lfg" },
      { name: "Communauté", href: "/community" },
    ],
    Ressources: [
      { name: "Guides", href: "/guides" },
      { name: "FAQ", href: "/faq" },
      { name: "Support", href: "/support" },
      { name: "API", href: "/api" },
    ],
    Légal: [
      { name: "Conditions d'utilisation", href: "/terms" },
      { name: "Politique de confidentialité", href: "/privacy" },
      { name: "Règles de la communauté", href: "/rules" },
    ],
  };

  return (
    <footer className="glass-effect border-t border-slate-800/50 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center space-x-2 mb-4">
              <Gamepad2 className="h-8 w-8 text-indigo-500" />
              <span className="text-2xl font-bold neon-text">NexusGG</span>
            </Link>
            <p className="text-slate-400 mb-4 max-w-sm">
              La plateforme gaming ultime pour trouver des équipes, partager tes
              exploits et dominer le classement.
            </p>
            {/* Social Links */}
            <div className="flex items-center space-x-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg glass-hover transition-all"
              >
                <Twitter className="h-5 w-5 text-slate-400 hover:text-cyan-400" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg glass-hover transition-all"
              >
                <Youtube className="h-5 w-5 text-slate-400 hover:text-red-500" />
              </a>
              <a
                href="https://twitch.tv"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg glass-hover transition-all"
              >
                <Twitch className="h-5 w-5 text-slate-400 hover:text-purple-500" />
              </a>
              <a
                href="https://discord.com"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg glass-hover transition-all"
              >
                <MessageCircle className="h-5 w-5 text-slate-400 hover:text-indigo-500" />
              </a>
            </div>
          </div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h3 className="font-semibold text-white mb-4">{title}</h3>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-slate-400 hover:text-indigo-400 transition-colors text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-800/50 flex flex-col md:flex-row items-center justify-between">
          <p className="text-slate-500 text-sm">
            © 2026 NexusGG. Tous droits réservés.
          </p>
          <div className="flex items-center space-x-6 mt-4 md:mt-0">
            <span className="text-sm text-slate-500">
              Fait avec 💜 pour les gamers
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
