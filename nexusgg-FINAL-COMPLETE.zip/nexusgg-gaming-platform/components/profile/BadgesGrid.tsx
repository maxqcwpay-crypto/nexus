"use client";

import {
  UserPlus,
  Trophy,
  Users,
  Shield,
  Crown,
  Video,
  Heart,
  Award,
  LucideIcon,
} from "lucide-react";

interface Badge {
  id: string;
  name: string;
  icon: string;
  description: string;
  rarity: "common" | "rare" | "epic" | "legendary";
}

interface BadgesGridProps {
  badges: Badge[];
}

const iconMap: Record<string, LucideIcon> = {
  "user-plus": UserPlus,
  trophy: Trophy,
  users: Users,
  shield: Shield,
  crown: Crown,
  video: Video,
  heart: Heart,
  award: Award,
};

const rarityConfig = {
  common: {
    color: "text-slate-400",
    bg: "bg-slate-800/50",
    border: "border-slate-700",
    glow: "shadow-slate-500/20",
  },
  rare: {
    color: "text-blue-400",
    bg: "bg-blue-900/30",
    border: "border-blue-500/30",
    glow: "shadow-blue-500/30",
  },
  epic: {
    color: "text-purple-400",
    bg: "bg-purple-900/30",
    border: "border-purple-500/30",
    glow: "shadow-purple-500/30",
  },
  legendary: {
    color: "text-amber-400",
    bg: "bg-amber-900/30",
    border: "border-amber-500/30",
    glow: "shadow-amber-500/50",
  },
};

export default function BadgesGrid({ badges }: BadgesGridProps) {
  if (!badges || badges.length === 0) {
    return (
      <div className="card-gaming text-center py-12">
        <Trophy className="h-12 w-12 text-slate-600 mx-auto mb-4" />
        <p className="text-slate-400">Aucun badge pour le moment</p>
        <p className="text-sm text-slate-500 mt-2">
          Continue à jouer pour débloquer des badges !
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {badges.map((badge) => {
        const Icon = iconMap[badge.icon] || Trophy;
        const config = rarityConfig[badge.rarity];

        return (
          <div
            key={badge.id}
            className={`glass-effect rounded-lg p-6 border ${config.border} hover:${config.glow} transition-all duration-300 group cursor-pointer`}
          >
            <div
              className={`h-16 w-16 rounded-full ${config.bg} flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform`}
            >
              <Icon className={`h-8 w-8 ${config.color}`} />
            </div>
            <div className="text-center">
              <h3 className={`font-bold ${config.color} mb-1`}>
                {badge.name}
              </h3>
              <p className="text-xs text-slate-500">{badge.description}</p>
              <div className="mt-2">
                <span
                  className={`text-xs px-2 py-1 rounded ${config.bg} ${config.color} font-medium uppercase`}
                >
                  {badge.rarity}
                </span>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
