// Core Types for NexusGG Gaming Platform

export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  bio?: string;
  createdAt: Date;
  updatedAt: Date;
  // Gaming specific
  favoriteGames: Game[];
  twitchUrl?: string;
  steamUrl?: string;
  discordTag?: string;
  rank: UserRank;
  badges: Badge[];
}

export interface Game {
  id: string;
  name: string;
  slug: string;
  coverImage?: string;
  genre: string[];
  platform: Platform[];
}

export type Platform = 'PC' | 'PS5' | 'Xbox' | 'Switch' | 'Mobile';

export type UserRank = 'Rookie' | 'Player' | 'Pro' | 'Elite' | 'Legend';

export interface Badge {
  id: string;
  name: string;
  icon: string;
  description: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface Post {
  id: string;
  authorId: string;
  author: User;
  title: string;
  content: string;
  mediaUrl?: string;
  mediaType?: 'image' | 'video' | 'clip';
  createdAt: Date;
  updatedAt: Date;
  upvotes: number;
  downvotes: number;
  commentCount: number;
  tags: string[];
  gameId?: string;
  game?: Game;
}

export interface Comment {
  id: string;
  postId: string;
  authorId: string;
  author: User;
  content: string;
  createdAt: Date;
  upvotes: number;
  downvotes: number;
  parentCommentId?: string;
  replies?: Comment[];
}

export interface LFGPost {
  id: string;
  authorId: string;
  author: User;
  gameId: string;
  game: Game;
  title: string;
  description: string;
  platform: Platform;
  playersNeeded: number;
  currentPlayers: number;
  scheduledTime?: Date;
  voiceRequired: boolean;
  skillLevel: 'Casual' | 'Competitive' | 'Any';
  createdAt: Date;
  expiresAt: Date;
  status: 'open' | 'full' | 'closed';
  tags: string[];
}

export interface LFGApplication {
  id: string;
  lfgPostId: string;
  userId: string;
  user: User;
  message?: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: Date;
}

// Navigation
export interface NavItem {
  title: string;
  href: string;
  icon?: string;
  disabled?: boolean;
}

// API Response types
export interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    pageSize: number;
    totalPages: number;
    totalItems: number;
  };
}
