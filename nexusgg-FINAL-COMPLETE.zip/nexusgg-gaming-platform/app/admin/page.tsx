import { redirect } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { isAdmin, getAdminStats, getAdminLogs } from "@/lib/admin/admin-service";
import AdminSidebar from "@/components/admin/AdminSidebar";
import StatsCard from "@/components/admin/StatsCard";
import { Users, FileText, MessageSquare, Activity, TrendingUp } from "lucide-react";
import { formatRelativeTime } from "@/lib/utils";

export default async function AdminDashboard() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user || !(await isAdmin(user.id))) {
    redirect("/");
  }

  const stats = await getAdminStats();
  const logs = await getAdminLogs(10);

  return (
    <div className="min-h-screen flex bg-slate-950">
      <AdminSidebar />

      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-white mb-2">Dashboard</h1>
            <p className="text-slate-400">Vue d&apos;ensemble de la plateforme</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
              title="Total Utilisateurs"
              value={stats.totalUsers}
              icon={Users}
              trend={{ value: stats.newUsers, isPositive: true }}
              color="indigo"
            />
            <StatsCard
              title="Total Posts"
              value={stats.totalPosts}
              icon={FileText}
              trend={{ value: stats.newPosts, isPositive: true }}
              color="cyan"
            />
            <StatsCard
              title="Total Commentaires"
              value={stats.totalComments}
              icon={MessageSquare}
              color="purple"
            />
            <StatsCard
              title="Utilisateurs Actifs"
              value={stats.activeUsers}
              icon={Activity}
              color="green"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Activity */}
            <div className="glass-effect rounded-lg p-6 border border-slate-800/50">
              <div className="flex items-center space-x-2 mb-6">
                <TrendingUp className="h-5 w-5 text-indigo-400" />
                <h2 className="text-xl font-bold text-white">Activité Récente</h2>
              </div>
              <div className="space-y-4">
                {stats.recentActivity.slice(0, 5).map((activity: any) => (
                  <div
                    key={activity.id}
                    className="flex items-start space-x-3 p-3 rounded-lg hover:bg-slate-800/30 transition-colors"
                  >
                    <img
                      src={activity.author?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${activity.author?.username}`}
                      alt={activity.author?.username}
                      className="h-10 w-10 rounded-full"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white truncate">
                        <span className="font-medium">{activity.author?.username}</span>
                        {" a publié "}
                        <span className="text-slate-400">{activity.title}</span>
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        {formatRelativeTime(new Date(activity.created_at))}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Admin Logs */}
            <div className="glass-effect rounded-lg p-6 border border-slate-800/50">
              <div className="flex items-center space-x-2 mb-6">
                <Activity className="h-5 w-5 text-cyan-400" />
                <h2 className="text-xl font-bold text-white">Logs Admin</h2>
              </div>
              <div className="space-y-3">
                {logs.map((log: any) => (
                  <div
                    key={log.id}
                    className="flex items-start justify-between p-3 rounded-lg glass-effect border border-slate-800/30"
                  >
                    <div className="flex-1">
                      <p className="text-sm text-white">
                        <span className="font-medium">{log.admin?.username}</span>
                        {" - "}
                        <span className="text-slate-400">{log.action.replace(/_/g, ' ')}</span>
                      </p>
                      <p className="text-xs text-slate-500 mt-1">
                        {formatRelativeTime(new Date(log.created_at))}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
              <div className="text-sm text-slate-400 mb-1">Nouveaux utilisateurs (7j)</div>
              <div className="text-2xl font-bold text-green-400">+{stats.newUsers}</div>
            </div>
            <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
              <div className="text-sm text-slate-400 mb-1">Nouveaux posts (7j)</div>
              <div className="text-2xl font-bold text-cyan-400">+{stats.newPosts}</div>
            </div>
            <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
              <div className="text-sm text-slate-400 mb-1">Utilisateurs actifs (24h)</div>
              <div className="text-2xl font-bold text-indigo-400">{stats.activeUsers}</div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
