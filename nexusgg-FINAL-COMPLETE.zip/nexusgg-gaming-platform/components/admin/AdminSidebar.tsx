"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  FileText,
  Gamepad2,
  Trophy,
  Flag,
  Activity,
  Settings,
  Shield,
} from "lucide-react";

const menuItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/admin" },
  { icon: Users, label: "Utilisateurs", href: "/admin/users" },
  { icon: FileText, label: "Posts", href: "/admin/posts" },
  { icon: Gamepad2, label: "Jeux", href: "/admin/games" },
  { icon: Trophy, label: "Badges", href: "/admin/badges" },
  { icon: Flag, label: "Reports", href: "/admin/reports" },
  { icon: Activity, label: "Logs", href: "/admin/logs" },
  { icon: Settings, label: "Paramètres", href: "/admin/settings" },
];

export default function AdminSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 glass-effect border-r border-slate-800/50 min-h-screen p-6">
      <div className="mb-8">
        <div className="flex items-center space-x-2 mb-2">
          <Shield className="h-6 w-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">Admin Panel</h2>
        </div>
        <p className="text-xs text-slate-500">NexusGG Management</p>
      </div>

      <nav className="space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;

          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                isActive
                  ? "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30"
                  : "text-slate-400 hover:bg-slate-800/50 hover:text-white"
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="font-medium">{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="mt-8 pt-8 border-t border-slate-800/50">
        <Link
          href="/"
          className="flex items-center space-x-2 text-sm text-slate-500 hover:text-white transition-colors"
        >
          <span>← Retour au site</span>
        </Link>
      </div>
    </aside>
  );
}
