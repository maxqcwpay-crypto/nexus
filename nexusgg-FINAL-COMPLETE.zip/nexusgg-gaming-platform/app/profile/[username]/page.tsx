import { notFound } from "next/navigation";
import { createClient } from "@/lib/auth/supabase-server";
import { getProfileByUsername } from "@/lib/profile/profile-service";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ProfileHeader from "@/components/profile/ProfileHeader";
import FavoriteGames from "@/components/profile/FavoriteGames";
import BadgesGrid from "@/components/profile/BadgesGrid";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

interface ProfilePageProps {
  params: {
    username: string;
  };
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const { username } = params;
  const profile = await getProfileByUsername(username);

  if (!profile) {
    notFound();
  }

  // Get current user to check if this is their own profile
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  const isOwnProfile = user?.id === profile.id;

  // Extract favorite games from the joined data
  const favoriteGames =
    profile.favorite_games?.map((fg: any) => fg.game).filter(Boolean) || [];

  // Extract badges from the joined data
  const badges =
    profile.badges?.map((ub: any) => ub.badge).filter(Boolean) || [];

  return (
    <div className="min-h-screen">
      <Navbar />

      <main className="pt-16">
        <ProfileHeader profile={profile} isOwnProfile={isOwnProfile} />

        {/* Content Tabs */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="glass-effect rounded-lg p-6 border border-slate-800/50">
            <div className="border-b border-slate-800/50 mb-6">
              <div className="flex space-x-8">
                <button className="pb-4 px-1 border-b-2 border-indigo-500 text-white font-medium">
                  Aperçu
                </button>
                <button className="pb-4 px-1 border-b-2 border-transparent text-slate-400 hover:text-white transition-colors">
                  Posts
                </button>
                <button className="pb-4 px-1 border-b-2 border-transparent text-slate-400 hover:text-white transition-colors">
                  Clips
                </button>
              </div>
            </div>

            <div className="space-y-8">
              {/* Jeux Favoris */}
              <section>
                <h2 className="text-2xl font-bold text-white mb-4">
                  Jeux Favoris
                </h2>
                <FavoriteGames games={favoriteGames} />
              </section>

              {/* Badges */}
              <section>
                <h2 className="text-2xl font-bold text-white mb-4">Badges</h2>
                <BadgesGrid badges={badges} />
              </section>

              {/* Recent Activity */}
              <section>
                <h2 className="text-2xl font-bold text-white mb-4">
                  Activité Récente
                </h2>
                <div className="card-gaming text-center py-12">
                  <p className="text-slate-400">
                    Aucune activité récente pour le moment
                  </p>
                </div>
              </section>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
