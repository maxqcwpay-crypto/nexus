-- Forum tables for posts and comments

-- Posts table
create table if not exists posts (
  id uuid default gen_random_uuid() primary key,
  author_id uuid references profiles(id) on delete cascade not null,
  game_id uuid references games(id) on delete set null,
  title text not null,
  content text not null,
  media_url text,
  media_type text check (media_type in ('image', 'video', 'clip')),
  upvotes integer default 0,
  downvotes integer default 0,
  comment_count integer default 0,
  tags text[] default '{}',
  is_pinned boolean default false,
  is_locked boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Comments table
create table if not exists comments (
  id uuid default gen_random_uuid() primary key,
  post_id uuid references posts(id) on delete cascade not null,
  author_id uuid references profiles(id) on delete cascade not null,
  parent_comment_id uuid references comments(id) on delete cascade,
  content text not null,
  upvotes integer default 0,
  downvotes integer default 0,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- User votes on posts
create table if not exists post_votes (
  id uuid default gen_random_uuid() primary key,
  post_id uuid references posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  vote_type text check (vote_type in ('upvote', 'downvote')) not null,
  created_at timestamp with time zone default now(),
  unique(post_id, user_id)
);

-- User votes on comments
create table if not exists comment_votes (
  id uuid default gen_random_uuid() primary key,
  comment_id uuid references comments(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete cascade not null,
  vote_type text check (vote_type in ('upvote', 'downvote')) not null,
  created_at timestamp with time zone default now(),
  unique(comment_id, user_id)
);

-- Post views tracking
create table if not exists post_views (
  id uuid default gen_random_uuid() primary key,
  post_id uuid references posts(id) on delete cascade not null,
  user_id uuid references profiles(id) on delete set null,
  ip_address text,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table posts enable row level security;
alter table comments enable row level security;
alter table post_votes enable row level security;
alter table comment_votes enable row level security;
alter table post_views enable row level security;

-- Policies for posts
create policy "Posts are viewable by everyone"
  on posts for select
  using (true);

create policy "Authenticated users can create posts"
  on posts for insert
  with check (auth.uid() = author_id);

create policy "Users can update their own posts"
  on posts for update
  using (auth.uid() = author_id);

create policy "Users can delete their own posts"
  on posts for delete
  using (auth.uid() = author_id);

-- Policies for comments
create policy "Comments are viewable by everyone"
  on comments for select
  using (true);

create policy "Authenticated users can create comments"
  on comments for insert
  with check (auth.uid() = author_id);

create policy "Users can update their own comments"
  on comments for update
  using (auth.uid() = author_id);

create policy "Users can delete their own comments"
  on comments for delete
  using (auth.uid() = author_id);

-- Policies for votes
create policy "Votes are viewable by everyone"
  on post_votes for select
  using (true);

create policy "Users can manage their own post votes"
  on post_votes for all
  using (auth.uid() = user_id);

create policy "Comment votes are viewable by everyone"
  on comment_votes for select
  using (true);

create policy "Users can manage their own comment votes"
  on comment_votes for all
  using (auth.uid() = user_id);

-- Policies for views
create policy "Anyone can create views"
  on post_views for insert
  with check (true);

-- Function to update post vote counts
create or replace function update_post_votes()
returns trigger as $$
begin
  if TG_OP = 'INSERT' then
    if NEW.vote_type = 'upvote' then
      update posts set upvotes = upvotes + 1 where id = NEW.post_id;
    else
      update posts set downvotes = downvotes + 1 where id = NEW.post_id;
    end if;
  elsif TG_OP = 'UPDATE' then
    if OLD.vote_type = 'upvote' and NEW.vote_type = 'downvote' then
      update posts set upvotes = upvotes - 1, downvotes = downvotes + 1 where id = NEW.post_id;
    elsif OLD.vote_type = 'downvote' and NEW.vote_type = 'upvote' then
      update posts set upvotes = upvotes + 1, downvotes = downvotes - 1 where id = NEW.post_id;
    end if;
  elsif TG_OP = 'DELETE' then
    if OLD.vote_type = 'upvote' then
      update posts set upvotes = upvotes - 1 where id = OLD.post_id;
    else
      update posts set downvotes = downvotes - 1 where id = OLD.post_id;
    end if;
  end if;
  return NEW;
end;
$$ language plpgsql;

-- Trigger for post votes
drop trigger if exists on_post_vote_change on post_votes;
create trigger on_post_vote_change
  after insert or update or delete on post_votes
  for each row execute procedure update_post_votes();

-- Function to update comment vote counts
create or replace function update_comment_votes()
returns trigger as $$
begin
  if TG_OP = 'INSERT' then
    if NEW.vote_type = 'upvote' then
      update comments set upvotes = upvotes + 1 where id = NEW.comment_id;
    else
      update comments set downvotes = downvotes + 1 where id = NEW.comment_id;
    end if;
  elsif TG_OP = 'UPDATE' then
    if OLD.vote_type = 'upvote' and NEW.vote_type = 'downvote' then
      update comments set upvotes = upvotes - 1, downvotes = downvotes + 1 where id = NEW.comment_id;
    elsif OLD.vote_type = 'downvote' and NEW.vote_type = 'upvote' then
      update comments set upvotes = upvotes + 1, downvotes = downvotes - 1 where id = NEW.comment_id;
    end if;
  elsif TG_OP = 'DELETE' then
    if OLD.vote_type = 'upvote' then
      update comments set upvotes = upvotes - 1 where id = OLD.comment_id;
    else
      update comments set downvotes = downvotes - 1 where id = OLD.comment_id;
    end if;
  end if;
  return NEW;
end;
$$ language plpgsql;

-- Trigger for comment votes
drop trigger if exists on_comment_vote_change on comment_votes;
create trigger on_comment_vote_change
  after insert or update or delete on comment_votes
  for each row execute procedure update_comment_votes();

-- Function to update comment count on posts
create or replace function update_post_comment_count()
returns trigger as $$
begin
  if TG_OP = 'INSERT' then
    update posts set comment_count = comment_count + 1 where id = NEW.post_id;
  elsif TG_OP = 'DELETE' then
    update posts set comment_count = comment_count - 1 where id = OLD.post_id;
  end if;
  return NEW;
end;
$$ language plpgsql;

-- Trigger for comment count
drop trigger if exists on_comment_change on comments;
create trigger on_comment_change
  after insert or delete on comments
  for each row execute procedure update_post_comment_count();

-- Function to update user posts count
create or replace function update_user_posts_count()
returns trigger as $$
begin
  if TG_OP = 'INSERT' then
    update profiles set posts_count = posts_count + 1 where id = NEW.author_id;
  elsif TG_OP = 'DELETE' then
    update profiles set posts_count = posts_count - 1 where id = OLD.author_id;
  end if;
  return NEW;
end;
$$ language plpgsql;

-- Trigger for user posts count
drop trigger if exists on_post_change on posts;
create trigger on_post_change
  after insert or delete on posts
  for each row execute procedure update_user_posts_count();

-- Indexes for performance
create index if not exists posts_created_at_idx on posts(created_at desc);
create index if not exists posts_author_id_idx on posts(author_id);
create index if not exists posts_game_id_idx on posts(game_id);
create index if not exists posts_upvotes_idx on posts(upvotes desc);
create index if not exists comments_post_id_idx on comments(post_id);
create index if not exists comments_parent_id_idx on comments(parent_comment_id);
create index if not exists post_votes_user_idx on post_votes(user_id);
create index if not exists comment_votes_user_idx on comment_votes(user_id);
