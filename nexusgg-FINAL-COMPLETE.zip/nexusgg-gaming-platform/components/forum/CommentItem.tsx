"use client";

import { useState } from "react";
import { ThumbsUp, ThumbsDown, Reply, Edit, Trash2, Flag, Save, X } from "lucide-react";
import { ForumComment } from "@/lib/forum/forum-service";
import { formatRelativeTime } from "@/lib/utils";
import Link from "next/link";
import CommentForm from "./CommentForm";
import ReportModal from "./ReportModal";
import { editComment, deleteComment } from "@/app/forum/actions";
import { useRouter } from "next/navigation";

interface CommentItemProps {
  comment: ForumComment;
  postId: string;
  depth?: number;
  currentUserId?: string;
}

export default function CommentItem({ comment, postId, depth = 0, currentUserId }: CommentItemProps) {
  const router = useRouter();
  const [showReply, setShowReply] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(comment.content);
  const [isSaving, setIsSaving] = useState(false);

  const isOwner = currentUserId === comment.author_id;

  const handleSaveEdit = async () => {
    if (!editContent.trim()) return;
    
    setIsSaving(true);
    try {
      await editComment(comment.id, editContent.trim());
      router.refresh();
      setIsEditing(false);
    } catch (error) {
      alert("Erreur lors de la modification");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce commentaire ?")) return;

    try {
      await deleteComment(comment.id, postId);
      router.refresh();
    } catch (error) {
      alert("Erreur lors de la suppression");
    }
  };

  return (
    <div className={`${depth > 0 ? 'ml-8 mt-4' : 'mt-4'}`}>
      <div className="glass-effect rounded-lg p-4 border border-slate-800/50">
        {/* Header */}
        <div className="flex items-center space-x-2 mb-3">
          <Link
            href={`/profile/${comment.author?.username}`}
            className="font-medium text-slate-300 hover:text-white transition-colors"
          >
            {comment.author?.username}
          </Link>
          <span className="text-slate-600">•</span>
          <span className="text-xs text-slate-500">
            {formatRelativeTime(new Date(comment.created_at))}
          </span>
          {comment.updated_at && comment.updated_at !== comment.created_at && (
            <>
              <span className="text-slate-600">•</span>
              <span className="text-xs text-slate-500 italic">modifié</span>
            </>
          )}
        </div>

        {/* Content */}
        {isEditing ? (
          <div className="mb-3">
            <textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              rows={4}
              className="w-full px-3 py-2 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white resize-none mb-2"
              autoFocus
            />
            <div className="flex items-center space-x-2">
              <button
                onClick={handleSaveEdit}
                disabled={isSaving || !editContent.trim()}
                className="px-3 py-1.5 rounded-lg bg-indigo-500 hover:bg-indigo-600 text-white text-sm font-medium transition-all disabled:opacity-50 flex items-center space-x-1"
              >
                <Save className="h-3.5 w-3.5" />
                <span>{isSaving ? "Sauvegarde..." : "Sauvegarder"}</span>
              </button>
              <button
                onClick={() => {
                  setIsEditing(false);
                  setEditContent(comment.content);
                }}
                className="px-3 py-1.5 rounded-lg glass-effect border border-slate-700 text-slate-300 text-sm font-medium transition-all flex items-center space-x-1"
              >
                <X className="h-3.5 w-3.5" />
                <span>Annuler</span>
              </button>
            </div>
          </div>
        ) : (
          <p className="text-slate-300 mb-3 whitespace-pre-wrap">{comment.content}</p>
        )}

        {/* Actions */}
        {!isEditing && (
          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-2">
              <button className="p-1 rounded hover:bg-slate-800/50 text-slate-400 hover:text-indigo-400 transition-all">
                <ThumbsUp className="h-4 w-4" />
              </button>
              <span className="text-slate-500">{comment.upvotes}</span>
              <button className="p-1 rounded hover:bg-slate-800/50 text-slate-400 hover:text-red-400 transition-all">
                <ThumbsDown className="h-4 w-4" />
              </button>
            </div>
            {depth < 3 && (
              <button
                onClick={() => setShowReply(!showReply)}
                className="flex items-center space-x-1 text-slate-400 hover:text-white transition-colors"
              >
                <Reply className="h-4 w-4" />
                <span>{showReply ? 'Annuler' : 'Répondre'}</span>
              </button>
            )}
            {isOwner && (
              <>
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center space-x-1 text-slate-400 hover:text-indigo-400 transition-colors"
                >
                  <Edit className="h-4 w-4" />
                  <span>Éditer</span>
                </button>
                <button
                  onClick={handleDelete}
                  className="flex items-center space-x-1 text-slate-400 hover:text-red-400 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                  <span>Supprimer</span>
                </button>
              </>
            )}
            {!isOwner && currentUserId && (
              <button
                onClick={() => setShowReportModal(true)}
                className="flex items-center space-x-1 text-slate-400 hover:text-red-400 transition-colors"
              >
                <Flag className="h-4 w-4" />
                <span>Signaler</span>
              </button>
            )}
          </div>
        )}

        {/* Reply Form */}
        {showReply && (
          <div className="mt-4 pt-4 border-t border-slate-800/50">
            <CommentForm
              postId={postId}
              parentCommentId={comment.id}
              placeholder={`Répondre à ${comment.author?.username}...`}
              onSuccess={() => setShowReply(false)}
              autoFocus
            />
          </div>
        )}
      </div>

      {/* Replies */}
      {comment.replies && comment.replies.length > 0 && (
        <div className="mt-2">
          {comment.replies.map((reply) => (
            <CommentItem 
              key={reply.id} 
              comment={reply} 
              postId={postId} 
              depth={depth + 1}
              currentUserId={currentUserId}
            />
          ))}
        </div>
      )}
      
      {showReportModal && (
        <ReportModal
          targetType="comment"
          targetId={comment.id}
          onClose={() => setShowReportModal(false)}
        />
      )}
    </div>
  );
}
