# 🎮 NexusGG - Plateforme Gaming Communautaire

Une plateforme moderne et immersive pour les gamers, construite avec Next.js 14, TypeScript et Tailwind CSS.

![NexusGG](https://img.shields.io/badge/Status-MVP-success)
![Next.js](https://img.shields.io/badge/Next.js-14+-black)
![TypeScript](https://img.shields.io/badge/TypeScript-5.4+-blue)
![Tailwind](https://img.shields.io/badge/Tailwind-3.4+-38bdf8)

## ✨ Fonctionnalités (MVP en cours)

### Étape 1 - Landing Page ✅
- ✅ **Landing Page Immersive** avec hero section et effets glassmorphism
- ✅ **Navigation Responsive** avec menu mobile
- ✅ **Derniers Posts** de la communauté (données mockées)
- ✅ **Design Gaming** avec palette de couleurs cybernétique (indigo/cyan)
- ✅ **Dark Mode** par défaut
- ✅ **Animations** fluides et modernes

### Étape 2 - Authentification ✅
- ✅ **Pages Login/Signup** avec validation complète
- ✅ **Intégration Supabase** pour l'authentification
- ✅ **OAuth** Google et Discord
- ✅ **Protected Routes** avec middleware
- ✅ **User Menu** dans la navbar
- ✅ **Gestion de session** sécurisée

### Étape 3 - Profils Utilisateurs ✅
- ✅ **Pages de profil publiques** avec design gaming
- ✅ **Upload d'avatar** via Supabase Storage
- ✅ **Édition de profil** (bio, liens sociaux, jeux favoris)
- ✅ **Système de badges** avec 4 raretés
- ✅ **Jeux favoris** (jusqu'à 6)
- ✅ **Stats utilisateur** (posts, followers, wins)
- ✅ **Système de rangs** (Rookie → Legend)

### Étape 4 - Forum ✅
- ✅ **Pages forum** (liste, création, détails)
- ✅ **Système de votes** upvote/downvote
- ✅ **Commentaires imbriqués** (3 niveaux)
- ✅ **Filtres** par jeu, tag, recherche
- ✅ **Tri** (récents, top, tendances)
- ✅ **Upload média** (images/vidéos)
- ✅ **Tags personnalisés**

### Bonus - Panel d'Administration ✅
- ✅ **Dashboard** avec statistiques
- ✅ **Gestion utilisateurs** (ban, delete)
- ✅ **Gestion posts** (pin, lock, delete)
- ✅ **Gestion jeux** (CRUD complet)
- ✅ **Système de rôles** (super_admin, moderator, support)
- ✅ **Logs d'activité** admin
- ✅ **Interface dédiée** responsive

### Étape 5 - Système LFG ✅
- ✅ **Page LFG** avec liste et filtres
- ✅ **Création de demandes** LFG
- ✅ **Système de candidatures** (postuler, accepter, refuser)
- ✅ **Gestion d'équipe** automatique
- ✅ **Filtres avancés** (jeu, plateforme, niveau, région)
- ✅ **Statuts automatiques** (open, full, expired)
- ✅ **Page de détails** avec gestion candidatures

## 🚀 Stack Technique

- **Framework:** Next.js 14+ (App Router)
- **Langage:** TypeScript
- **Styling:** Tailwind CSS
- **Icônes:** Lucide React
- **Composants:** Architecture modulaire personnalisée
- **Auth & Database:** Supabase
- **Validation:** Zod + React Hook Form
- **Gestion d'état:** React Hooks (Zustand à implémenter)

## 📁 Structure du Projet

```
nexusgg-gaming-platform/
├── app/
│   ├── login/              # Page de connexion
│   ├── signup/             # Page d'inscription
│   ├── auth/callback/      # Callback OAuth
│   ├── layout.tsx          # Layout racine avec metadata
│   ├── page.tsx            # Page d'accueil
│   └── globals.css         # Styles globaux et thème
├── components/
│   ├── auth/
│   │   ├── LoginForm.tsx   # Formulaire de connexion
│   │   ├── SignupForm.tsx  # Formulaire d'inscription
│   │   └── UserMenu.tsx    # Menu utilisateur
│   ├── Navbar.tsx          # Barre de navigation
│   ├── HeroSection.tsx     # Section hero
│   ├── LatestPosts.tsx     # Liste des posts
│   └── Footer.tsx          # Pied de page
├── lib/
│   ├── auth/
│   │   ├── supabase-client.ts  # Client Supabase (browser)
│   │   ├── supabase-server.ts  # Client Supabase (server)
│   │   ├── validation.ts       # Schémas Zod
│   │   └── useUser.ts          # Hook utilisateur
│   └── utils.ts            # Fonctions utilitaires
├── types.ts                # Interfaces TypeScript
├── middleware.ts           # Middleware auth
├── .env.example            # Variables d'environnement
└── public/                 # Assets statiques
```

## 🎨 Design System

### Palette de Couleurs

- **Background:** `slate-950` (très sombre)
- **Texte:** `slate-200` (clair)
- **Accent Principal:** `indigo-500` (violet)
- **Accent Secondaire:** `cyan-400` (bleu néon)
- **Accent Tertiaire:** `purple-500` et `pink-500`

### Effets Visuels

- **Glassmorphism:** Arrière-plans semi-transparents avec flou
- **Neon Effects:** Bordures et textes avec effet néon
- **Animations:** Float, glow, et gradient animés
- **Hover States:** Transitions fluides sur tous les éléments interactifs

## 🛠️ Installation et Démarrage

```bash
# Installer les dépendances
npm install

# Configurer Supabase (IMPORTANT)
# 1. Crée un projet sur https://supabase.com
# 2. Copie .env.example vers .env.local
cp .env.example .env.local
# 3. Remplis les variables dans .env.local avec tes clés Supabase
# 4. Suis le guide complet dans SUPABASE_SETUP.md

# Lancer le serveur de développement
npm run dev

# Build pour production
npm run build

# Démarrer en mode production
npm start
```

Ouvrir [http://localhost:3000](http://localhost:3000) dans votre navigateur.

**⚠️ Configuration requise :** Avant de lancer l'app, configure Supabase en suivant `SUPABASE_SETUP.md`

## 📋 Développement Terminé ✅

Toutes les fonctionnalités principales ont été implémentées :

### ✅ Étape 1 - Landing Page
### ✅ Étape 2 - Authentification  
### ✅ Étape 3 - Profils Utilisateurs
### ✅ Étape 4 - Forum Complet
### ✅ Étape 5 - Système LFG
### ✅ Bonus - Panel d'Administration

## 🎯 Améliorations Futures Possibles

- [ ] Système de notifications en temps réel
- [ ] Followers/Following fonctionnel
- [ ] Chat intégré dans LFG
- [ ] Édition de posts/commentaires
- [ ] Reports et modération avancée
- [ ] Pages statiques (Terms, Privacy, etc.)
- [ ] Markdown support dans posts
- [ ] Bookmarks/Favoris
- [ ] Mentions @username
- [ ] Intégration Discord/Twitch

## 🎯 Fonctionnalités Avancées (Futures)

- [ ] Système de notifications en temps réel
- [ ] Chat privé entre utilisateurs
- [ ] Intégration Discord/Twitch
- [ ] Classements et leaderboards
- [ ] Événements et tournois
- [ ] Achievements et badges personnalisés
- [ ] Mode sombre/clair (toggle)
- [ ] Multilingue (i18n)

## 🔧 Configuration pour Cursor AI

Ce projet est optimisé pour être utilisé avec Cursor AI:

1. Ouvrir le projet dans Cursor
2. La structure modulaire facilite l'édition par composant
3. TypeScript strict activé pour une meilleure auto-complétion
4. Tous les composants sont documentés et typés

## 📝 Notes de Développement

- **Server Components:** Utilisés par défaut pour de meilleures performances
- **Client Components:** Marqués avec `"use client"` quand nécessaire
- **Responsive Design:** Mobile-first approach
- **Accessibilité:** Semantic HTML et ARIA labels
- **SEO:** Metadata optimisé dans layout.tsx

## 🤝 Contribution

Ce projet est en cours de développement actif. Les fonctionnalités sont ajoutées étape par étape.

## 📄 Licence

Projet personnel - Tous droits réservés

---

**Fait avec 💜 pour la communauté gaming**
