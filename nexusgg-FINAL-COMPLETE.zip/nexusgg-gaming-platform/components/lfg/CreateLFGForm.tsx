"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { Loader2, AlertCircle, Users, Calendar, Mic } from "lucide-react";
import { createClient } from "@/lib/auth/supabase-client";

interface CreateLFGFormProps {
  games: any[];
}

interface LFGFormData {
  gameId: string;
  title: string;
  description: string;
  platform: string;
  playersNeeded: number;
  scheduledTime: string;
  voiceRequired: boolean;
  skillLevel: string;
  rankRequirement: string;
  region: string;
  tags: string;
}

const platforms = ["PC", "PS5", "Xbox", "Switch", "Mobile"];
const skillLevels = ["Casual", "Competitive", "Any"];
const regions = ["EU West", "EU East", "NA West", "NA East", "Asia", "OCE"];

export default function CreateLFGForm({ games }: CreateLFGFormProps) {
  const router = useRouter();
  const [error, setError] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<LFGFormData>({
    defaultValues: {
      playersNeeded: 1,
      skillLevel: "Any",
      voiceRequired: false,
    },
  });

  const voiceRequired = watch("voiceRequired");

  const onSubmit = async (data: LFGFormData) => {
    setError("");
    setIsLoading(true);

    try {
      const supabase = createClient();
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) {
        router.push("/login");
        return;
      }

      const tags = data.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean);

      const { error: lfgError } = await supabase.from("lfg_posts").insert({
        author_id: user.id,
        game_id: data.gameId,
        title: data.title,
        description: data.description,
        platform: data.platform,
        players_needed: Number(data.playersNeeded),
        scheduled_time: data.scheduledTime || null,
        voice_required: data.voiceRequired,
        skill_level: data.skillLevel,
        rank_requirement: data.rankRequirement || null,
        region: data.region || null,
        tags,
      });

      if (lfgError) throw lfgError;

      router.push("/lfg");
      router.refresh();
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue");
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {error && (
        <div className="p-4 rounded-lg bg-red-500/10 border border-red-500/50 flex items-start space-x-3">
          <AlertCircle className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-200">{error}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Game */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Jeu *
          </label>
          <select
            {...register("gameId", { required: "Le jeu est requis" })}
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          >
            <option value="">Sélectionner un jeu...</option>
            {games.map((game) => (
              <option key={game.id} value={game.id}>
                {game.name}
              </option>
            ))}
          </select>
          {errors.gameId && (
            <p className="mt-1 text-sm text-red-400">{errors.gameId.message}</p>
          )}
        </div>

        {/* Title */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Titre *
          </label>
          <input
            {...register("title", {
              required: "Le titre est requis",
              minLength: { value: 5, message: "Minimum 5 caractères" },
            })}
            type="text"
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
            placeholder="Ex: Cherche 2 joueurs pour Ranked..."
          />
          {errors.title && (
            <p className="mt-1 text-sm text-red-400">{errors.title.message}</p>
          )}
        </div>

        {/* Platform */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Plateforme *
          </label>
          <select
            {...register("platform", { required: true })}
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          >
            <option value="">Sélectionner...</option>
            {platforms.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>

        {/* Players Needed */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            <Users className="inline h-4 w-4 mr-1" />
            Joueurs recherchés *
          </label>
          <input
            {...register("playersNeeded", {
              required: true,
              min: 1,
              max: 10,
            })}
            type="number"
            min="1"
            max="10"
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          />
        </div>

        {/* Skill Level */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Niveau de jeu
          </label>
          <select
            {...register("skillLevel")}
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          >
            {skillLevels.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Region */}
        <div>
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Région
          </label>
          <select
            {...register("region")}
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          >
            <option value="">Toutes</option>
            {regions.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>

        {/* Scheduled Time */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-300 mb-2">
            <Calendar className="inline h-4 w-4 mr-1" />
            Date et heure (optionnel)
          </label>
          <input
            {...register("scheduledTime")}
            type="datetime-local"
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
          />
        </div>

        {/* Description */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Description *
          </label>
          <textarea
            {...register("description", {
              required: "La description est requise",
              minLength: { value: 10, message: "Minimum 10 caractères" },
            })}
            rows={4}
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white resize-none"
            placeholder="Décris ce que tu recherches, tes attentes..."
          />
          {errors.description && (
            <p className="mt-1 text-sm text-red-400">
              {errors.description.message}
            </p>
          )}
        </div>

        {/* Voice Required */}
        <div className="md:col-span-2">
          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              {...register("voiceRequired")}
              type="checkbox"
              className="w-5 h-5 rounded border-slate-700 bg-slate-800 text-indigo-500 focus:ring-indigo-500 focus:ring-offset-slate-900"
            />
            <div>
              <div className="flex items-center space-x-2 text-sm font-medium text-white">
                <Mic className="h-4 w-4" />
                <span>Micro requis</span>
              </div>
              <p className="text-xs text-slate-500">
                Communication vocale obligatoire
              </p>
            </div>
          </label>
        </div>

        {/* Tags */}
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-slate-300 mb-2">
            Tags (séparés par des virgules)
          </label>
          <input
            {...register("tags")}
            type="text"
            className="w-full px-4 py-3 glass-effect rounded-lg border border-slate-700 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 transition-all outline-none text-white"
            placeholder="ranked, chill, training"
          />
        </div>
      </div>

      {/* Submit */}
      <div className="flex items-center justify-end space-x-4 pt-4 border-t border-slate-800/50">
        <button
          type="button"
          onClick={() => router.back()}
          className="px-6 py-3 rounded-lg glass-effect border border-slate-700 hover:border-slate-600 text-slate-300 font-medium transition-all"
        >
          Annuler
        </button>
        <button
          type="submit"
          disabled={isLoading}
          className="px-6 py-3 rounded-lg bg-gradient-to-r from-indigo-500 to-cyan-500 hover:from-indigo-600 hover:to-cyan-600 text-white font-semibold transition-all duration-300 shadow-lg hover:shadow-indigo-500/50 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              <span>Création...</span>
            </>
          ) : (
            <span>Créer la demande</span>
          )}
        </button>
      </div>
    </form>
  );
}
